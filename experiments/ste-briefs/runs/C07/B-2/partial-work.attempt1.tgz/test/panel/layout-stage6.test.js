import { describe, it, expect } from 'vitest';
import { computeStageLayout } from '../../js/panel/layout.js';
import { buildOrreryRings } from '../../js/panel/rings.js';

// Stage 6 orrery registry (DESIGN.md): eight concentric rings — DNS 10.60
// takes Ring 7 and the Router side-card sits beside the 10.x hub on
// Ring 6 with its two-interface chip. Title here is the manifest ref in
// slices.yaml / storymap.yaml (PANEL-6).
describe('stage 6 layout', () => {
  it('stage 6 lays out the eight-ring DNS orrery with the router side-card on the network ring', () => {
    const stage6 = computeStageLayout(6, 5);
    expect(stage6.rings.map((r) => r.radius)).toEqual([
      400, 800, 1200, 1600, 2000, 2400, 2800, 3200,
    ]);
    expect(stage6.rings.map((r) => r.id)).toEqual([
      'ring-db',
      'ring-workers',
      'ring-cache',
      'ring-compute',
      'ring-lb',
      'ring-network',
      'ring-dns',
      'ring-clients',
    ]);
    // The resolver sits on Ring 7 at 180°; the router joins the 10.x hub
    // on the network ring at 150°.
    expect(stage6.nodes['node-dns']).toMatchObject({
      x: -2800,
      y: 0,
      radius: 2800,
      ring: 'ring-dns',
    });
    expect(stage6.nodes['node-router']).toMatchObject({
      radius: 2400,
      ring: 'ring-network',
    });
    // The hub keeps its 180° seat; the stage-5 stack rides unchanged.
    expect(stage6.nodes['node-network']).toMatchObject({ x: -2400, y: 0 });
    expect(stage6.nodes['node-db']).toMatchObject({ x: -400, y: 0, ring: 'ring-db' });
    expect(stage6.nodes['node-queue']).toMatchObject({ ring: 'ring-workers' });
    expect(stage6.nodes['node-worker']).toMatchObject({ ring: 'ring-workers' });
    expect(stage6.nodes['node-cache']).toMatchObject({ x: -1200, y: 0, ring: 'ring-cache' });
    expect(stage6.nodes['node-lb']).toMatchObject({ x: -2000, y: 0, ring: 'ring-lb' });
    expect(stage6.nodes['node-browser']).toMatchObject({ x: -3200, y: 0, ring: 'ring-clients' });
    for (const node of Object.values(stage6.nodes)) {
      expect(node.radius).toBeGreaterThan(0);
      expect(node.x !== 0 || node.y !== 0).toBe(true);
    }
    // Two new spokes: hub -> DNS and hub -> router, after the stage-5 set.
    expect(stage6.wires.map((w) => w.id)).toEqual([
      'wire-browser-network',
      'wire-network-lb',
      'wire-lb-webserver',
      'wire-lb-webserver-2',
      'wire-webserver-cache',
      'wire-webserver-2-cache',
      'wire-cache-db',
      'wire-cache-queue',
      'wire-queue-worker',
      'wire-worker-db',
      'wire-network-dns',
      'wire-network-router',
    ]);
    expect(stage6.wires.at(-2)).toMatchObject({ x1: -2400, y1: 0, x2: -2800, y2: 0 });
    // The bounds clear the outer 3200 client ring.
    expect(stage6.bounds).toEqual({ minX: -3380, maxX: 120, minY: -540, maxY: 540 });

    // A tuned ring gap rescales all eight rings as r_k = k * ringGap.
    const tuned = computeStageLayout(6, 5, { ringGap: 300 });
    expect(tuned.rings.map((r) => r.radius)).toEqual([
      300, 600, 900, 1200, 1500, 1800, 2100, 2400,
    ]);
    expect(tuned.nodes['node-dns']).toMatchObject({ x: -2100, y: 0, radius: 2100 });
    expect(tuned.nodes['node-browser']).toMatchObject({ x: -2400, y: 0 });
    expect(buildOrreryRings(400, 6).map((r) => r.label)).toContain('RING 7 · DNS');
  });
});
