import { describe, it, expect } from 'vitest';
import { describeSnapshot } from '../../js/panel/model.js';
import { componentTitle, formatComponentState } from '../../js/panel/inspector-state.js';

// Stage-boundary extraction (guard-file-size): the Stage 6 narrative-branch
// pins and the dns/router inspector state. Titles here are the manifest refs
// in slices.yaml / storymap.yaml (PANEL-6). The named counter-examples are
// the brief's DL-3/DL-4 pins: a host-less stage-6 GET keeps the stage-5 hop
// story byte-identical, a hosted trace adds exactly two DNS hops, and an NX
// trace emits no GET.
const BASE = {
  tick: 2,
  users: 5,
  serverAddress: '10.1',
  queueDepth: 0,
  served: 1,
  avgLatencyTicks: 1,
  loadBalancer: {
    address: '10.1',
    algorithm: 'round-robin',
    backends: ['10.11', '10.12'],
    nextBackend: '10.12',
    forwarded: 1,
    lastTarget: '10.11',
    perBackend: { 10.11: 1, 10.12: 0 },
  },
  cache: { address: '10.20', ttlTicks: 10, hits: 0, misses: 1, sets: 1, evictions: 0, lastLookup: null, entries: [] },
  database: {
    primaryAddress: '10.30',
    replicaAddress: '10.31',
    replicationLagTicks: 3,
    reads: 1,
    writes: 0,
    staleReads: 0,
    replicated: 0,
    lastOp: null,
    pendingReplication: 0,
    rows: [],
  },
  workerQueue: {
    address: '10.40',
    workerAddress: '10.41',
    jobDurationTicks: 2,
    enqueued: 0,
    completed: 0,
    activeJob: null,
    pendingJobs: [],
    lastJobResult: null,
  },
  servers: [
    { address: '10.11', queueDepth: 0, served: 1, queue: [] },
    { address: '10.12', queueDepth: 0, served: 0, queue: [] },
  ],
};

const CHAIN_TRACE = {
  method: 'GET',
  path: '/about',
  request: 'GET /about',
  from: '10.2',
  targetServer: '10.11',
  cacheStatus: 'MISS',
  dbOp: 'SELECT',
  dbStale: false,
  response: '200 This is the about page',
  status: 200,
  body: 'This is the about page',
  routeId: 'about',
};

describe('stage 6 hop sentences', () => {
  // PINS: named counter-example — the host-less stage-6 story is the
  // stage-5 story byte for byte, including the /8 denominators.
  it('stage 6 host-less hop sentences are byte-identical to the stage-5 story', () => {
    const story = (stage, trace) =>
      Array.from({ length: 8 }, (_, i) =>
        describeSnapshot({
          ...BASE,
          stage,
          trace: { ...trace, hop: i + 1 },
        }).hopStatus,
      );
    const stage5 = story(5, { ...CHAIN_TRACE, hosted: false, nx: false, totalHops: 8 });
    const stage6 = story(6, { ...CHAIN_TRACE, hosted: false, nx: false, totalHops: 8 });
    expect(stage6).toEqual(stage5);
    expect(stage6[0]).toBe('Hop 1/8: Browser (10.2) emits "GET /about"');
    expect(stage6[7]).toBe('Hop 8/8: Worker (10.41) idle — no async jobs in this trace');
    // No DNS hop anywhere in the story.
    expect(stage6.join(' ')).not.toContain('DNS');
  });

  it('stage 6 hosted hop sentences add exactly two DNS hops to the stage-5 chain', () => {
    const trace = {
      ...CHAIN_TRACE,
      path: 'example.com/about',
      request: 'GET example.com/about',
      hosted: true,
      host: 'example.com',
      dnsTarget: '10.1',
      dnsStatus: 'AUTH',
      nx: false,
      totalHops: 10,
    };
    const sentence = (hop) => describeSnapshot({ ...BASE, stage: 6, trace: { ...trace, hop } }).hopStatus;
    expect(sentence(1)).toBe(
      'Hop 1/10: Browser (10.2) emits "GET example.com/about" — host example.com unresolved',
    );
    expect(sentence(2)).toBe('Hop 2/10: Browser (10.2) asks DNS (10.60) — "who is example.com?"');
    expect(sentence(3)).toBe('Hop 3/10: DNS (10.60) answers example.com -> 10.1 (authoritative)');
    // The chain resumes at hop 4 with the stage-5 bodies and /10 denominators.
    expect(sentence(4)).toBe('Hop 4/10: Network (10.x) routes to LoadBalancer (10.1)');
    expect(sentence(5)).toBe('Hop 5/10: LoadBalancer (10.1) -> 10.11 queue');
    expect(sentence(6)).toBe('Hop 6/10: Database SELECT @ Replica (10.31) — fresh');
    expect(sentence(10)).toBe('Hop 10/10: Worker (10.41) idle — no async jobs in this trace');
    // A ledger hit names the cache HIT instead of the authority.
    expect(
      describeSnapshot({ ...BASE, stage: 6, trace: { ...trace, hop: 3, dnsStatus: 'HIT' } })
        .hopStatus,
    ).toBe('Hop 3/10: DNS (10.60) answers example.com -> 10.1 (cache HIT)');
  });

  // PINS: the NX branch — the trace narrates the resolver ask/answer and the
  // NX card, and a GET appears in no sentence.
  it('stage 6 NX sentences never narrate a GET', () => {
    const trace = {
      method: 'GET',
      path: 'nope.example/about',
      request: 'GET nope.example/about',
      from: '10.2',
      hosted: true,
      host: 'nope.example',
      dnsTarget: null,
      dnsStatus: null,
      nx: true,
      totalHops: 4,
    };
    const sentences = Array.from({ length: 4 }, (_, i) =>
      describeSnapshot({ ...BASE, stage: 6, trace: { ...trace, hop: i + 1 } }).hopStatus,
    );
    expect(sentences[0]).toBe(
      'Hop 1/4: Browser (10.2) emits "GET nope.example/about" — host nope.example unresolved',
    );
    expect(sentences[1]).toBe('Hop 2/4: Browser (10.2) asks DNS (10.60) — "who is nope.example?"');
    expect(sentences[2]).toBe('Hop 3/4: DNS (10.60) answers nope.example — NX no record');
    expect(sentences[3]).toBe(
      'Hop 4/4: Browser (10.2) renders NX — no GET emitted for nope.example',
    );
    const joined = sentences.join(' ');
    expect(joined).not.toContain('"200');
    expect(joined).not.toContain('LoadBalancer');
    expect(joined).not.toContain('Network delivers');
  });

  it('describes the stage-6 total hops from the trace shape, not the fixed map', () => {
    const hosted = describeSnapshot({
      ...BASE,
      stage: 6,
      trace: { ...CHAIN_TRACE, hosted: true, host: 'example.com', nx: false, totalHops: 10 },
    });
    expect(hosted.totalHops).toBe(10);
    const nx = describeSnapshot({
      ...BASE,
      stage: 6,
      trace: { ...CHAIN_TRACE, hosted: true, host: 'nope.example', nx: true, totalHops: 4 },
    });
    expect(nx.totalHops).toBe(4);
    // Stages 1-5 keep the fixed map.
    expect(describeSnapshot({ ...BASE, stage: 5 }).totalHops).toBe(8);
  });
});

describe('stage 6 inspector state', () => {
  const snap = {
    ...BASE,
    stage: 6,
    dns: {
      address: '10.60',
      ttlTicks: 300,
      lookups: 2,
      cachedHits: 1,
      authoritative: 1,
      lastReply: { name: 'example.com', status: 'HIT', target: '10.1', atTick: 2 },
      cache: [
        { name: 'example.com', target: '10.1', cachedAtTick: 0, expiresAtTick: 300, ttlRemaining: 298 },
      ],
    },
    router: {
      leftAddress: '10.65',
      rightAddress: '20.1',
      routed: 0,
      lastFrame: null,
    },
  };

  it('dns and router inspector titles and state derive from the live snapshot', () => {
    expect(componentTitle(snap, 'dns')).toBe('DNS — mini-IP 10.60');
    expect(componentTitle(snap, 'router')).toBe('Router — 10.65 ⇄ 20.1');
    const dnsState = JSON.parse(formatComponentState(snap, 'dns'));
    expect(dnsState).toEqual({
      address: '10.60',
      ttlTicks: 300,
      lookups: 2,
      cachedHits: 1,
      authoritative: 1,
      lastReply: snap.dns.lastReply,
      entries: snap.dns.cache,
    });
    const routerState = JSON.parse(formatComponentState(snap, 'router'));
    expect(routerState).toEqual({
      leftAddress: '10.65',
      rightAddress: '20.1',
      subnets: ['10.x', '20.x'],
      routed: 0,
      lastFrame: null,
    });
    // The dns/router labels carry the live counters for the node cards.
    const labels = describeSnapshot(snap);
    expect(labels.dnsStatsLabel).toBe(
      'Lookups: 2 · Cached hits: 1 · Authority: 1 · TTL: 300t',
    );
    expect(labels.dnsEntries).toEqual(snap.dns.cache);
    expect(labels.routerStatsLabel).toBe('Routed: 0 · 10.65 ⇄ 20.1');
    // The network interface table names the Stage 6 additions.
    const networkState = JSON.parse(formatComponentState(snap, 'network'));
    expect(networkState.interfaces['10.60']).toBe('DNS');
    expect(networkState.interfaces[10.65]).toBe('Router ⇄ 20.1');
  });
});
