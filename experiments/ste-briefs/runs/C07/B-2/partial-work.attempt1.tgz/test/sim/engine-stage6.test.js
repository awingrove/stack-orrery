import { describe, it, expect } from 'vitest';
import { createEngine } from '../../js/sim/engine.js';

// Stage 6 engine wiring — the DNS front-end over the stage-5 chain. The
// titles here are the manifest refs in slices.yaml / storymap.yaml (SIM-6).
describe('stage 6 engine — DNS front-end over the stage-5 chain', () => {
  // PINS: the brief's named counter-example — a host-less path keeps the
  // stage-5 hop count and hop frames byte-identical, and the trace carries
  // no DNS hop.
  it('stage 6 hostless GET keeps the stage-5 hop frames byte-identical', () => {
    const run = (stage) => {
      const engine = createEngine({ stage, users: 5 });
      const frames = [];
      for (let hop = 0; hop < 8; hop++) {
        engine.traceHop({ method: 'GET', path: '/about' });
        frames.push(engine.snapshot().lastFrame);
      }
      return frames;
    };
    const stage5 = run(5);
    const stage6 = run(6);
    expect(stage6).toEqual(stage5);
    expect(stage6[0]).toBe('10.2 -> 10.1 | GET /about');

    // The resolver ledger stays untouched — no lookup happened.
    expect(createEngine({ stage: 6 }).snapshot().dns).toMatchObject({ lookups: 0 });
  });

  it('stage 6 hosted example.com/about adds exactly two DNS hops around the stage-5 chain', () => {
    const engine = createEngine({ stage: 6 });
    const frames = [];
    for (let hop = 0; hop < 10; hop++) {
      engine.traceHop({ method: 'GET', path: 'example.com/about' });
      frames.push(engine.snapshot().lastFrame);
    }
    // The two DNS hops lead, then the resolved GET enters the chain.
    expect(frames[0]).toBe('10.2 -> DNS (10.60) | GET example.com/about');
    expect(frames[1]).toBe('10.2 -> DNS (10.60) | who is example.com?');
    expect(frames[2]).toBe('DNS (10.60) -> 10.2 | example.com is 10.1');
    expect(frames[3]).toBe('routed 10.2 -> 10.1 (GET /about) to LoadBalancer');
    expect(frames[9]).toBe('Worker 10.41 idle — no async jobs in this trace');

    const snap = engine.snapshot();
    expect(snap.trace.hop).toBe(10);
    expect(snap.trace.totalHops).toBe(10);
    expect(snap.trace.hosted).toBe(true);
    expect(snap.trace.dnsTarget).toBe('10.1');
    expect(snap.trace.request).toBe('GET example.com/about');
    expect(snap.dns).toMatchObject({ lookups: 1, cachedHits: 0, authoritative: 1 });
    // The resolved request — not the host-style URL — reached the pool.
    expect(snap.servers[0].served).toBe(1);
    expect(snap.browserDisplay.body).toBe('This is the about page');

    // A second hosted trace is a ledger hit inside ttlTicks: the authority
    // counter stays put and the answer names the cached HIT.
    for (let hop = 0; hop < 10; hop++) engine.traceHop({ method: 'GET', path: 'example.com/about' });
    const second = engine.snapshot();
    expect(second.dns).toMatchObject({ lookups: 2, cachedHits: 1, authoritative: 1 });
    expect(second.trace.dnsStatus).toBe('HIT');
  });

  it('stage 6 NX trace renders the NX card and never emits a GET', () => {
    const engine = createEngine({ stage: 6 });
    for (let hop = 0; hop < 4; hop++) engine.traceHop({ method: 'GET', path: 'nope.example/about' });
    const snap = engine.snapshot();
    expect(snap.trace.hop).toBe(4);
    expect(snap.trace.totalHops).toBe(4);
    expect(snap.trace.nx).toBe(true);
    // The browser card renders the NX answer; no GET reached any server.
    expect(snap.browserDisplay).toMatchObject({ status: 'NX', body: 'no record' });
    expect(snap.dns).toMatchObject({ lookups: 1, cachedHits: 0, authoritative: 1 });
    expect(snap.servers.every((s) => s.served === 0 && s.queueDepth === 0)).toBe(true);
    expect(snap.loadBalancer.forwarded).toBe(0);
  });

  it('stage 6 engine exposes the dns and router snapshots and stages 1-5 stay bare', () => {
    const snap = createEngine({ stage: 6 }).snapshot();
    expect(snap.dns).toMatchObject({ address: '10.60', ttlTicks: 300, lookups: 0 });
    expect(snap.router).toMatchObject({
      leftAddress: '10.65',
      rightAddress: '20.1',
      routed: 0,
    });
    expect(createEngine({ stage: 5 }).snapshot().dns).toBe(null);
    expect(createEngine({ stage: 5 }).snapshot().router).toBe(null);
    expect(() => createEngine({ stage: 7 })).toThrow(/stage must be/);
  });
});
