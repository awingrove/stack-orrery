import { describe, it, expect } from 'vitest';
import { createRouter } from '../../js/sim/router.js';
import { createNetwork } from '../../js/sim/network.js';
import { createWebServer } from '../../js/sim/webserver.js';

describe('createRouter', () => {
  it('same-subnet sends and queue deliveries keep the plain network contract', () => {
    const left = createNetwork({ subnet: '10' });
    const right = createNetwork({ subnet: '20' });
    const server = createWebServer({ address: '10.1' });
    left.registerServer('10.1', server);
    const router = createRouter({ leftNetwork: left, rightNetwork: right });
    left.attachRouter(router);

    // A 10.x -> 10.x frame is answered by the fabric itself: the router
    // never sees it and `routed` stays at zero.
    expect(left.send({ from: '10.2', to: '10.1', request: 'GET /about' })).toEqual({
      from: '10.2',
      to: '10.1',
      request: 'GET /about',
      response: '200 This is the about page',
    });
    server.enqueue({
      id: 'you:1',
      atTick: 1,
      from: '10.2',
      to: '10.1',
      request: 'GET /',
      isYou: true,
    });
    expect(server.queueSnapshot()[0].isYou).toBe(true);
    expect(router.snapshot()).toMatchObject({ routed: 0, leftAddress: '10.65', rightAddress: '20.1' });
  });

  it('a cross-subnet frame takes exactly one router hop and 20.9 fails loud', () => {
    const left = createNetwork({ subnet: '10' });
    const right = createNetwork({ subnet: '20' });
    left.registerServer('10.1', createWebServer({ address: '10.1' }));
    const router = createRouter({ leftNetwork: left, rightNetwork: right });
    left.attachRouter(router);

    // 20.1 — the router's own 20-side interface — is the only reachable
    // subnet-20 target in Stage 6a, and the frame rides exactly one hop.
    const reply = left.send({ from: '10.2', to: '20.1', request: 'GET /' });
    expect(reply.response).toContain('20.1');
    expect(reply.routed).toBe(true);
    expect(router.snapshot().routed).toBe(1);
    expect(router.snapshot().lastFrame).toContain('one router hop via 10.65');

    // CHECKS: an unregistered 20.x host fails loud (DL-1), and nothing
    // queues across the join in Stage 6a.
    expect(() => left.send({ from: '10.2', to: '20.9', request: 'GET /' })).toThrow(
      /no host at 20\.9/,
    );
    expect(() =>
      left.deliverToQueue({ id: '1:1', from: '10.2', to: '20.1', request: 'GET /', atTick: 1 }),
    ).toThrow(/nothing queues/);

    // A subnet the router does not join keeps the plain no-server error.
    expect(() => left.send({ from: '10.2', to: '11.1', request: 'GET /' })).toThrow(
      /no server at 11\.1/,
    );

    // The join is bidirectional: a 20-side frame routed into the 10.x
    // fabric is one hop too.
    const back = router.route({ from: '20.1', to: '10.1', request: 'GET /about' });
    expect(back.response).toBe('200 This is the about page');
    expect(router.snapshot().routed).toBe(2);
  });

  it('router rejects invalid or same-subnet interfaces and missing networks', () => {
    expect(() => createRouter({ leftAddress: 'bad' })).toThrow(/invalid mini-IP/);
    expect(() => createRouter({ rightAddress: '2099' })).toThrow(/invalid mini-IP/);
    expect(() =>
      createRouter({
        leftAddress: '10.65',
        rightAddress: '10.66',
        leftNetwork: createNetwork(),
        rightNetwork: createNetwork(),
      }),
    ).toThrow(/different subnets/);
    expect(() =>
      createRouter({ leftNetwork: null, rightNetwork: createNetwork({ subnet: '20' }) }),
    ).toThrow(/required/);
    // A frame for a subnet neither interface joins is refused loud.
    const router = createRouter({
      leftNetwork: createNetwork(),
      rightNetwork: createNetwork({ subnet: '20' }),
    });
    expect(() => router.route({ from: '10.2', to: '30.1', request: 'GET /' })).toThrow(
      /not attached/,
    );
  });
});
