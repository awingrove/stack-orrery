import { describe, it, expect } from 'vitest';
import { createDns } from '../../js/sim/dns.js';

describe('createDns', () => {
  // PINS: the brief's DNS TTL branch — a hit inside ttlTicks is an
  // incrementing cachedHits counter with NO authoritative consult, and the
  // named counter-example: an expired entry is NOT answered from the cache
  // ledger, it re-consults the authoritative table.
  it('dns serves cache hits inside ttlTicks without consulting the authority and re-consults once an entry expires', () => {
    const dns = createDns({ address: '10.60', ttlTicks: 300 });

    // Cold lookup: the authoritative table answers and the ledger warms.
    expect(dns.lookup('example.com', 5)).toEqual({
      status: 'AUTH',
      name: 'example.com',
      target: '10.1',
    });
    let snap = dns.snapshot(5);
    expect(snap).toMatchObject({ lookups: 1, cachedHits: 0, authoritative: 1 });
    expect(snap.cache).toEqual([
      { name: 'example.com', target: '10.1', cachedAtTick: 5, expiresAtTick: 305, ttlRemaining: 300 },
    ]);

    // A hit inside ttlTicks: cachedHits increments, the authority counter
    // stays put — the ledger answered, the table was not consulted.
    expect(dns.lookup('example.com', 100)).toEqual({
      status: 'HIT',
      name: 'example.com',
      target: '10.1',
    });
    snap = dns.snapshot(100);
    expect(snap).toMatchObject({ lookups: 2, cachedHits: 1, authoritative: 1 });

    // The tick the TTL names is the first tick the entry is gone: the
    // lookup evicts it, re-consults the authority, and sets a fresh entry —
    // cachedHits stays where it was.
    expect(dns.lookup('example.com', 305)).toEqual({
      status: 'AUTH',
      name: 'example.com',
      target: '10.1',
    });
    snap = dns.snapshot(305);
    expect(snap).toMatchObject({ lookups: 3, cachedHits: 1, authoritative: 2 });
    expect(snap.cache[0]).toMatchObject({ cachedAtTick: 305, expiresAtTick: 605 });
  });

  it('unknown names answer NX no record and keep the browser off the GET path', () => {
    const dns = createDns();

    // CHECKS: the NX branch — an unknown name is a status, not a throw at
    // the DNS layer (the fail-loud throw rule belongs to cross-subnet
    // addresses); the reply carries no target and nothing is cached, so a
    // repeated ask consults the authority again instead of a ledger.
    expect(dns.lookup('nope.example', 0)).toEqual({ status: 'NX', name: 'nope.example' });
    let snap = dns.snapshot(0);
    expect(snap.lastReply).toEqual({ name: 'nope.example', status: 'NX', target: null, atTick: 0 });
    expect(snap.cache).toEqual([]);
    expect(snap).toMatchObject({ lookups: 1, cachedHits: 0, authoritative: 1 });

    expect(dns.lookup('nope.example', 1)).toEqual({ status: 'NX', name: 'nope.example' });
    snap = dns.snapshot(1);
    expect(snap).toMatchObject({ lookups: 2, cachedHits: 0, authoritative: 2 });
  });

  it('dns rejects a non mini-IP address and a non-positive or non-integer ttlTicks', () => {
    expect(() => createDns({ address: '1060' })).toThrow(/invalid mini-IP/);
    expect(() => createDns({ address: '10.6.0' })).toThrow(/invalid mini-IP/);
    expect(() => createDns({ ttlTicks: 0 })).toThrow(/ttlTicks/);
    expect(() => createDns({ ttlTicks: 2.5 })).toThrow(/ttlTicks/);
  });
});
