import { test, expect } from '@playwright/test';

// Stage 6 — DNS 10.60 with its tick-TTL ledger and the cross-subnet Router
// (10.65 ⇄ 20.1). The sim runs from a fixed seed, so the hop sequence — and
// therefore these assertions — are identical on every run. Titles are the
// manifest pins (PANEL-6): do not reword.

// The live Stage 6: 8 rings, the resolver and router cards visible, and a
// hosted path resolving through the ledger before the chain serves it.
test('should switch to Stage 6, resolve example.com through DNS 10.60, and inspect DNS code + TTL ledger', async ({
  page,
}) => {
  await page.goto('/panel.html');
  await page.getByTestId('stage-pill-6').click();
  await expect(page).toHaveURL(/stage=6/);
  await expect(page.getByTestId('stage-pill-6')).toHaveAttribute('aria-current', 'true');
  await expect(page.locator('.orrery-ring')).toHaveCount(8);
  await expect(page.locator('.orrery-ring').last()).toHaveAttribute('r', '3200');
  await expect(page.getByTestId('node-dns')).toBeVisible();
  await expect(page.getByTestId('node-router')).toBeVisible();
  await expect(page.getByTestId('dns-stats')).toHaveText(
    'Lookups: 0 · Cached hits: 0 · Authority: 0 · TTL: 300t',
  );
  await expect(page.getByTestId('router-stats')).toHaveText('Routed: 0 · 10.65 ⇄ 20.1');

  // First hosted trace: the authority answers and the ledger warms.
  await page.getByTestId('url-input').fill('example.com/about');
  for (let hop = 0; hop < 10; hop++) await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toContainText('Hop 10/10');
  await expect(page.getByTestId('dns-stats')).toHaveText(
    'Lookups: 1 · Cached hits: 0 · Authority: 1 · TTL: 300t',
  );
  await expect(page.getByTestId('dns-entries-list')).toContainText('example.com -> 10.1');
  await expect(page.getByTestId('browser-rendered-body')).toHaveText('This is the about page');

  // Second hosted trace: the ledger answers inside ttlTicks — a cached hit,
  // the authority counter stays put.
  for (let hop = 0; hop < 10; hop++) await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('dns-stats')).toHaveText(
    'Lookups: 2 · Cached hits: 1 · Authority: 1 · TTL: 300t',
  );

  await page.getByTestId('node-dns').click();
  await expect(page.getByTestId('inspector-code')).toContainText('createDns');
  await expect(page.getByTestId('inspector-state')).toContainText('"cachedHits": 1');
  await expect(page.getByTestId('inspector-state')).toContainText('"10.1"');

  await page.getByTestId('node-router').click();
  await expect(page.getByTestId('inspector-code')).toContainText('createRouter');
  await expect(page.getByTestId('inspector-state')).toContainText('"routed": 0');
});

// The hosted trace leads with the DNS ask and the answer, then the resolved
// GET enters the stage-5 chain.
test('should trace example.com/about with DNS ask + answer hops', async ({ page }) => {
  await page.goto('/panel.html');
  await page.getByTestId('stage-pill-6').click();
  await page.getByTestId('url-input').fill('example.com/about');

  await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toContainText(
    'Hop 1/10: Browser (10.2) emits "GET example.com/about" — host example.com unresolved',
  );
  await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toContainText(
    'Hop 2/10: Browser (10.2) asks DNS (10.60) — "who is example.com?"',
  );
  await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toContainText(
    'Hop 3/10: DNS (10.60) answers example.com -> 10.1 (authoritative)',
  );
  await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toContainText(
    'Hop 4/10: Network (10.x) routes to LoadBalancer (10.1)',
  );
  // The answer frame is on the journey log verbatim, before the chain.
  await expect(page.getByTestId('journey-log')).toContainText(
    'DNS (10.60) -> 10.2 | example.com is 10.1',
  );
  for (let hop = 0; hop < 6; hop++) await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toContainText(
    'Hop 10/10: Worker (10.41) idle — no async jobs in this trace',
  );
});

// Negative-case pin (named counter-example): a host-less GET on Stage 6
// keeps the Stage 5 hop story byte-identical — no DNS hop, no cross-subnet
// hop, the resolver ledger untouched.
test('should keep GET /about on Stage 6 at the Stage 5 hop story', async ({ page }) => {
  await page.goto('/panel.html');
  await page.getByTestId('stage-pill-5').click();
  await page.getByTestId('url-input').fill('/about');
  const trace = async () => {
    const texts = [];
    for (let hop = 0; hop < 8; hop++) {
      await page.getByTestId('btn-next-hop').click();
      texts.push(await page.getByTestId('hop-status').textContent());
    }
    return texts;
  };
  const stage5Story = await trace();

  await page.getByTestId('stage-pill-6').click();
  const stage6Story = await trace();
  expect(stage6Story).toEqual(stage5Story);
  expect(stage6Story[0]).toBe('Hop 1/8: Browser (10.2) emits "GET /about"');
  expect(stage6Story[7]).toBe('Hop 8/8: Worker (10.41) idle — no async jobs in this trace');

  // No DNS hop in the journey log, and the ledger stayed cold.
  const entries = await page.getByTestId('journey-log').locator('.journey-entry').allTextContents();
  expect(entries.filter((text) => text.includes('DNS'))).toEqual([]);
  await expect(page.getByTestId('dns-stats')).toHaveText(
    'Lookups: 0 · Cached hits: 0 · Authority: 0 · TTL: 300t',
  );
});

// CHECKS: the live-stage list feeds ?stage= — 6 selects the live pill and
// both Stage 6 cards; unknown values still fall back to Stage 1 (pinned in
// e2e/panel.spec.js).
test('should deep-link ?stage=6 to the live stage pill, DNS and router cards', async ({
  page,
}) => {
  await page.goto('/panel.html?stage=6');
  await expect(page.getByTestId('stage-pill-6')).toHaveAttribute('aria-current', 'true');
  await expect(page.getByTestId('node-dns')).toBeVisible();
  await expect(page.getByTestId('node-router')).toBeVisible();
  await expect(page.getByTestId('dns-stats')).toHaveText(
    'Lookups: 0 · Cached hits: 0 · Authority: 0 · TTL: 300t',
  );
});
