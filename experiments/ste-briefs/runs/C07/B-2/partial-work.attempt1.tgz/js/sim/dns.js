// DOCUMENTS: the Stage 6 component — a DNS resolver at mini-IP 10.60 with a
// tick-based TTL ledger over an authoritative table. It is a real Map lookup
// on the resolution path rather than a probability: a name asks the
// authoritative table only on a cache miss or an expired entry, a hit inside
// ttlTicks is answered from the ledger, and unknown names answer NX (the
// browser renders the NX card; no GET is emitted). Deterministic by
// construction: no clock, no RNG — time arrives as the `currentTick`
// argument, the same way the Cache keeps time.
//
// CHECKS: the constructor rejects an address that is not a two-number
// mini-IP and a ttlTicks that is not a positive integer (fail-loud over
// silent mis-configuration).
const AUTHORITATIVE = {
  'example.com': '10.1', // Stage 6b adds the CDN name here.
};

export function createDns({ address = '10.60', ttlTicks = 300 } = {}) {
  if (!/^\d+\.\d+$/.test(address)) {
    throw new Error(`dns: invalid mini-IP address ${address}`);
  }
  if (!Number.isInteger(ttlTicks) || ttlTicks < 1) {
    throw new Error(`dns: ttlTicks must be a positive integer, got ${ttlTicks}`);
  }
  const entries = new Map(); // name -> { name, target, cachedAtTick, expiresAtTick }
  let lookups = 0;
  let cachedHits = 0;
  let authoritative = 0;
  let lastReply = null;

  // An entry is stale the moment the current tick reaches its expiry —
  // cached at tick T with ttlTicks = 300 means alive through tick T + 299.
  function evictExpired(currentTick = 0) {
    for (const entry of entries.values()) {
      if (currentTick >= entry.expiresAtTick) entries.delete(entry.name);
    }
  }

  // lookup(name, currentTick): the ledger branch comes first — a live entry
  // answers with an incrementing cachedHits counter and no authoritative
  // consult; a miss, an expired entry, or an unknown name consults the
  // authoritative table. Unknown names return { status: 'NX' } — the DNS
  // layer itself does not throw (the fail-loud throw rule belongs to
  // cross-subnet addresses, see router.js).
  function lookup(name, currentTick = 0) {
    lookups += 1;
    evictExpired(currentTick);
    const entry = entries.get(name);
    if (entry) {
      cachedHits += 1;
      lastReply = { name, status: 'HIT', target: entry.target, atTick: currentTick };
      return { status: 'HIT', name, target: entry.target };
    }
    authoritative += 1;
    const target = AUTHORITATIVE[name] ?? null;
    if (target === null) {
      lastReply = { name, status: 'NX', target: null, atTick: currentTick };
      return { status: 'NX', name };
    }
    entries.set(name, {
      name,
      target,
      cachedAtTick: currentTick,
      expiresAtTick: currentTick + ttlTicks,
    });
    lastReply = { name, status: 'AUTH', target, atTick: currentTick };
    return { status: 'AUTH', name, target };
  }

  function snapshot(currentTick = 0) {
    evictExpired(currentTick);
    return {
      address,
      ttlTicks,
      lookups,
      cachedHits,
      authoritative,
      lastReply,
      cache: [...entries.values()].map((e) => ({
        name: e.name,
        target: e.target,
        cachedAtTick: e.cachedAtTick,
        expiresAtTick: e.expiresAtTick,
        ttlRemaining: e.expiresAtTick - currentTick,
      })),
    };
  }

  return {
    get address() {
      return address;
    },
    evictExpired,
    lookup,
    snapshot,
  };
}
