// DOCUMENTS: the Stage 6 DNS front-end for the hop machine — a wrapper over
// the chain machine (trace.js) that branches on host syntax before any GET
// exists. A browser path that carries a host (`example.com/about`, split on
// the first `/`) resolves through DNS 10.60 first: the browser emits its
// URL, asks the resolver, and only after the answer does the resolved
// request (`GET /about`) enter the stage-5 chain — the hosted shape is the
// stage-5 count plus exactly two DNS hops. A host-less path (`/about`)
// delegates to the chain machine untouched, so the stage-5 hop story stays
// byte-identical. An unknown name answers `NX no record`: the trace is the
// DNS ask, the NX answer, and the browser rendering the NX card — no GET is
// ever emitted (DL-3/DL-4: the branch consumes the resolver's actual reply).
//
// CHECKS: a mid-trace input change keeps the running trace (the input is
// read only when a trace starts, matching the chain machine's own rule); a
// hosted trace starts only while the chain machine is fresh or finished.
export function createDnsTrace({ base, dns, getTick, onFinish }) {
  if (!base || !dns) {
    throw new Error('trace-dns: base machine and dns resolver are required');
  }
  // The chain machine's finished shape for this wrapper's stage (the Stage
  // 5 chain shape it normalizes onto).
  const BASE_FINAL_HOP = 8;

  // null = direct mode: every step delegates to the chain machine.
  let hosted = null;

  function parseTarget(path = '') {
    const raw = String(path);
    const slashAt = raw.indexOf('/');
    return {
      host: slashAt === -1 ? raw : raw.slice(0, slashAt),
      hostPath: slashAt === -1 ? '/' : raw.slice(slashAt),
    };
  }

  function chainBusy() {
    const hop = base.snapshot().hop;
    return hop !== 0 && hop < BASE_FINAL_HOP;
  }

  function startHosted({ method, path, from }, target) {
    hosted = {
      hop: 1,
      request: `${method} ${path}`,
      method,
      path,
      from,
      host: target.host,
      hostPath: target.hostPath,
      nx: false,
      dnsTarget: null,
      dnsStatus: null,
      totalHops: 10,
    };
    return `${from} -> DNS (${dns.address}) | ${hosted.request}`;
  }

  function advanceHosted() {
    let frame = null;
    if (hosted.hop === 1) {
      // Hop 2/10: the resolver query itself.
      hosted.hop = 2;
      frame = `${hosted.from} -> DNS (${dns.address}) | who is ${hosted.host}?`;
    } else if (hosted.hop === 2) {
      // Hop 3/10: the answer hop — the actual ledger lookup happens here,
      // consuming the resolver's real reply. An NX answer switches the
      // trace to its own 4-hop shape; an address hands the resolved GET to
      // the chain machine (whose creation frame is superseded by this one).
      hosted.hop = 3;
      const reply = dns.lookup(hosted.host, getTick());
      if (reply.status === 'NX') {
        hosted.nx = true;
        hosted.totalHops = 4;
        frame = `DNS (${dns.address}) -> ${hosted.from} | NX no record`;
      } else {
        hosted.dnsTarget = reply.target;
        hosted.dnsStatus = reply.status;
        base.step({ method: hosted.method, path: hosted.hostPath, from: hosted.from });
        frame = `DNS (${dns.address}) -> ${hosted.from} | ${hosted.host} is ${reply.target}`;
      }
    } else if (hosted.nx) {
      // Hop 4/4: the browser renders the NX card — the reply that reached
      // the browser, not a GET on the wire.
      hosted.hop = 4;
      onFinish({
        from: dns.address,
        to: hosted.from,
        request: hosted.request,
        response: 'NX no record',
        nx: true,
        browser: hosted.from,
      });
      frame = `Browser ${hosted.from} renders ${hosted.host} — NX no record (no GET emitted)`;
    } else {
      // Hops 4..10: the resolved request rides the stage-5 chain; the
      // wrapper hop is the chain hop plus the two DNS hops before it.
      frame = base.step({});
      hosted.hop = base.snapshot().hop + 2;
    }
    return frame;
  }

  return {
    step({ method = 'GET', path = '/about', from = '10.2' } = {}) {
      const target = parseTarget(path);
      if (hosted) {
        // A running hosted trace keeps its shape until it finishes, like the
        // chain machine keeps a running trace until its restart hop.
        if (hosted.hop < hosted.totalHops) return advanceHosted();
        hosted = null;
      }
      if (target.host && !chainBusy()) return startHosted({ method, path, from }, target);
      return base.step({ method, path, from });
    },

    // The wrapper trace leads while a hosted/NX trace runs; otherwise the
    // chain machine's snapshot stands, tagged with the host-less shape.
    snapshot() {
      const baseSnap = base.snapshot();
      if (!hosted) {
        return {
          ...baseSnap,
          hosted: false,
          host: null,
          dnsTarget: null,
          dnsStatus: null,
          nx: false,
          totalHops: BASE_FINAL_HOP,
        };
      }
      return {
        ...baseSnap,
        hop: hosted.hop,
        method: hosted.method,
        path: hosted.path,
        request: hosted.request,
        from: hosted.from,
        hosted: true,
        host: hosted.host,
        dnsTarget: hosted.dnsTarget,
        dnsStatus: hosted.dnsStatus,
        nx: hosted.nx,
        totalHops: hosted.totalHops,
      };
    },
  };
}
