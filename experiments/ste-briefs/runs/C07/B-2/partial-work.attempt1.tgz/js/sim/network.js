// DOCUMENTS: the network — the wiring that lets two-number mini-IP
// addressable components exchange messages. Today it carries slim HTTP
// requests to a registered server; later stages attach more components
// without changing the send/enqueue contract.
//
// Stage 6: the fabric carries an optional subnet number and an attached
// Router (js/sim/router.js). A frame addressed to a subnet the router joins
// crosses the join for exactly one router hop; same-subnet traffic — and
// every network built with the zero-argument constructor — keeps the plain
// send/deliverToQueue contract untouched.
//
// CHECKS: every address crossing the wire is validated as a two-number
// mini-IP (<net>.<host>), and sends to unregistered hosts fail loud. A
// subnet the attached router does not join keeps that same loud
// no-server error rather than silently routing.
const MINI_IP = /^\d+\.\d+$/;
const netOf = (addr) => String(addr).split('.')[0];

export function createNetwork({ subnet = '10' } = {}) {
  const servers = new Map();
  let router = null;

  function validate(addr) {
    if (!MINI_IP.test(addr)) {
      throw new Error(`network: invalid mini-IP address ${addr}`);
    }
  }

  function resolve(address) {
    validate(address);
    const server = servers.get(address);
    if (!server) {
      throw new Error(`network: no server at ${address}`);
    }
    return server;
  }

  // A target leaves this fabric only when a router is attached and its
  // interfaces actually join the target's subnet.
  function crossesAttachedJoin(to) {
    return router !== null && netOf(to) !== subnet && router.servesSubnet(netOf(to));
  }

  return {
    registerServer(address, server) {
      validate(address);
      servers.set(address, server);
    },

    resolve,

    attachRouter(attached) {
      router = attached;
    },

    send({ from, to, request }) {
      validate(from);
      if (crossesAttachedJoin(to)) return router.route({ from, to, request });
      const server = resolve(to);
      const response = server.handleRequest(request);
      return { from, to, request, response };
    },

    // `isYou` rides through untouched: the engine marks the learner's own
    // interactive-browser request, the server stores it on the queue row.
    deliverToQueue({ id, from, to, request, atTick, isYou = false }) {
      validate(from);
      if (crossesAttachedJoin(to)) {
        return router.routeQueue({ id, from, to, request, atTick, isYou });
      }
      const server = resolve(to);
      server.enqueue({ id, from, to, request, atTick, isYou });
    },
  };
}
