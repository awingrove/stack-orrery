// DOCUMENTS: the Stage 6 component — a cross-subnet Router joining the 10.x
// and 20.x network instances (left interface 10.65, right interface 20.1).
// Any cross-subnet frame takes exactly one router hop and increments the
// `routed` counter; `isYou` rides through untouched. Same-subnet sends keep
// the plain network contract (network.js handles them and the router).
// Nothing lives in subnet 20 in Stage 6a besides the router's own presence:
// 20.1 (the router's 20-side) is the only reachable target, and Stage 6b
// occupies it with the CDN edge.
//
// CHECKS: the constructor rejects a non-mini-IP interface, interfaces on the
// same subnet, and a missing network on either side (fail-loud over a router
// that could never route).
const MINI_IP = /^\d+\.\d+$/;
const netOf = (addr) => String(addr).split('.')[0];

export function createRouter({
  leftAddress = '10.65',
  rightAddress = '20.1',
  leftNetwork = null,
  rightNetwork = null,
} = {}) {
  if (!MINI_IP.test(leftAddress) || !MINI_IP.test(rightAddress)) {
    throw new Error(`router: invalid mini-IP addresses ${leftAddress} / ${rightAddress}`);
  }
  if (netOf(leftAddress) === netOf(rightAddress)) {
    throw new Error(
      `router: the two interfaces must sit on different subnets, got ${leftAddress} / ${rightAddress}`,
    );
  }
  if (!leftNetwork || !rightNetwork) {
    throw new Error('router: leftNetwork and rightNetwork are required');
  }
  const leftSubnet = netOf(leftAddress);
  const rightSubnet = netOf(rightAddress);
  let routed = 0;
  let lastFrame = null;

  return {
    get leftAddress() {
      return leftAddress;
    },
    get rightAddress() {
      return rightAddress;
    },

    servesSubnet(subnet) {
      return subnet === leftSubnet || subnet === rightSubnet;
    },

    // One router hop across the join. A frame addressed to the router's own
    // 20-side interface terminates there — the interface answers so the wire
    // record keeps its slim response shape; a frame for any other 20.x host
    // fails loud (DL-1), and a frame for an unattached subnet is refused.
    route({ from, to, request, isYou = false }) {
      for (const addr of [from, to]) {
        if (!MINI_IP.test(addr)) {
          throw new Error(`router: invalid mini-IP address ${addr}`);
        }
      }
      const targetSubnet = netOf(to);
      if (targetSubnet === rightSubnet) {
        if (to !== rightAddress) {
          throw new Error(`router: no host at ${to} in subnet ${rightSubnet}`);
        }
        routed += 1;
        lastFrame = `${from} -> ${to} | ${request} (one router hop via ${leftAddress})`;
        return {
          from,
          to,
          via: leftAddress,
          request,
          isYou,
          routed: true,
          response: `200 router ${rightAddress} — subnet ${rightSubnet} edge (CDN edge arrives in Stage 6b)`,
        };
      }
      if (targetSubnet === leftSubnet) {
        routed += 1;
        lastFrame = `${from} -> ${to} | ${request} (one router hop via ${rightAddress})`;
        return leftNetwork.send({ from, to, request });
      }
      throw new Error(
        `router: subnet ${targetSubnet} is not attached to ${leftAddress} / ${rightAddress}`,
      );
    },

    // CHECKS: queue deliveries across the join fail loud in Stage 6a —
    // nothing in subnet 20 accepts a queued request until Stage 6b seats the
    // CDN edge at 20.1.
    routeQueue({ to }) {
      throw new Error(
        `router: nothing queues at ${to} in subnet ${netOf(to)} yet (Stage 6b adds the CDN edge)`,
      );
    },

    snapshot() {
      return { leftAddress, rightAddress, routed, lastFrame };
    },
  };
}
