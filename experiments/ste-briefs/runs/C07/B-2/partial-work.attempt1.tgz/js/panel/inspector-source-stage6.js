// DOCUMENTS: the Stage 6 inspector code entries — a readable, hand-edited
// mirror of js/sim/dns.js and js/sim/router.js (js/sim is the executable
// truth). Split from inspector-source.js by responsibility
// (guard-file-size); that file spreads these into COMPONENT_SOURCE.
export const DNS_ROUTER_SOURCE = {
  dns: {
    file: 'js/sim/dns.js',
    code: `createDns({ address = '10.60', ttlTicks = 300 } = {}) {
  // address must be "<net>.<host>" — a two-number mini-IP
  const AUTHORITATIVE = { 'example.com': '10.1' };  // 6b adds the CDN name
  const entries = new Map(); // name -> { target, cachedAtTick, expiresAtTick }
  let lookups = 0, cachedHits = 0, authoritative = 0, lastReply = null;
  function evictExpired(currentTick = 0) {
    for (const entry of entries.values()) {
      if (currentTick >= entry.expiresAtTick) entries.delete(entry.name);
    }
  }
  function lookup(name, currentTick = 0) {
    lookups += 1;
    evictExpired(currentTick);
    const entry = entries.get(name);
    if (entry) {  // ledger branch: no authoritative consult
      cachedHits += 1;
      lastReply = { name, status: 'HIT', target: entry.target, atTick: currentTick };
      return { status: 'HIT', name, target: entry.target };
    }
    authoritative += 1;  // miss, expired entry, or unknown name
    const target = AUTHORITATIVE[name] ?? null;
    if (target === null) {  // NX: a status, not a throw — the browser
      lastReply = { name, status: 'NX', target: null, atTick: currentTick };  // renders the NX card
      return { status: 'NX', name };
    }
    entries.set(name, { name, target,
      cachedAtTick: currentTick, expiresAtTick: currentTick + ttlTicks });
    lastReply = { name, status: 'AUTH', target, atTick: currentTick };
    return { status: 'AUTH', name, target };
  }
  function snapshot(currentTick = 0) {
    evictExpired(currentTick);
    return { address, ttlTicks, lookups, cachedHits, authoritative, lastReply,
      cache: [...entries.values()].map((e) => ({ ...e,
        ttlRemaining: e.expiresAtTick - currentTick })) };
  }
  return { address, evictExpired, lookup, snapshot };
}`,
  },
  router: {
    file: 'js/sim/router.js',
    code: `createRouter({ leftAddress = '10.65', rightAddress = '20.1',
  leftNetwork, rightNetwork } = {}) {
  // interfaces must be "<net>.<host>" mini-IPs on different subnets
  const leftSubnet = leftAddress.split('.')[0];
  const rightSubnet = rightAddress.split('.')[0];
  let routed = 0;
  let lastFrame = null;
  return {
    servesSubnet(subnet) { return subnet === leftSubnet || subnet === rightSubnet; },
    // one router hop across the join; isYou rides through
    route({ from, to, request, isYou = false }) {
      const targetSubnet = to.split('.')[0];
      if (targetSubnet === rightSubnet) {
        if (to !== rightAddress) throw new Error(\`no host at \${to} in subnet \${rightSubnet}\`);
        routed += 1;
        lastFrame = \`\${from} -> \${to} | \${request} (one router hop via \${leftAddress})\`;
        return { from, to, via: leftAddress, request, isYou, routed: true,
          response: \`200 router \${rightAddress} — subnet \${rightSubnet} edge\` };
      }
      if (targetSubnet === leftSubnet) {  // reverse direction
        routed += 1;
        lastFrame = \`\${from} -> \${to} | \${request} (one router hop via \${rightAddress})\`;
        return leftNetwork.send({ from, to, request });
      }
      throw new Error(\`subnet \${targetSubnet} is not attached\`);
    },
    routeQueue({ to }) {  // nothing queues across the join until Stage 6b
      throw new Error(\`nothing queues at \${to} in subnet \${to.split('.')[0]} yet\`);
    },
    snapshot() { return { leftAddress, rightAddress, routed, lastFrame }; },
  };
}`,
  },
};
