// DOCUMENTS: DOM the panel page cannot hold — panel.html sits at its
// 550-line cap, so this module builds the inspector tab row and the Stage 6
// inspector-canvas cards (#node-dns, #node-router) in JS. Structure reuses
// the node-card / comp-tab patterns from DESIGN.md; behavior stays in
// panel.js's addEventListener wiring, all content via textContent — no
// inline handlers, no inline styles (CSP rule).
const TAB_KEYS = [
  'browser',
  'network',
  'loadbalancer',
  'webserver',
  'cache',
  'database',
  'workerqueue',
  'dns',
  'router',
];

export function initStage6Nodes() {
  const world = document.getElementById('orrery-world');
  if (!world) throw new Error('stage6-nodes: #orrery-world is required');

  const dnsCard = document.createElement('article');
  dnsCard.className = 'node-card';
  dnsCard.id = 'node-dns';
  dnsCard.dataset.testid = 'node-dns';
  dnsCard.dataset.component = 'dns';
  dnsCard.hidden = true; // revealed by renderStageTopology on stage >= 6

  const dnsHead = document.createElement('header');
  dnsHead.className = 'node-head';
  const dnsName = document.createElement('div');
  dnsName.className = 'node-name';
  const dnsRole = document.createElement('span');
  dnsRole.className = 'role-name';
  dnsRole.textContent = 'DNS';
  const dnsSub = document.createElement('span');
  dnsSub.className = 'node-subtitle';
  dnsSub.textContent = 'resolver ledger';
  dnsName.replaceChildren(dnsRole, dnsSub);
  const dnsChip = document.createElement('span');
  dnsChip.className = 'ip-chip';
  dnsChip.textContent = '10.60';
  const dnsCode = document.createElement('span');
  dnsCode.className = 'code-chip';
  dnsCode.textContent = '</> Code';
  dnsHead.replaceChildren(dnsName, dnsChip, dnsCode);

  const dnsStats = document.createElement('p');
  dnsStats.id = 'dns-stats';
  dnsStats.dataset.testid = 'dns-stats';
  dnsStats.className = 'mono last-frame';
  dnsStats.textContent = 'Lookups: 0 · Cached hits: 0 · Authority: 0 · TTL: 300t';

  const dnsList = document.createElement('ul');
  dnsList.id = 'dns-entries-list';
  dnsList.dataset.testid = 'dns-entries-list';
  dnsList.className = 'route-list';
  dnsList.setAttribute('aria-label', 'Resolver ledger');

  dnsCard.replaceChildren(dnsHead, dnsStats, dnsList);

  const routerCard = document.createElement('article');
  routerCard.className = 'node-card';
  routerCard.id = 'node-router';
  routerCard.dataset.testid = 'node-router';
  routerCard.dataset.component = 'router';
  routerCard.hidden = true;

  const routerHead = document.createElement('header');
  routerHead.className = 'node-head';
  const routerName = document.createElement('div');
  routerName.className = 'node-name';
  const routerRole = document.createElement('span');
  routerRole.className = 'role-name';
  routerRole.textContent = 'Router';
  const routerSub = document.createElement('span');
  routerSub.className = 'node-subtitle';
  routerSub.textContent = 'cross-subnet join';
  routerName.replaceChildren(routerRole, routerSub);
  const routerChip = document.createElement('span');
  routerChip.className = 'ip-chip';
  routerChip.textContent = '10.65 ⇄ 20.1';
  const routerCode = document.createElement('span');
  routerCode.className = 'code-chip';
  routerCode.textContent = '</> Code';
  routerHead.replaceChildren(routerName, routerChip, routerCode);

  const routerStats = document.createElement('p');
  routerStats.id = 'router-stats';
  routerStats.dataset.testid = 'router-stats';
  routerStats.className = 'mono last-frame';
  routerStats.textContent = 'Routed: 0 · 10.65 ⇄ 20.1';

  routerCard.replaceChildren(routerHead, routerStats);

  // The full inspector tab row — one button per selectable component,
  // including the Stage 6 dns/router pair.
  const tabs = document.querySelector('.comp-tabs');
  for (const key of TAB_KEYS) {
    const tab = document.createElement('button');
    tab.className = 'comp-tab';
    tab.type = 'button';
    tab.dataset.select = key;
    tab.textContent = key;
    tabs.append(tab);
  }

  world.append(dnsCard, routerCard);
}
