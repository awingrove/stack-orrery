// DOCUMENTS: the bottom inspector's code side for the core components — a
// readable, hand-edited mirror of each sim component's real implementation
// (js/sim/* is the executable truth; this module renders the same logic for
// learners). The back-tier mirrors (Cache, Database, WorkerQueue, DNS,
// Router) live in inspector-source-tiers.js, merged into COMPONENT_SOURCE
// below; the live-state builders and their JSON formatting live in
// inspector-state.js (split by responsibility, guard-file-size), which also
// builds the per-snapshot inspector headline in componentTitle — this file
// keeps only the static file/code entries, no per-stage address pins.
import { TIER_SOURCE } from './inspector-source-tiers.js';

const CORE_SOURCE = {
  browser: {
    file: 'js/sim/browser.js',
    code: `createBrowser({ name, address, network }) {
  // address must be "<net>.<host>" — a two-number mini-IP
  let lastDisplay = null;
  return {
    createRequest(path = '/', method = 'GET') { return \`\${method} \${path}\`; },
    parseResponse(raw) {  // slim HTTP: no version, no headers
      const [statusToken, ...body] = String(raw).trim().split(' ');
      return { status: Number(statusToken), body: body.join(' ') };
    },
    // render an arriving wire record: parse and store viewport state
    receiveResponse({ from, to, request, response }) {
      lastDisplay = { from, to, request, response, ...this.parseResponse(response) };
      return lastDisplay;
    },
    get(targetAddress, path = '/', method = 'GET') {
      const request = this.createRequest(path, method);
      const { response } = network.send({ from: address, to: targetAddress, request });
      return this.receiveResponse({ from: address, to: targetAddress, request, response });
    },
    last() { return lastDisplay; },
  };
}`,
  },
  network: {
    file: 'js/sim/network.js',
    title: 'Network — routing fabric',
    code: `createNetwork() {
  const servers = new Map();
  let gateway = null;  // Stage 6: the Router attaches as the only
                       // inter-subnet gateway (router.js)
  function resolve(address) {
    if (!/^\\d+\\.\\d+$/.test(address)) throw new Error(\`invalid mini-IP \${address}\`);
    const server = servers.get(address);
    if (!server) throw new Error(\`no server at \${address}\`);
    return server;
  }
  return {
    registerServer(address, server) { servers.set(address, server); },
    attachGateway(attached) { gateway = attached; },
    // same-subnet: request in, response out; a far-subnet destination
    // takes exactly one router hop through the gateway
    send({ from, to, request }) {
      if (gateway && gateway.handles(to)) return gateway.forward({ from, to, request });
      return { from, to, request, response: resolve(to).handleRequest(request) };
    },
    deliverToQueue({ id, from, to, request, atTick, isYou = false }) {
      resolve(to).enqueue({ id, from, to, request, atTick, isYou });
    },
  };
}`,
  },
  loadbalancer: {
    file: 'js/sim/loadbalancer.js',
    code: `createLoadBalancer({ address = '10.1', backends = ['10.11', '10.12'], network }) {
  const pool = [...backends];
  const perBackend = Object.fromEntries(pool.map((b) => [b, 0]));
  let nextIndex = 0;
  let forwarded = 0;
  let lastTarget = null;
  function selectBackend() {
    const target = pool[nextIndex];
    nextIndex = (nextIndex + 1) % pool.length;
    forwarded += 1;
    perBackend[target] += 1;
    lastTarget = target;
    return target;
  }
  return {
    nextBackend() { return pool[nextIndex]; },
    handleRequest(request = 'GET /') {
      return network.send({ from: address, to: selectBackend(), request }).response;
    },
    enqueue({ id, atTick, from = '10.2', request = 'GET /', isYou = false }) {
      const target = selectBackend();
      network.deliverToQueue({ id, from, to: target, request, atTick, isYou });
      return target;
    },
  };
}`,
  },
  webserver: {
    file: 'js/sim/webserver.js',
    code: `createWebServer({ address = '10.1', serviceRate = 4, files = DEFAULT_FILES,
  cache = null, database = null } = {}) {
  const fs = new Map(Object.entries(files)); // '/' and '/about' on disk
  let queue = [];      // FIFO; work budget serviceRate * 2 per step()
  let served = 0;
  function matchRoute(request = 'GET /') {
    const [method, ...rest] = String(request).trim().split(' ');
    const path = rest[0] ?? '';
    let response;
    let routeId = null;
    if (method !== 'GET') response = '405 Only GET requests are supported';
    else if (fs.has(path)) {
      response = \`200 \${fs.get(path)}\`;
      routeId = path === '/' ? 'route-home' : \`route-\${path.slice(1)}\`;
    } else response = '404 Page not found';
    const [statusToken, ...body] = response.split(' ');
    return { response, status: Number(statusToken), body: body.join(' '), routeId };
  }
  function enqueue({ id, atTick, from = '10.2', to = address, request = 'GET /', isYou = false }) {
    queue.push({ id, atTick, from, to, request, isYou });
  }
  function handleRequest(request = 'GET /') { return matchRoute(request).response; }
  function resolveRequest(request = 'GET /', currentTick = 0) {
    const { method, path } = parseRequest(request);
    if (method === 'GET' && cache) {
      const cached = cache.get(path, currentTick);
      if (cached) return { response: \`200 \${cached}\`, cacheStatus: 'HIT' };
    }
    if (database && method === 'POST') {
      const written = database.write(path, \`Updated \${path} at tick \${currentTick}\`, currentTick);
      cache?.del(path);  // write-through: drop the cached copy
      return { response: \`200 \${written.value}\`, cacheStatus: 'INVALIDATE',
        dbOp: 'WRITE', dbTarget: database.primaryAddress, dbStale: false };
    }
    // cache MISS: read the replica (Stage 4) or the filesystem (Stage 3).
    const row = database ? database.read(path, currentTick) : null;
    if (row && row.found) {
      if (!row.stale) cache?.set(path, row.value, currentTick);
      return { response: \`200 \${row.value}\`, cacheStatus: 'MISS',
        dbOp: 'SELECT', dbTarget: database.replicaAddress, dbStale: row.stale };
    }
    const matched = matchRoute(request);
    if (matched.status === 200) cache?.set(path, matched.body, currentTick);
    return { ...matched, cacheStatus: 'MISS' };
  }
  function step(currentTick) {
    const budget = cache || database ? serviceRate * 2 : serviceRate;
    // ... drain the queue up to the work budget, resolving each request
    return queue.splice(0, budget).map((r) => ({ ...r, ...resolveRequest(r.request, currentTick),
      latencyTicks: currentTick - r.atTick + 1 }));
  }
  return { address, matchRoute, handleRequest, resolveRequest, enqueue, step };
}`,
  },
};

// COMPONENT_SOURCE: the full inspector registry — core components here,
// back-tier components (cache, database, workerqueue, dns, router) merged
// in from inspector-source-tiers.js.
export const COMPONENT_SOURCE = { ...CORE_SOURCE, ...TIER_SOURCE };
