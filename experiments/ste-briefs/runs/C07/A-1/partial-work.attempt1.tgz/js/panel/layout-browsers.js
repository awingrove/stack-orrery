// DOCUMENTS: the addressable browser ring — slot geometry for the outer
// client ring, split from layout.js by responsibility (guard-file-size).
// Slot 0 (mini-IP 10.2) owns the 180° expanded-#node-browser spot; slots
// 1 .. users-1 (10.3 .. 10.(users + 1)) take the satellite arcs. Pure
// math in, coordinates out — no DOM here.
export function computeSatellites(count, outerRadius) {
  const arcCount = Math.max(0, Math.round(count));
  const leftCount = Math.ceil(arcCount / 2);
  const rightCount = arcCount - leftCount;
  const satellites = [];
  const place = (n, startAngle) => {
    for (let j = 0; j < n; j += 1) {
      const angleDeg = startAngle + ((j + 1) / (n + 1)) * 37;
      const rad = (angleDeg * Math.PI) / 180;
      satellites.push({
        index: satellites.length,
        x: Math.round(outerRadius * Math.cos(rad)),
        y: Math.round(outerRadius * Math.sin(rad)),
        angleDeg,
      });
    }
  };
  place(leftCount, 135);
  place(rightCount, 188);
  return satellites;
}

// CHECKS: the expanded browser must sit exactly on its own slot (180° for
// the default 10.2) so #node-browser and its wires re-anchor with it.
export function computeBrowserRing(users = 5, outerRadius, activeBrowser = '10.2') {
  const browserCount = Math.max(0, Math.round(users));
  const walkArcs = computeSatellites(Math.max(0, browserCount - 1), outerRadius);
  const browserSlots = Array.from({ length: browserCount }, (_, i) => {
    if (i === 0)
      return { index: 0, address: '10.2', angleDeg: 180, ...polar(outerRadius, 180) };
    return { index: i, address: `10.${i + 2}`, ...walkArcs[i - 1] };
  });
  const activeSlot =
    browserSlots.find((slot) => slot.address === String(activeBrowser)) ?? {
      index: 0,
      address: '10.2',
      angleDeg: 180,
      ...polar(outerRadius, 180),
    };
  return {
    browserSlots,
    activeSlot,
    satellites: browserSlots.map(({ index, x, y, angleDeg }) => ({ index, x, y, angleDeg })),
  };
}

function polar(radius, angleDeg) {
  const rad = (angleDeg * Math.PI) / 180;
  return { x: Math.round(radius * Math.cos(rad)), y: Math.round(radius * Math.sin(rad)) };
}
