// DOCUMENTS: the bottom inspector's code mirrors for the back-tier
// components (Cache, Database, WorkerQueue, and the Stage 6 DNS resolver
// and cross-subnet Router) — a readable, hand-edited mirror of each sim
// component's real implementation (js/sim/* is the executable truth; this
// module renders the same logic for learners). The core components'
// mirrors live in inspector-source.js, which merges this map into
// COMPONENT_SOURCE; the live-state builders live in inspector-state.js.
export const TIER_SOURCE = {
  cache: {
    file: 'js/sim/cache.js',
    code: `createCache({ address = '10.20', ttlTicks = 10 } = {}) {
  // address must be "<net>.<host>" — a two-number mini-IP
  const entries = new Map(); // path -> { value, cachedAtTick, expiresAtTick }
  let hits = 0, misses = 0, sets = 0, evictions = 0, lastLookup = null;
  function evictExpired(currentTick = 0) {
    for (const entry of entries.values()) {
      if (currentTick >= entry.expiresAtTick) {  // TTL elapsed
        entries.delete(entry.key);
        evictions += 1;
      }
    }
  }
  function has(key, currentTick = 0) {
    evictExpired(currentTick);
    return entries.has(key);
  }
  function get(key, currentTick = 0) {
    evictExpired(currentTick);
    const entry = entries.get(key);
    if (entry) {
      hits += 1;
      lastLookup = { key, status: 'HIT', atTick: currentTick };
      return entry.value;
    }
    misses += 1;
    lastLookup = { key, status: 'MISS', atTick: currentTick };
    return null;
  }
  function set(key, value, currentTick = 0) {
    entries.set(key, { key, value, cachedAtTick: currentTick,
      expiresAtTick: currentTick + ttlTicks });
    sets += 1;
  }
  function del(key) {  // Stage 4: write-through invalidation
    return entries.delete(key);
  }
  function snapshot(currentTick = 0) {
    evictExpired(currentTick);
    return { address, ttlTicks, hits, misses, sets, evictions, lastLookup,
      entries: [...entries.values()].map((e) => ({ ...e,
        ttlRemaining: e.expiresAtTick - currentTick })) };
  }
  return { address, evictExpired, has, get, set, del, snapshot };
}`,
  },
  database: {
    file: 'js/sim/database.js',
    code: `createDatabase({ primaryAddress = '10.30', replicaAddress = '10.31',
  replicationLagTicks = 3, rows = DEFAULT_ROWS } = {}) {
  // addresses must be "<net>.<host>" — two-number mini-IPs
  const primary = new Map();   // key -> { key, value, version, updatedAtTick }
  const replica = new Map();   // same shape; serves all reads
  const replicationQueue = []; // FIFO { key, value, version, writtenAtTick, applyAtTick }
  let reads = 0, writes = 0, staleReads = 0, replicated = 0, lastOp = null;
  function stepReplication(currentTick = 0) {
    // oldest pending write first; applies once its applyAtTick arrives
    while (replicationQueue.length > 0 && currentTick >= replicationQueue[0].applyAtTick) {
      const entry = replicationQueue.shift();
      replica.set(entry.key, { key: entry.key, value: entry.value,
        version: entry.version, updatedAtTick: entry.applyAtTick });
      replicated += 1;
    }
  }
  function read(key, currentTick = 0) {   // always the replica
    stepReplication(currentTick);
    reads += 1;
    const replicaRow = replica.get(key) ?? null;
    const primaryRow = primary.get(key) ?? null;
    const stale = Boolean(primaryRow &&
      (!replicaRow || replicaRow.version < primaryRow.version));
    if (stale) staleReads += 1;
    lastOp = { op: 'SELECT', target: replicaAddress, key, found: Boolean(replicaRow),
      stale, atTick: currentTick };
    return { found: Boolean(replicaRow), value: replicaRow ? replicaRow.value : null,
      version: replicaRow ? replicaRow.version : 0, stale, source: replicaAddress };
  }
  function write(key, value, currentTick = 0) {  // always the primary
    stepReplication(currentTick);
    writes += 1;
    const version = (primary.get(key)?.version ?? 0) + 1;
    const applyAtTick = currentTick + replicationLagTicks;
    primary.set(key, { key, value, version, updatedAtTick: currentTick });
    replicationQueue.push({ key, value, version, writtenAtTick: currentTick, applyAtTick });
    lastOp = { op: 'WRITE', target: primaryAddress, key, version, applyAtTick, atTick: currentTick };
    return { key, value, version, applyAtTick, source: primaryAddress };
  }
  function snapshot(currentTick = 0) {
    stepReplication(currentTick);
    return { primaryAddress, replicaAddress, replicationLagTicks, reads, writes,
      staleReads, replicated, lastOp, pendingReplication: replicationQueue.length };
  }
  return { stepReplication, read, write, snapshot };
}`,
  },
  workerqueue: {
    file: 'js/sim/queue.js',
    code: `createWorkerQueue({ address = '10.40', workerAddress = '10.41', jobDurationTicks = 2 } = {}) {
  let jobs = [];
  let enqueued = 0;
  let completed = 0;
  let activeJob = null;
  function enqueue(path, payload, currentTick = 0) {
    const jobId = nextJobId++;
    enqueued += 1;
    const job = { jobId, path, payload, status: 'queued', queuedAtTick: currentTick };
    jobs.push(job);
    return job;
  }
  function step(database, currentTick = 0) {
    if (activeJob && currentTick >= activeJob.finishesAtTick) {
      database?.write(activeJob.path, activeJob.payload, currentTick);
      completed += 1;
      activeJob = null;
    }
    if (!activeJob && jobs.length > 0) {
      const job = jobs.shift();
      activeJob = { ...job, status: 'active', startedAtTick: currentTick, finishesAtTick: currentTick + jobDurationTicks };
    }
  }
  return { enqueue, step, snapshot };
}`,
  },
  dns: {
    file: 'js/sim/dns.js',
    code: `createDns({ address = '10.60', ttlTicks = 300 } = {}) {
  // address must be "<net>.<host>" — a two-number mini-IP
  const records = new Map([['example.com', '10.1']]); // authoritative table
  const ledger = new Map();  // name -> { name, target, expiresAtTick }
  let lookups = 0, cachedHits = 0, authoritative = 0, lastLookup = null;
  function lookup(name, currentTick = 0) {
    lookups += 1;
    const entry = ledger.get(name);
    if (entry && currentTick < entry.expiresAtTick) {
      // live ledger entry: answer without consulting the table
      cachedHits += 1;
      lastLookup = { name, status: 'HIT', target: entry.target, atTick: currentTick };
      return { status: 'OK', target: entry.target, cacheStatus: 'HIT' };
    }
    if (entry) ledger.delete(name);  // expired: never answered from the ledger
    authoritative += 1;
    const target = records.get(name) ?? null;
    if (target === null) {
      lastLookup = { name, status: 'NX', atTick: currentTick };
      return { status: 'NX' };  // unknown name: NX, not a throw
    }
    ledger.set(name, { name, target, expiresAtTick: currentTick + ttlTicks });
    lastLookup = { name, status: 'MISS', target, atTick: currentTick };
    return { status: 'OK', target, cacheStatus: 'MISS' };
  }
  function snapshot(currentTick = 0) {
    return { address, ttlTicks, lookups, cachedHits, authoritative, lastLookup,
      cache: [...ledger.values()].filter((e) => currentTick < e.expiresAtTick)
        .map((e) => ({ ...e, ttlRemaining: e.expiresAtTick - currentTick })) };
  }
  return { address, lookup, snapshot };
}`,
  },
  router: {
    file: 'js/sim/router.js',
    code: `createRouter({ leftAddress = '10.65', rightAddress = '20.1' } = {}) {
  // both interfaces must be "<net>.<host>" mini-IPs on different subnets
  const leftNet = leftAddress.split('.')[0];
  const rightNet = rightAddress.split('.')[0];
  let routed = 0, lastHop = null, leftNetwork = null, rightNetwork = null;
  function forward({ from, to, request }) {  // one cross-subnet hop
    const toNet = String(to).split('.')[0];
    const far = toNet === rightNet ? rightNetwork : toNet === leftNet ? leftNetwork : null;
    if (!far) throw new Error(\`router: no route to \${to}\`);
    routed += 1;
    const via = toNet === rightNet ? rightAddress : leftAddress;
    lastHop = { from, via, to, request };
    return { from, to, request, response: far.send({ from: via, to, request }).response };
  }
  return {
    leftAddress, rightAddress,
    join(left, right) {  // attach as each network's only inter-subnet gateway
      leftNetwork = left; rightNetwork = right;
      left.attachGateway({ handles: (to) => String(to).split('.')[0] === rightNet, forward });
      right.attachGateway({ handles: (to) => String(to).split('.')[0] === leftNet, forward });
    },
    handleRequest() { return \`200 Router at \${rightAddress}\`; },
    snapshot() { return { leftAddress, rightAddress, routed, lastHop }; },
  };
}`,
  },
};
