// DOCUMENTS: stage-shape DOM writes, split from render.js by
// responsibility (guard-file-size): which cards and wire lanes are visible
// per stage, which card and wire lane carries the active hop, the crowd
// dots, and the compact browser nodes on the outer client ring. Zero
// engine knowledge: snapshots and layout geometry in, DOM writes out.
const $ = (id) => document.getElementById(id);

const LANES = {
  'packet-req-left': $('packet-req-left'),
  'packet-res-left': $('packet-res-left'),
  'packet-req-right': $('packet-req-right'),
  'packet-res-right': $('packet-res-right'),
  'packet-req-lb': $('packet-req-lb'),
  'packet-res-lb': $('packet-res-lb'),
  'packet-req-cache': $('packet-req-cache'),
  'packet-res-cache': $('packet-res-cache'),
  'packet-req-db': $('packet-req-db'),
  'packet-res-db': $('packet-res-db'),
  'packet-req-queue': $('packet-req-queue'),
  'packet-res-queue': $('packet-res-queue'),
  'packet-req-worker': $('packet-req-worker'),
  'packet-res-worker': $('packet-res-worker'),
};

// Stage-switch hook: viewport.js registers a callback so camera + world
// layout resync the moment the topology toggles.
let stageRenderedHook = null;

export function onStageRendered(fn) {
  stageRenderedHook = fn;
}

export function renderStageTopology(stage) {
  const hasLb = stage >= 2;
  const hasCache = stage >= 3;
  const hasDb = stage >= 4;
  const hasWorkers = stage === 5;
  const hasDns = stage >= 6;
  $('node-lb').hidden = !hasLb;
  $('wire-lb-backends').hidden = !hasLb;
  $('node-webserver-2').hidden = !hasLb;
  $('node-cache').hidden = !hasCache;
  $('wire-servers-cache').hidden = !hasCache;
  $('node-db').hidden = !hasDb;
  $('wire-cache-db').hidden = !hasDb;
  $('node-queue').hidden = !hasWorkers;
  $('wire-cache-queue').hidden = !hasWorkers;
  $('node-worker').hidden = !hasWorkers;
  $('wire-queue-worker').hidden = !hasWorkers;
  // Stage 6: the DNS resolver card on Ring 7 and the cross-subnet Router
  // side-card beside the 10.x hub on Ring 6 (the network table rows are
  // snapshot-derived in render.js).
  $('node-dns').hidden = !hasDns;
  $('node-router').hidden = !hasDns;
  for (const pill of document.querySelectorAll('.stage-pill[data-stage]')) {
    const active = Number(pill.dataset.stage) === stage;
    pill.classList.toggle('active-stage', active);
    if (active) pill.setAttribute('aria-current', 'true');
    else pill.removeAttribute('aria-current');
  }
  if (stageRenderedHook) stageRenderedHook(stage);
}

// Which card executes the hop, and which wire lane carries it:
// Stage 1 is emit / route / serve / render; Stage 2 inserts the LB's
// round-robin pick; Stage 3 splits the backend serve into the cache
// lookup (Cache 10.20 answers) and the response emission; Stage 4 adds
// the database hop; Stage 5 adds async worker queue processing.
function stage5Target(snapshot, hop) {
  if (snapshot.stage === 6 || snapshot.stage === 5) {
    // Async POST /jobs walks browser -> lb -> enqueue -> 202 -> worker
    // commit; every other request keeps the Stage 4 cache/db story and the
    // worker reads idle on the tail hop.
    const backendCard =
      snapshot.trace?.targetServer === '10.12' ? 'node-webserver-2' : 'node-webserver';
    const dbLane = snapshot.trace?.dbOp === 'WRITE' ? 'packet-req-db' : 'packet-res-db';
    const owners = snapshot.trace?.asyncJob
      ? {
          1: 'node-browser',
          2: 'node-network',
          3: 'node-lb',
          4: 'node-queue',
          5: 'node-webserver',
          6: 'node-network',
          7: 'node-browser',
          8: 'node-worker',
        }
      : {
          1: 'node-browser',
          2: 'node-network',
          3: 'node-lb',
          4: 'node-db',
          5: backendCard,
          6: 'node-network',
          7: 'node-browser',
          8: 'node-worker',
        };
    const lanes = snapshot.trace?.asyncJob
      ? {
          1: 'packet-req-left',
          2: 'packet-req-right',
          3: 'packet-req-lb',
          4: 'packet-req-queue',
          5: 'packet-res-cache',
          6: 'packet-res-right',
          7: 'packet-res-left',
          8: 'packet-res-db',
        }
      : {
          1: 'packet-req-left',
          2: 'packet-req-right',
          3: 'packet-req-lb',
          4: dbLane,
          5: 'packet-res-cache',
          6: 'packet-res-right',
          7: 'packet-res-left',
          8: 'packet-res-worker',
        };
    return { cardId: owners[hop] ?? 'node-browser', laneId: lanes[hop] ?? 'packet-req-left' };
  }
}

// Stage 6 branches on host syntax: a hosted path puts the DNS card on the
// ask and answer hops (the browser↔DNS wire carries no lane chip) and the
// chain hops 4-10 repeat the Stage 5 owners two hops later; a host-less
// path and the NX path end with the browser card.
function activeHopTarget(snapshot) {
  const hop = snapshot.trace?.hop ?? 0;
  if (snapshot.stage === 6) {
    const t = snapshot.trace ?? {};
    if (t.status === 'NX') {
      const owners = { 1: 'node-browser', 2: 'node-dns', 3: 'node-dns', 4: 'node-browser' };
      return { cardId: owners[hop] ?? 'node-browser', laneId: hop > 1 && hop < 4 ? null : 'packet-req-left' };
    }
    if (t.host) {
      if (hop === 2 || hop === 3) return { cardId: 'node-dns', laneId: null };
      // Hosted chain hops 4-10 repeat the Stage 5 owners/lanes at hop - 2.
      return stage5Target(snapshot, hop - 2);
    }
  }
  // A Stage 6 host-less trace keeps the Stage 5 card-for-card story.
  const stageShape = snapshot.stage === 6 ? 5 : snapshot.stage;
  if (stageShape === 5) return stage5Target(snapshot, hop);
  return stageNTarget(snapshot, hop, stageShape);
}

function stageNTarget(snapshot, hop, stage) {
  if (stage === 4) {
    const backendCard =
      snapshot.trace?.targetServer === '10.12' ? 'node-webserver-2' : 'node-webserver';
    const dbLane = snapshot.trace?.dbOp === 'WRITE' ? 'packet-req-db' : 'packet-res-db';
    const owners = {
      1: 'node-browser',
      2: 'node-network',
      3: 'node-lb',
      4: 'node-cache',
      5: 'node-db',
      6: backendCard,
      7: 'node-browser',
    };
    const lanes = {
      1: 'packet-req-left',
      2: 'packet-req-right',
      3: 'packet-req-lb',
      4: 'packet-req-cache',
      5: dbLane,
      6: 'packet-res-cache',
      7: 'packet-res-left',
    };
    return { cardId: owners[hop], laneId: lanes[hop] };
  }
  if (stage === 3) {
    const backendCard =
      snapshot.trace?.targetServer === '10.12' ? 'node-webserver-2' : 'node-webserver';
    const owners = {
      1: 'node-browser',
      2: 'node-network',
      3: 'node-lb',
      4: 'node-cache',
      5: backendCard,
      6: 'node-browser',
    };
    const lanes = {
      1: 'packet-req-left',
      2: 'packet-req-right',
      3: 'packet-req-lb',
      4: 'packet-req-cache',
      5: 'packet-res-cache',
      6: 'packet-res-left',
    };
    return { cardId: owners[hop], laneId: lanes[hop] };
  }
  if (stage === 2) {
    const backendCard =
      snapshot.trace?.targetServer === '10.12' ? 'node-webserver-2' : 'node-webserver';
    const owners = {
      1: 'node-browser',
      2: 'node-network',
      3: 'node-lb',
      4: backendCard,
      5: 'node-browser',
    };
    const lanes = {
      1: 'packet-req-left',
      2: 'packet-req-right',
      3: 'packet-req-lb',
      4: 'packet-res-lb',
      5: 'packet-res-left',
    };
    return { cardId: owners[hop], laneId: lanes[hop] };
  }
  const owners = { 1: 'node-browser', 2: 'node-network', 3: 'node-webserver', 4: 'node-browser' };
  const lanes = {
    1: 'packet-req-left',
    2: 'packet-req-right',
    3: 'packet-res-right',
    4: 'packet-res-left',
  };
  return { cardId: owners[hop], laneId: lanes[hop] };
}

export function renderHopHighlights(snapshot, selectedComponent) {
  const { cardId, laneId } = activeHopTarget(snapshot);
  for (const card of document.querySelectorAll('.node-card')) {
    card.classList.toggle('active-hop', card.id === cardId);
    card.classList.toggle('selected-node', card.dataset.component === selectedComponent);
  }
  for (const [id, node] of Object.entries(LANES)) {
    node.classList.toggle('lane-active', id === laneId);
  }
}

export function renderDots(n) {
  $('user-dots').replaceChildren(
    ...Array.from({ length: n }, () => {
      const dot = document.createElement('span');
      dot.className = 'user-dot';
      return dot;
    }),
  );
}

// CHECKS: compact outer-ring browser nodes rebuild from the layout's
// browser slots so a re-spaced or re-populated ring leaves no stale or
// ghost buttons behind.
export function renderRingBrowsers(slots, activeAddress) {
  const ring = $('browser-ring-nodes');
  if (!ring) return;
  ring.replaceChildren(
    ...slots
      .filter((slot) => slot.address !== activeAddress)
      .map((slot) => {
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'browser-compact';
        button.dataset.testid = `browser-node-${slot.address}`;
        button.dataset.address = slot.address;
        button.style.left = `${slot.x}px`;
        button.style.top = `${slot.y}px`;
        const chip = document.createElement('span');
        chip.className = 'ip-chip';
        chip.textContent = slot.address;
        const status = document.createElement('span');
        status.className = 'browser-compact-status';
        status.textContent = slot.lastDisplay ? String(slot.lastDisplay.status) : 'idle';
        button.replaceChildren(chip, status);
        return button;
      }),
  );
}
