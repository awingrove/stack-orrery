// DOCUMENTS: the Stage 6 component — a DNS resolver with a tick-TTL ledger,
// mirroring the Cache's tick-based TTL pattern (cache.js). The authoritative
// table is in-component (`example.com -> 10.1`; Stage 6b adds a CDN name),
// and `lookup(name, currentTick)` is a real Map lookup on the request path,
// never a probability: a live entry answers from the ledger without
// consulting the table, an expired entry is dropped and re-consulted, and an
// unknown name answers `NX no record` — the browser renders the NX card; no
// GET is ever emitted for it. Deterministic by construction: no clock, no
// RNG — time arrives as the `currentTick` argument.
//
// CHECKS: the constructor rejects an address that is not a two-number
// mini-IP and a ttlTicks that is not a positive integer (fail-loud over
// silent mis-configuration).
export function createDns({ address = '10.60', ttlTicks = 300 } = {}) {
  if (!/^\d+\.\d+$/.test(address)) {
    throw new Error(`dns: invalid mini-IP address ${address}`);
  }
  if (!Number.isInteger(ttlTicks) || ttlTicks < 1) {
    throw new Error(`dns: ttlTicks must be a positive integer, got ${ttlTicks}`);
  }
  // Authoritative table: name -> mini-IP. Stage 6b adds the CDN name here.
  const records = new Map([['example.com', '10.1']]);
  const ledger = new Map(); // name -> { name, target, expiresAtTick }
  let lookups = 0;
  let cachedHits = 0;
  let authoritative = 0;
  let lastLookup = null;

  function lookup(name, currentTick = 0) {
    lookups += 1;
    const entry = ledger.get(name);
    // PINS: a hit inside ttlTicks increments cachedHits and never consults
    // the authoritative table; an expired entry is dropped, never answered
    // from the ledger (test/sim/dns.test.js).
    if (entry && currentTick < entry.expiresAtTick) {
      cachedHits += 1;
      lastLookup = { name, status: 'HIT', target: entry.target, atTick: currentTick };
      return { status: 'OK', target: entry.target, cacheStatus: 'HIT' };
    }
    if (entry) ledger.delete(name);
    authoritative += 1;
    const target = records.get(name) ?? null;
    if (target === null) {
      lastLookup = { name, status: 'NX', atTick: currentTick };
      return { status: 'NX' };
    }
    ledger.set(name, { name, target, expiresAtTick: currentTick + ttlTicks });
    lastLookup = { name, status: 'MISS', target, atTick: currentTick };
    return { status: 'OK', target, cacheStatus: 'MISS' };
  }

  function snapshot(currentTick = 0) {
    return {
      address,
      ttlTicks,
      lookups,
      cachedHits,
      authoritative,
      lastLookup,
      cache: [...ledger.values()]
        .filter((e) => currentTick < e.expiresAtTick)
        .map((e) => ({
          name: e.name,
          target: e.target,
          expiresAtTick: e.expiresAtTick,
          ttlRemaining: e.expiresAtTick - currentTick,
        })),
    };
  }

  return {
    get address() {
      return address;
    },
    lookup,
    snapshot,
  };
}
