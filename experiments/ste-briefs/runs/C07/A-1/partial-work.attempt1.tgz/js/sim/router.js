// DOCUMENTS: the Stage 6a component — a cross-subnet Router joining two
// network instances (the 10.x and 20.x subnets). It attaches itself to both
// networks as their only inter-subnet gateway: any frame whose destination
// sits on the far subnet takes exactly one router hop (the `routed`
// counter), forwarded from the router's own interface on that side. The
// router answers requests addressed to its right-side interface, so 20.1 is
// the only reachable 20.x target in 6a — Stage 6b occupies the subnet with
// the CDN edge. Same-subnet sends never touch the router.
//
// CHECKS: the constructor rejects a non-mini-IP interface address and a
// same-subnet pair (both interfaces must sit on different <net> numbers).
export function createRouter({ leftAddress = '10.65', rightAddress = '20.1' } = {}) {
  if (!/^\d+\.\d+$/.test(leftAddress)) {
    throw new Error(`router: invalid mini-IP address ${leftAddress}`);
  }
  if (!/^\d+\.\d+$/.test(rightAddress)) {
    throw new Error(`router: invalid mini-IP address ${rightAddress}`);
  }
  const leftNet = leftAddress.split('.')[0];
  const rightNet = rightAddress.split('.')[0];
  if (leftNet === rightNet) {
    throw new Error(
      `router: interfaces must sit on different subnets, got ${leftAddress} and ${rightAddress}`,
    );
  }
  let routed = 0;
  let lastHop = null;
  let leftNetwork = null;
  let rightNetwork = null;

  // One hop: validate the destination, count it, and hand the frame to the
  // far network from this side's interface. A destination on neither subnet
  // has no route (the networks' own fail-loud resolve answers the rest).
  function forward({ from, to, request }) {
    const toNet = String(to).split('.')[0];
    const far = toNet === rightNet ? rightNetwork : toNet === leftNet ? leftNetwork : null;
    if (!far) throw new Error(`router: no route to ${to}`);
    routed += 1;
    const via = toNet === rightNet ? rightAddress : leftAddress;
    lastHop = { from, via, to, request };
    return { from, to, request, response: far.send({ from: via, to, request }).response };
  }

  // The gateway predicates: a network forwards a destination only when it
  // sits on the other side's subnet, so same-subnet sends stay unchanged.
  return {
    get leftAddress() {
      return leftAddress;
    },
    get rightAddress() {
      return rightAddress;
    },

    join(left, right) {
      leftNetwork = left;
      rightNetwork = right;
      left.attachGateway({
        handles: (to) => String(to).split('.')[0] === rightNet,
        forward,
      });
      right.attachGateway({
        handles: (to) => String(to).split('.')[0] === leftNet,
        forward,
      });
    },

    // Requests addressed to the router's own interface are answered by the
    // router itself — it is the only 20.x host in 6a (Stage 6b adds the CDN).
    handleRequest() {
      return `200 Router at ${rightAddress}`;
    },

    snapshot() {
      return { leftAddress, rightAddress, routed, lastHop };
    },
  };
}
