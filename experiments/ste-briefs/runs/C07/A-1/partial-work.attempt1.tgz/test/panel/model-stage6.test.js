import { describe, it, expect } from 'vitest';
import { describeSnapshot } from '../../js/panel/model.js';
import { formatComponentState } from '../../js/panel/inspector-state.js';
import { createEngine } from '../../js/sim/engine.js';

// Stage-boundary extraction (guard-file-size pattern): the Stage 6
// narrative-branch pins live here so model.test.js stays inside the
// 450-line test cap. The trace snapshots are hand-built around the exact
// shape trace.js produces.
const baseSnapshot = {
  stage: 6,
  tick: 1,
  users: 5,
  serverAddress: '10.1',
  queueDepth: 0,
  served: 0,
  avgLatencyTicks: 0,
  dns: { address: '10.60', ttlTicks: 300, lookups: 0, cachedHits: 0, authoritative: 0, cache: [] },
  router: { leftAddress: '10.65', rightAddress: '20.1', routed: 0, lastHop: null },
};

const withTrace = (over) => ({ ...baseSnapshot, trace: over });

describe('describeSnapshot on Stage 6', () => {
  // PINS: the named counter-example — `GET /about` on Stage 6 keeps the
  // Stage 5 hop count and every hop text byte-identical: no DNS hop, no
  // cross-subnet hop. The whole sentence arrays must be equal.
  it('keeps GET /about on Stage 6 at the byte-identical Stage 5 hop story', () => {
    const trace = {
      hop: 4,
      method: 'GET',
      path: '/about',
      request: 'GET /about',
      displayRequest: 'GET /about',
      host: null,
      totalHops: 8,
      targetServer: '10.11',
      cacheStatus: 'MISS',
      dbOp: 'SELECT',
      dbStale: false,
      response: '200 This is the about page',
      status: 200,
      body: 'This is the about page',
      routeId: 'about',
    };
    const stage6 = { ...baseSnapshot, trace };
    const stage5 = {
      ...baseSnapshot,
      stage: 5,
      dns: undefined,
      router: undefined,
      trace: { ...trace, totalHops: undefined, host: undefined, displayRequest: undefined },
    };
    const six = describeSnapshot(stage6);
    const five = describeSnapshot(stage5);
    expect(six.totalHops).toBe(8);
    expect(six.hopStatus).toBe(five.hopStatus);
    expect(six.hopStatus).toBe('Hop 4/8: Database SELECT @ Replica (10.31) — fresh');
  });

  // PINS: a hosted path adds EXACTLY two DNS hops (ask, then the answer the
  // ledger actually gave) on top of Stage 5's eight — 10 total.
  it('adds exactly two DNS hops to a hosted example.com/about trace', () => {
    const snap = withTrace({
      hop: 3,
      method: 'GET',
      path: '/about',
      request: 'GET /about',
      displayRequest: 'GET example.com/about',
      host: 'example.com',
      dnsStatus: 'OK',
      dnsCacheStatus: 'MISS',
      dnsTarget: '10.1',
      totalHops: 10,
      targetServer: null,
      status: 200,
      response: '200 This is the about page',
      cacheStatus: 'MISS',
    });
    const labels = describeSnapshot(snap);
    expect(labels.totalHops).toBe(10);
    expect(labels.hopStatus).toBe('Hop 3/10: DNS (10.60) -> 10.2 | example.com = 10.1 (cache MISS)');
    const hopLabels = (hop, over = {}) =>
      describeSnapshot({ ...snap, trace: { ...snap.trace, hop, ...over } }).hopStatus;
    expect(hopLabels(1)).toBe('Hop 1/10: Browser (10.2) emits "GET example.com/about"');
    expect(hopLabels(2)).toBe('Hop 2/10: Browser (10.2) asks DNS (10.60) for example.com');
    expect(hopLabels(4)).toBe('Hop 4/10: Network (10.x) routes to LoadBalancer (10.1)');
    expect(hopLabels(9)).toBe('Hop 9/10: Browser (10.2) received and displayed 200');
    // A warm ledger answers as a cached hit in the same hop shape.
    expect(
      hopLabels(3, { dnsCacheStatus: 'HIT', dnsTarget: '10.1' }),
    ).toBe('Hop 3/10: DNS (10.60) -> 10.2 | example.com = 10.1 (cache HIT)');
  });

  // PINS: the NX branch — an unknown host never emits a GET: the trace is
  // the DNS ask plus the `NX no record` answer, then the browser renders
  // the NX card. Pinned here at the narrative layer and at the engine
  // layer below (no queue depth, no served, no LB forwarding).
  it('never emits a GET for a nope.example trace and renders the NX card', () => {
    const labels = describeSnapshot(
      withTrace({
        hop: 3,
        method: 'GET',
        path: '/about',
        request: 'GET /about',
        displayRequest: 'GET nope.example/about',
        host: 'nope.example',
        dnsStatus: 'NX',
        totalHops: 4,
        status: 'NX',
        response: 'NX no record',
        body: 'no record',
      }),
    );
    expect(labels.totalHops).toBe(4);
    expect(labels.hopStatus).toBe('Hop 3/4: DNS (10.60) -> 10.2 | NX no record');
    expect(labels.hopStatus).not.toContain('GET /about');

    // Engine-level: the NX trace runs 4 hops and the stack behind the DNS
    // is untouched — no GET reached the LB or the servers.
    const engine = createEngine({ stage: 6 });
    for (let i = 0; i < 4; i++) engine.traceHop({ method: 'GET', path: 'nope.example/about' });
    const snap = engine.snapshot();
    expect(snap.trace.hop).toBe(4);
    expect(snap.trace.status).toBe('NX');
    expect(snap.trace.dnsStatus).toBe('NX');
    expect(snap.loadBalancer.forwarded).toBe(0);
    expect(snap.servers.every((s) => s.served === 0)).toBe(true);
    expect(snap.queueDepth).toBe(0);
    expect(snap.dns).toMatchObject({ lookups: 1, authoritative: 1, cachedHits: 0 });
  });

  // PINS: the inspector carries the DNS ledger counters and the Router's
  // cross-subnet state as JSON derived from the snapshot.
  it('maps a Stage 6 snapshot to the DNS and Router inspector state as JSON', () => {
    const snap = {
      ...baseSnapshot,
      dns: {
        address: '10.60',
        ttlTicks: 300,
        lookups: 2,
        cachedHits: 1,
        authoritative: 1,
        lastLookup: { name: 'example.com', status: 'HIT', target: '10.1', atTick: 1 },
        cache: [{ name: 'example.com', target: '10.1', expiresAtTick: 301, ttlRemaining: 300 }],
      },
      router: {
        leftAddress: '10.65',
        rightAddress: '20.1',
        routed: 1,
        lastHop: { from: '10.2', via: '20.1', to: '20.1', request: 'GET /' },
      },
    };
    expect(JSON.parse(formatComponentState(snap, 'dns'))).toEqual({
      address: '10.60',
      ttlTicks: 300,
      lookups: 2,
      cachedHits: 1,
      authoritative: 1,
      lastLookup: snap.dns.lastLookup,
      ledger: snap.dns.cache,
    });
    expect(JSON.parse(formatComponentState(snap, 'router'))).toEqual({
      leftAddress: '10.65',
      rightAddress: '20.1',
      routed: 1,
      lastHop: snap.router.lastHop,
    });
    const networkState = JSON.parse(formatComponentState(snap, 'network'));
    expect(networkState.interfaces['10.60']).toBe('DNS');
    expect(networkState.interfaces[10.65]).toBe('Router');
    expect(networkState.interfaces[20.1]).toBe('Router (20.x side)');
  });
});
