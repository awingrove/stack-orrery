import { describe, it, expect } from 'vitest';
import { createNetwork } from '../../js/sim/network.js';
import { createRouter } from '../../js/sim/router.js';
import { createWebServer } from '../../js/sim/webserver.js';
import { createBrowser } from '../../js/sim/browser.js';

describe('createRouter', () => {
  // PINS: same-subnet sends are unchanged from today's send/deliverToQueue
  // contract — the router attaches as a gateway but never sees a frame
  // whose destination lives on the sending side's own subnet.
  it('passes same-subnet sends through unchanged with no router hop', () => {
    const left = createNetwork();
    const right = createNetwork();
    const router = createRouter({ leftAddress: '10.65', rightAddress: '20.1' });
    router.join(left, right);
    const server = createWebServer({ address: '10.1' });
    left.registerServer('10.1', server);

    const browser = createBrowser({ address: '10.2', network: left });
    const ok = browser.get('10.1', '/about');
    expect(ok.response).toBe('200 This is the about page');
    expect(router.snapshot()).toMatchObject({ routed: 0, lastHop: null });
  });

  // PINS: a cross-subnet frame takes exactly one router hop, forwarded from
  // the router's own interface on the far side; the router answers its own
  // right-side interface, so 20.1 is the only reachable 20.x target in 6a.
  it('takes a cross-subnet frame over exactly one router hop to 20.1', () => {
    const left = createNetwork();
    const right = createNetwork();
    const router = createRouter({ leftAddress: '10.65', rightAddress: '20.1' });
    router.join(left, right);
    right.registerServer('20.1', router);

    const record = left.send({ from: '10.2', to: '20.1', request: 'GET /' });
    expect(record).toEqual({
      from: '10.2',
      to: '20.1',
      request: 'GET /',
      response: '200 Router at 20.1',
    });
    expect(router.snapshot()).toMatchObject({
      routed: 1,
      lastHop: { from: '10.2', via: '20.1', to: '20.1', request: 'GET /' },
    });

    // The reverse direction routes back through the left interface (10.65).
    const server = createWebServer({ address: '10.1' });
    left.registerServer('10.1', server);
    const back = right.send({ from: '20.1', to: '10.1', request: 'GET /about' });
    expect(back.response).toBe('200 This is the about page');
    expect(router.snapshot().routed).toBe(2);
  });

  // PINS: the DL-1 fail-loud counter-example — sending into subnet 20 to an
  // unregistered host (20.9) throws, mirroring network.js's own
  // `no server at` failure for same-subnet sends.
  it('fails loud sending into subnet 20 to an unregistered host like 20.9', () => {
    const left = createNetwork();
    const right = createNetwork();
    const router = createRouter({ leftAddress: '10.65', rightAddress: '20.1' });
    router.join(left, right);

    expect(() => left.send({ from: '10.2', to: '20.9', request: 'GET /' })).toThrow(
      /no server at 20\.9/,
    );
    // The frame did take its one router hop — the throw comes from the far
    // network's own fail-loud resolve, after the hop counted.
    expect(router.snapshot().routed).toBe(1);
  });

  // CHECKS: the constructor rejects a non-mini-IP interface and a
  // same-subnet pair (both interfaces on one subnet join nothing).
  it('rejects invalid or same-subnet interface addresses', () => {
    expect(() => createRouter({ leftAddress: '1065' })).toThrow(/invalid mini-IP/);
    expect(() => createRouter({ rightAddress: '201' })).toThrow(/invalid mini-IP/);
    expect(() => createRouter({ leftAddress: '10.65', rightAddress: '10.1' })).toThrow(
      /different subnets/,
    );
  });
});
