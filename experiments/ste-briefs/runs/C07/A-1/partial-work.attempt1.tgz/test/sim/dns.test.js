import { describe, it, expect } from 'vitest';
import { createDns } from '../../js/sim/dns.js';
import { createEngine } from '../../js/sim/engine.js';

describe('createDns', () => {
  // PINS: the DNS TTL branch — a lookup inside ttlTicks is an incrementing
  // cachedHits with NO authoritative consult; an expired entry is dropped
  // and the table is re-consulted, never answered from the ledger.
  it('answers a lookup inside ttlTicks from the ledger cache with no authoritative consult', () => {
    const dns = createDns({ address: '10.60', ttlTicks: 300 });

    // First lookup: a real table consult (authoritative), which fills the
    // ledger with the tick-TTL entry.
    expect(dns.lookup('example.com', 5)).toEqual({
      status: 'OK',
      target: '10.1',
      cacheStatus: 'MISS',
    });
    let snap = dns.snapshot(5);
    expect(snap).toMatchObject({ lookups: 1, cachedHits: 0, authoritative: 1 });
    expect(snap.cache).toEqual([
      { name: 'example.com', target: '10.1', expiresAtTick: 305, ttlRemaining: 300 },
    ]);

    // Inside the TTL: the ledger answers — cachedHits increments and the
    // authoritative counter must NOT move.
    expect(dns.lookup('example.com', 304)).toEqual({
      status: 'OK',
      target: '10.1',
      cacheStatus: 'HIT',
    });
    snap = dns.snapshot(304);
    expect(snap).toMatchObject({ lookups: 2, cachedHits: 1, authoritative: 1 });
    expect(snap.lastLookup).toEqual({
      name: 'example.com',
      status: 'HIT',
      target: '10.1',
      atTick: 304,
    });
  });

  it('never answers an expired entry from the cache ledger and reconsults the table', () => {
    const dns = createDns({ address: '10.60', ttlTicks: 300 });

    dns.lookup('example.com', 0); // cached at tick 0, alive through 299
    // Tick 300 is the first tick the entry is gone: the ledger must not
    // answer — the table is re-consulted (authoritative +1) and the entry
    // is rewritten with a fresh expiry.
    expect(dns.lookup('example.com', 300)).toEqual({
      status: 'OK',
      target: '10.1',
      cacheStatus: 'MISS',
    });
    const snap = dns.snapshot(300);
    expect(snap).toMatchObject({ lookups: 2, cachedHits: 0, authoritative: 2 });
    expect(snap.cache).toEqual([
      { name: 'example.com', target: '10.1', expiresAtTick: 600, ttlRemaining: 300 },
    ]);
  });

  // PINS: the unknown-name branch — NX, not a throw; the DNS layer never
  // throws on a missing record (the throw rule belongs to cross-subnet
  // addresses, network.js).
  it('answers an unknown name with NX no record and never throws', () => {
    const dns = createDns({ address: '10.60', ttlTicks: 300 });
    expect(dns.lookup('nope.example', 1)).toEqual({ status: 'NX' });
    const snap = dns.snapshot(1);
    expect(snap).toMatchObject({ lookups: 1, cachedHits: 0, authoritative: 1 });
    expect(snap.cache).toEqual([]);
    expect(snap.lastLookup).toEqual({ name: 'nope.example', status: 'NX', atTick: 1 });
  });

  // CHECKS: the constructor rejects a non-mini-IP address and a
  // non-positive or non-integer ttlTicks (fail-loud over silent misconfig).
  it('rejects a non mini-IP address and a non-positive ttlTicks', () => {
    expect(() => createDns({ address: '1060' })).toThrow(/invalid mini-IP/);
    expect(() => createDns({ ttlTicks: 0 })).toThrow(/ttlTicks/);
    expect(() => createDns({ ttlTicks: 2.5 })).toThrow(/ttlTicks/);
  });
});

describe('stage 6 engine wiring', () => {
  // PINS: stage >= 6 instantiates DNS 10.60 with a 300t TTL ledger and the
  // Router 10.65 ⇄ 20.1, both exposed on the snapshot; earlier stages
  // expose neither.
  it('stage 6 engine exposes DNS 10.60 and Router 10.65 ⇄ 20.1 on the snapshot', () => {
    const engine = createEngine({ stage: 6 });
    const snap = engine.snapshot();
    expect(snap.dns).toMatchObject({ address: '10.60', ttlTicks: 300, lookups: 0 });
    expect(snap.router).toEqual({
      leftAddress: '10.65',
      rightAddress: '20.1',
      routed: 0,
      lastHop: null,
    });
    expect(createEngine({ stage: 5 }).snapshot().dns).toBe(null);
    expect(createEngine({ stage: 5 }).snapshot().router).toBe(null);
    expect(() => createEngine({ stage: 7 })).toThrow(/stage must be/);
  });
});
