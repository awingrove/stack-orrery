import { test, expect } from '@playwright/test';

// Stage 6a — DNS with a tick-TTL ledger + cross-subnet Router. These
// assertions live in their own spec (guard-file-size splits e2e by
// responsibility, as with teaching.spec.js — panel.spec.js sits at its
// 450-line cap). Titles are manifest pins (PANEL-6): do not reword.

// The Stage 6 orrery draws 8 rings, reveals the DNS card (10.60) on Ring 7
// and the Router side-card (10.65 ⇄ 20.1) beside the 10.x hub, and a hosted
// path resolves through the DNS ledger before the GET goes out — the DNS
// code and its live TTL ledger open in the bottom inspector.
test('should switch to Stage 6, resolve example.com through DNS 10.60, and inspect DNS code + TTL ledger', async ({
  page,
}) => {
  await page.goto('/panel.html');

  await page.getByTestId('stage-pill-6').click();
  await expect(page.getByTestId('stage-pill-6')).toHaveAttribute('aria-current', 'true');
  await expect(page.getByTestId('node-dns')).toBeVisible();
  await expect(page.getByTestId('node-router')).toBeVisible();
  await expect(page.getByTestId('node-queue')).toBeVisible();
  await expect(page.locator('.orrery-ring')).toHaveCount(8);
  await expect(page.locator('.orrery-ring').first()).toHaveAttribute('r', '400');
  await expect(page.locator('.orrery-ring').last()).toHaveAttribute('r', '3200');
  await expect(page.getByTestId('dns-stats')).toHaveText(
    'Lookups: 0 · Cached hits: 0 · Authoritative: 0 · TTL: 300t',
  );
  await expect(page.getByTestId('router-stats')).toHaveText('Routed: 0');

  // The hosted path resolves first: one authoritative ask fills the ledger.
  await page.getByTestId('url-input').fill('example.com/about');
  await page.getByTestId('btn-url-go').click();
  await expect(page.getByTestId('dns-stats')).toHaveText(
    'Lookups: 1 · Cached hits: 0 · Authoritative: 1 · TTL: 300t',
  );
  await expect(page.getByTestId('dns-entries-list')).toContainText('example.com = 10.1');
  await expect(page.getByTestId('browser-rendered-body')).toHaveText('This is the about page');
  await expect(page.getByTestId('hop-status')).toContainText('Hop 10/10');

  await page.getByTestId('node-dns').click();
  await expect(page.getByTestId('inspector-code')).toContainText('createDns');
  await expect(page.getByTestId('inspector-state')).toContainText('"ttlTicks": 300');
  await expect(page.getByTestId('inspector-state')).toContainText('"authoritative": 1');
  await page.getByTestId('node-router').click();
  await expect(page.getByTestId('inspector-code')).toContainText('createRouter');
  await expect(page.getByTestId('inspector-state')).toContainText('"routed": 0');
  await expect(page.getByTestId('inspector-state')).toContainText('10.65');
});

// The hosted trace walks the two DNS hops (ask, then the ledger's answer)
// before the Stage 5 chain; a second trace inside the TTL is a cached hit
// with NO second authoritative consult.
test('should trace example.com/about with DNS ask + answer hops', async ({ page }) => {
  await page.goto('/panel.html');

  await page.getByTestId('stage-pill-6').click();
  await page.getByTestId('url-input').fill('example.com/about');

  for (let hop = 0; hop < 2; hop++) await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toHaveText(
    'Hop 2/10: Browser (10.2) asks DNS (10.60) for example.com',
  );
  for (let hop = 0; hop < 1; hop++) await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toHaveText(
    'Hop 3/10: DNS (10.60) -> 10.2 | example.com = 10.1 (cache MISS)',
  );
  await expect(page.getByTestId('dns-stats')).toHaveText(
    'Lookups: 1 · Cached hits: 0 · Authoritative: 1 · TTL: 300t',
  );
  for (let hop = 0; hop < 7; hop++) await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toContainText('Hop 10/10');
  await expect(page.getByTestId('browser-rendered-body')).toHaveText('This is the about page');

  // Second trace inside the TTL: the ledger answers — cachedHits +1, the
  // authoritative counter must not move.
  await page.getByTestId('url-input').fill('example.com/about');
  for (let hop = 0; hop < 3; hop++) await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toHaveText(
    'Hop 3/10: DNS (10.60) -> 10.2 | example.com = 10.1 (cache HIT)',
  );
  await expect(page.getByTestId('dns-stats')).toHaveText(
    'Lookups: 2 · Cached hits: 1 · Authoritative: 1 · TTL: 300t',
  );
});

// Negative-case pin: a host-less `GET /about` on Stage 6 keeps the Stage 5
// hop story — 8 hops, no DNS hop, and the DNS counters stay at zero. The
// deep-link live set extends to 6 (?stage=6), so load it directly.
test('should keep GET /about on Stage 6 at the Stage 5 hop story', async ({ page }) => {
  await page.goto('/panel.html?stage=6');
  await expect(page.getByTestId('stage-pill-6')).toHaveAttribute('aria-current', 'true');
  await expect(page.getByTestId('node-dns')).toBeVisible();

  await page.getByTestId('url-input').fill('/about');
  for (let hop = 0; hop < 2; hop++) await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toHaveText(
    'Hop 2/8: Network (10.x) routes to LoadBalancer (10.1)',
  );
  for (let hop = 0; hop < 6; hop++) await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toHaveText(
    'Hop 8/8: Worker (10.41) idle — no async jobs in this trace',
  );
  await expect(page.getByTestId('browser-rendered-body')).toHaveText('This is the about page');
  // No DNS hop happened: the resolver was never asked.
  await expect(page.getByTestId('dns-stats')).toHaveText(
    'Lookups: 0 · Cached hits: 0 · Authoritative: 0 · TTL: 300t',
  );
  await expect(page.getByTestId('dns-entries-list')).not.toContainText('example.com');
});
