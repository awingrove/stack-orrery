import { test, expect } from '@playwright/test';

// Stage 6a — DNS with a tick-TTL ledger + cross-subnet Router. Split from
// panel.spec.js by responsibility (guard-file-size: that spec sits at its
// 450-line cap). Titles are manifest pins (PANEL-6): do not reword.

// CHECKS: the hosted URL walks browser -> DNS ask -> DNS answer -> the
// Stage 5 chain (10 hops); the resolver's ledger answers the second hosted
// trace from cache (Cached hits +1, no authoritative consult), and the
// DNS/Router cards open their code + live ledger state in the inspector.
test('should switch to Stage 6, resolve example.com through DNS 10.60, and inspect DNS code + TTL ledger', async ({
  page,
}) => {
  await page.goto('/panel.html');

  await page.getByTestId('stage-pill-6').click();
  await expect(page.getByTestId('node-dns')).toBeVisible();
  await expect(page.getByTestId('node-router')).toBeVisible();
  await expect(page.locator('.orrery-ring')).toHaveCount(8);
  await expect(page.locator('.orrery-ring').first()).toHaveAttribute('r', '400');
  await expect(page.locator('.orrery-ring').last()).toHaveAttribute('r', '3200');
  await expect(page.getByTestId('dns-stats')).toHaveText('Lookups: 0 · Cached hits: 0 · TTL: 300t');
  await expect(page.getByTestId('router-stats')).toHaveText('Routed: 0 · 10.65 ⇄ 20.1');

  // Hops 1-2/10: the browser asks DNS 10.60, and the resolver answers
  // example.com = 10.1 from its authoritative table (one consult, no hit).
  await page.getByTestId('url-input').fill('example.com/about');
  for (let hop = 0; hop < 2; hop++) await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toContainText('Hop 2/10: DNS (10.60) -> 10.2');
  await expect(page.getByTestId('dns-stats')).toHaveText('Lookups: 1 · Cached hits: 0 · TTL: 300t');
  await expect(page.getByTestId('dns-entries-list')).toContainText('example.com');

  // Hops 3-10/10: the resolved GET rides the Stage 5 chain.
  for (let hop = 0; hop < 8; hop++) await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toContainText('Hop 10/10');
  await expect(page.getByTestId('browser-rendered-body')).toHaveText('This is the about page');

  // The second hosted trace answers from the tick-TTL ledger.
  for (let hop = 0; hop < 10; hop++) await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('dns-stats')).toHaveText('Lookups: 2 · Cached hits: 1 · TTL: 300t');
  await expect(page.getByTestId('browser-rendered-body')).toHaveText('This is the about page');

  await page.getByTestId('node-dns').click();
  await expect(page.getByTestId('inspector-code')).toContainText('createDns');
  await expect(page.getByTestId('inspector-state')).toContainText('"cachedHits": 1');
  await page.getByTestId('node-router').click();
  await expect(page.getByTestId('inspector-code')).toContainText('createRouter');
  await expect(page.getByTestId('inspector-state')).toContainText('"routed": 0');
});

// CHECKS: the deep-linked live-stage set extends to 6 — ?stage=6 boots the
// 8-ring topology directly, and the hosted trace's first two hops are the
// DNS ask + answer.
test('should trace example.com/about with DNS ask + answer hops', async ({ page }) => {
  await page.goto('/panel.html?stage=6');
  await expect(page.getByTestId('stage-pill-6')).toHaveAttribute('aria-current', 'true');
  await expect(page.getByTestId('node-dns')).toBeVisible();

  await page.getByTestId('url-input').fill('example.com/about');
  await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toHaveText(
    'Hop 1/10: Browser (10.2) emits "GET example.com/about" — DNS ask example.com @ 10.60',
  );
  await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toHaveText(
    'Hop 2/10: DNS (10.60) -> 10.2 — example.com = 10.1',
  );
  await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toContainText('Hop 3/10');
  // The resolved request, not the URL, rides the wire from hop 3 on.
  await expect(page.getByTestId('network-last-frame')).toContainText('GET /about');
});

// CHECKS (named counter-example): a host-less GET /about on Stage 6 keeps
// the Stage 5 hop story byte-identical — 8 hops, the same sentences, and
// the resolver stays untouched (zero lookups, empty ledger).
test('should keep GET /about on Stage 6 at the Stage 5 hop story', async ({ page }) => {
  await page.goto('/panel.html?stage=6');
  await expect(page.getByTestId('dns-stats')).toHaveText('Lookups: 0 · Cached hits: 0 · TTL: 300t');
  await expect(page.getByTestId('dns-entries-list')).toContainText('resolver cache empty');

  await page.getByTestId('url-input').fill('/about');
  for (let hop = 0; hop < 8; hop++) await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toHaveText(
    'Hop 8/8: Worker (10.41) idle — no async jobs in this trace',
  );
  await expect(page.getByTestId('dns-stats')).toHaveText('Lookups: 0 · Cached hits: 0 · TTL: 300t');
  await expect(page.getByTestId('dns-entries-list')).toContainText('resolver cache empty');
  await expect(page.getByTestId('browser-rendered-body')).toHaveText('This is the about page');
});
