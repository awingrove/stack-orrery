// DOCUMENTS: the Stage 6 hosted-DNS trace runner — the hop-by-hop machine
// for a browser path that carries a host (`example.com/about`). trace.js
// delegates only hosted hops here; a host-less path (`/about`) keeps the
// Stage 5 chain byte-identical. Two DNS hops ride in front: Browser -> DNS
// ask, DNS answer with the resolved target, then the browser emits the GET
// with the resolved target and the Stage 5 story follows — 10 hops. An
// unknown name ends the trace after the ask/answer pair: DNS ask + "NX no
// record" answer + the browser rendering the NX card — no GET is emitted
// and the servers never drain.
//
// CHECKS: the hosted/NX/host-less branch keys off the path's first
// character and host syntax — "GET /about" is never hosted (named
// counter-example pinned in test/panel/model-stage6.test.js), and a bare
// name without a path ("example.com") is not a hosted URL either.
export function isHostedPath(path = '') {
  const raw = String(path);
  return raw.length > 0 && !raw.startsWith('/') && raw.includes('/');
}

import { drainUntilYou, backendFor } from './trace-shared.js';

// Hosted grammar: the URL splits host/path on the first "/" —
// "example.com/about" -> host "example.com", path "/about".
function splitHostPath(raw) {
  const at = raw.indexOf('/');
  return { host: raw.slice(0, at), path: raw.slice(at) };
}

export function createHostedRunner({
  dns,
  lb,
  servers,
  cache = null,
  database = null,
  workerQueue = null,
  bumpTick,
  getTick,
  onServe,
  onFinish,
  serverAddress,
}) {
  // The served response record, held between the drain hop and the serve
  // hop so the learner watches the cache/database lookup before the
  // response leaves the backend (same pattern as the host-less machine).
  let served = null;
  const drain = (targetServer) => drainUntilYou(targetServer, getTick);
  const backendForTarget = (targetAddress) => backendFor(servers, targetAddress);

  function serve(record, trace) {
    trace.response = record.response;
    trace.status = record.status;
    trace.body = record.body;
    trace.routeId = record.routeId;
    onServe(record);
  }

  // Hop 1: the browser asks DNS 10.60 for the host — the lookup runs now,
  // and the answer hop narrates whatever the resolver actually did.
  function start({ method = 'GET', path = '/about', from = '10.2' }) {
    const { host, path: httpPath } = splitHostPath(String(path));
    const request = `${method} ${path}`;
    const answer = dns.lookup(host, getTick());
    const trace = {
      hop: 1,
      method,
      path,
      from,
      request,
      targetServer: null,
      hosted: true,
      host,
      httpPath,
      dnsStatus: answer.status,
      resolvedTarget: answer.target ?? null,
      nx: answer.status === 'NX',
      cacheStatus: null,
      dbOp: null,
      dbStale: false,
      asyncJob: false,
      response: null,
      status: null,
      body: null,
      routeId: null,
    };
    return { trace, frame: `${from} -> ${dns.address} | ${request} (DNS ask ${host})` };
  }

  // One hop per call (trace.hop values 1..9; hop 10 ends the trace and the
  // machine's hop >= finalHop branch restarts). Returns the hop's frame, or
  // null when nothing moved.
  function step(trace) {
    let frame = null;
    if (trace.hop === 1) {
      trace.hop = 2;
      frame = trace.nx
        ? `${dns.address} -> ${trace.from} | DNS answer ${trace.host} = NX no record`
        : `${dns.address} -> ${trace.from} | DNS answer ${trace.host} = ${trace.resolvedTarget}`;
    } else if (trace.nx) {
      // Final NX hop: the browser renders the NX card — no GET ever leaves
      // the browser, so the servers stay drained.
      trace.hop = 3;
      trace.response = 'NX no record';
      trace.status = 'NX';
      trace.body = 'no record';
      onFinish({
        from: trace.from,
        to: dns.address,
        request: trace.request,
        response: 'NX no record',
      });
      frame = `Browser ${trace.from} renders NX no record — no GET emitted`;
    } else if (trace.hop === 2) {
      // The browser emits the GET with the resolved target.
      trace.hop = 3;
      trace.request = `${trace.method} ${trace.httpPath}`;
      trace.path = trace.httpPath;
      frame = `${trace.from} -> ${serverAddress} | ${trace.request}`;
    } else if (trace.hop === 3) {
      trace.hop = 4;
      frame = `routed ${trace.from} -> ${serverAddress} (${trace.request}) to LoadBalancer`;
    } else if (trace.hop === 4) {
      trace.hop = 5;
      const atTick = bumpTick();
      const target = lb.enqueue({
        id: `you:${atTick}`,
        from: trace.from,
        to: serverAddress,
        request: trace.request,
        atTick,
        isYou: true,
      });
      trace.targetServer = target;
      frame = `LB ${serverAddress} -> ${target} (${trace.request}) queued`;
    } else if (trace.hop === 5) {
      // The backend drains and narrates the cache/database/async story it
      // actually took (the Stage 4 story on non-async paths, DL-4).
      trace.hop = 6;
      const backend = backendForTarget(trace.targetServer);
      served = drain(backend);
      if (served) {
        trace.cacheStatus = served.cacheStatus ?? null;
        trace.dbOp = served.dbOp ?? null;
        trace.dbStale = Boolean(served.dbStale);
        trace.asyncJob = Boolean(served.asyncJob);
        if (served.asyncJob) {
          frame = `${backend.address} -> ${workerQueue ? workerQueue.address : '10.40'} | enqueued async job (${trace.path})`;
        } else if (trace.dbOp === 'WRITE') {
          frame = `Database WRITE ${trace.path} @ ${database.primaryAddress} (replica ${database.replicaAddress} lags ${database.replicationLagTicks}t)`;
        } else if (trace.dbOp === 'SELECT') {
          frame = `Database SELECT ${trace.path} @ ${database.replicaAddress} (${trace.dbStale ? 'STALE' : 'fresh'})`;
        } else {
          frame = `Database SKIP ${trace.path} (warm cache HIT @ ${cache.address})`;
        }
      }
    } else if (trace.hop === 6) {
      trace.hop = 7;
      if (served) {
        serve(served, trace);
        frame = served.asyncJob
          ? `${trace.targetServer} -> ${trace.from} | ${served.response}`
          : `${trace.targetServer} -> ${trace.from} | ${served.response} (cache ${trace.cacheStatus})`;
      }
    } else if (trace.hop === 7) {
      trace.hop = 8;
      frame = `Network delivered ${trace.status} response to ${trace.from}`;
    } else if (trace.hop === 8) {
      trace.hop = 9;
      onFinish({
        from: trace.from,
        to: trace.targetServer ?? serverAddress,
        request: trace.request,
        response: trace.response,
      });
      frame = `Browser ${trace.from} received and displayed ${trace.status}`;
    } else if (trace.hop === 9) {
      trace.hop = 10;
      const dbTarget = database ? database.primaryAddress : '10.30';
      const workerAddr = workerQueue ? workerQueue.workerAddress : '10.41';
      frame = trace.asyncJob
        ? `Worker ${workerAddr} finished job and committed to Database ${dbTarget}`
        : `Worker ${workerAddr} idle — no async jobs in this trace`;
    }
    return frame;
  }

  return { start, step };
}
