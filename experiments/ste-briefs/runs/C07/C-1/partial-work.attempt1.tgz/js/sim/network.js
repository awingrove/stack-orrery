// DOCUMENTS: the network — the wiring that lets two-number mini-IP
// addressable components exchange messages. Today it carries slim HTTP
// requests to a registered server; later stages attach more components
// without changing the send/enqueue contract.
//
// Stage 6: with a `subnet` and a `gateway` attached, a frame whose target
// lives on another subnet is forwarded to the gateway (the cross-subnet
// Router) — exactly one router hop — instead of resolving the target here;
// an unregistered host on the gateway's own subnets still fails loud. With
// no subnet (Stages 1-5) the fabric is unchanged: every unregistered
// address throws.
//
// CHECKS: every address crossing the wire is validated as a two-number
// mini-IP (<net>.<host>), and sends to unregistered hosts fail loud. A
// cross-subnet fabric needs both a subnet and a gateway — either alone is
// rejected at construction.
const MINI_IP = /^\d+\.\d+$/;

export function createNetwork({ subnet = null, gateway = null } = {}) {
  if ((subnet === null) !== (gateway === null)) {
    throw new Error('network: cross-subnet routing needs both a subnet and a gateway');
  }
  const netOf = (addr) => addr.slice(0, addr.indexOf('.'));
  const servers = new Map();

  function validate(addr) {
    if (!MINI_IP.test(addr)) {
      throw new Error(`network: invalid mini-IP address ${addr}`);
    }
  }

  function resolve(address) {
    validate(address);
    const server = servers.get(address);
    if (!server) {
      throw new Error(`network: no server at ${address}`);
    }
    return server;
  }

  function crossSubnet(to) {
    return subnet !== null && netOf(to) !== subnet;
  }

  return {
    registerServer(address, server) {
      validate(address);
      servers.set(address, server);
    },

    resolve,

    send({ from, to, request, isYou = false }) {
      validate(from);
      validate(to);
      if (crossSubnet(to)) {
        return gateway.forward({ from, to, request, isYou });
      }
      const response = resolve(to).handleRequest(request);
      return { from, to, request, response };
    },

    // `isYou` rides through untouched: the engine marks the learner's own
    // interactive-browser request, the server stores it on the queue row.
    deliverToQueue({ id, from, to, request, atTick, isYou = false }) {
      validate(from);
      validate(to);
      if (crossSubnet(to)) {
        gateway.forwardQueue({ id, from, to, request, atTick, isYou });
        return;
      }
      const server = resolve(to);
      server.enqueue({ id, from, to, request, atTick, isYou });
    },
  };
}
