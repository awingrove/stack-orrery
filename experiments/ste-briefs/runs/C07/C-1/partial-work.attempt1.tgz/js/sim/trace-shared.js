// DOCUMENTS: hop-machine helpers shared by the host-less chain (trace.js)
// and the Stage 6 hosted runner (trace-hosted.js) — pure, no trace state of
// their own: time and the server pool arrive as arguments, the same way the
// components keep time.

// Serve from the front of the target's queue until the trace's own request
// (isYou) comes back, or the queue runs dry this tick.
export function drainUntilYou(targetServer, getTick) {
  for (;;) {
    const batch = targetServer.step(getTick());
    const you = batch.find((item) => item.isYou);
    if (you || batch.length === 0) return you;
  }
}

// The backend behind a target address (round-robin targets name their
// server; anything unknown falls back to the first pool entry).
export function backendFor(servers, targetAddress) {
  return servers.find((s) => s.address === targetAddress) ?? servers[0];
}
