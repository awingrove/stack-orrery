// DOCUMENTS: the Stage 6 component — a DNS resolver with a tick-TTL cache
// ledger. The authoritative table (example.com -> 10.1; Stage 6b adds a CDN
// name) is consulted only on a cold lookup: every resolved name is written
// into the ledger with an expiry tick, and a lookup inside that TTL is
// answered from the ledger (cachedHits) with no authoritative consult. An
// entry past its expiry is gone before the lookup runs, so a stale record is
// re-consulted, not answered. Unknown names answer { status: 'NX' } — the
// browser renders the NX card and no GET is emitted; the throw rule belongs
// to cross-subnet addresses (network.js), not to the resolver.
//
// Deterministic by construction: no clock, no RNG — time arrives as the
// `currentTick` argument, the same way the Cache and WebServer keep time.
//
// CHECKS: the constructor rejects an address that is not a two-number
// mini-IP and a ttlTicks that is not a positive integer (fail-loud over
// silent mis-configuration).
export function createDns({ address = '10.60', ttlTicks = 300 } = {}) {
  if (!/^\d+\.\d+$/.test(address)) {
    throw new Error(`dns: invalid mini-IP address ${address}`);
  }
  if (!Number.isInteger(ttlTicks) || ttlTicks < 1) {
    throw new Error(`dns: ttlTicks must be a positive integer, got ${ttlTicks}`);
  }
  const authoritative = new Map([['example.com', '10.1']]);
  const ledger = new Map(); // name -> { name, target, cachedAtTick, expiresAtTick }
  let lookups = 0;
  let cachedHits = 0;
  let evictions = 0;
  let lastLookup = null;

  // An entry is stale the moment the current tick reaches its expiry:
  // resolved at tick T with ttlTicks = 300 means alive through tick T + 299.
  function evictExpired(currentTick = 0) {
    for (const entry of ledger.values()) {
      if (currentTick >= entry.expiresAtTick) {
        ledger.delete(entry.name);
        evictions += 1;
      }
    }
  }

  // CHECKS: the cache branch answers only a live ledger entry (source
  // 'cache'); a miss or an expired entry consults the authoritative table
  // (source 'authoritative') and refills the ledger. lastLookup records
  // which branch ran, so tests and the inspector can pin that a hit inside
  // ttlTicks increments cachedHits with no authoritative consult.
  function lookup(name, currentTick = 0) {
    lookups += 1;
    evictExpired(currentTick);
    const entry = ledger.get(name);
    if (entry) {
      cachedHits += 1;
      lastLookup = {
        name,
        status: 'OK',
        source: 'cache',
        target: entry.target,
        atTick: currentTick,
      };
      return { status: 'OK', target: entry.target, source: 'cache' };
    }
    const target = authoritative.get(name) ?? null;
    if (target !== null) {
      ledger.set(name, {
        name,
        target,
        cachedAtTick: currentTick,
        expiresAtTick: currentTick + ttlTicks,
      });
      lastLookup = { name, status: 'OK', source: 'authoritative', target, atTick: currentTick };
      return { status: 'OK', target, source: 'authoritative' };
    }
    lastLookup = { name, status: 'NX', source: 'authoritative', target: null, atTick: currentTick };
    return { status: 'NX' };
  }

  function snapshot(currentTick = 0) {
    evictExpired(currentTick);
    return {
      address,
      ttlTicks,
      lookups,
      cachedHits,
      evictions,
      lastLookup,
      authoritative: [...authoritative.entries()].map(([name, target]) => ({ name, target })),
      cache: [...ledger.values()].map((e) => ({
        name: e.name,
        target: e.target,
        cachedAtTick: e.cachedAtTick,
        expiresAtTick: e.expiresAtTick,
        ttlRemaining: e.expiresAtTick - currentTick,
      })),
    };
  }

  return {
    get address() {
      return address;
    },
    evictExpired,
    lookup,
    snapshot,
  };
}
