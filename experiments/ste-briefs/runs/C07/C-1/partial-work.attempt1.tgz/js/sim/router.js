// DOCUMENTS: the Stage 6 component — a cross-subnet Router joining the 10.x
// and 20.x network instances. A frame whose target lives on the other subnet
// takes exactly one router hop (the `routed` counter) and is delivered out
// the matching interface; `isYou` rides through untouched. Nothing lives in
// subnet 20 in Stage 6a besides the router's own presence: an unregistered
// 20.x host fails loud (mirrors network.js), and the router's 20-side
// interface (20.1) is the only reachable target — Stage 6b occupies it with
// the CDN edge.
//
// CHECKS: the constructor rejects a non-mini-IP on either interface and both
// interfaces sitting on the same subnet; an attached frame to a subnet
// neither interface fronts fails loud (no route), and a queued frame whose
// final target is the router's own interface fails loud too (no worker
// lives behind the router in 6a).
export function createRouter({ leftAddress = '10.65', rightAddress = '20.1' } = {}) {
  if (!/^\d+\.\d+$/.test(leftAddress)) {
    throw new Error(`router: invalid mini-IP address ${leftAddress}`);
  }
  if (!/^\d+\.\d+$/.test(rightAddress)) {
    throw new Error(`router: invalid mini-IP address ${rightAddress}`);
  }
  const netOf = (addr) => addr.slice(0, addr.indexOf('.'));
  if (netOf(leftAddress) === netOf(rightAddress)) {
    throw new Error(
      `router: both interfaces must sit on different subnets, got ${leftAddress} and ${rightAddress}`,
    );
  }
  let left = null;
  let right = null;
  let routed = 0;

  // CHECKS: the exit interface is the one whose subnet fronts the target —
  // anything else is an unattached subnet and fails loud.
  function exitFor(to) {
    const net = netOf(to);
    if (net === netOf(rightAddress)) return { network: right, exit: rightAddress };
    if (net === netOf(leftAddress)) return { network: left, exit: leftAddress };
    throw new Error(`router: no route to subnet ${net} (target ${to})`);
  }

  function assertAttached() {
    if (!left || !right) {
      throw new Error('router: no networks attached — call attach({ left, right }) first');
    }
  }

  return {
    get leftAddress() {
      return leftAddress;
    },
    get rightAddress() {
      return rightAddress;
    },

    attach({ left: leftNetwork, right: rightNetwork }) {
      if (!leftNetwork || !rightNetwork) {
        throw new Error('router: attach needs both subnet networks');
      }
      left = leftNetwork;
      right = rightNetwork;
    },

    // Exactly one router hop: the counter increments once per cross-subnet
    // frame, and the frame exits on the interface that fronts its subnet.
    // A frame addressed to the router's own interface terminates at the
    // router (the subnet holds nothing else in 6a) and answers with a slim
    // diagnostic record — no HTTP server lives there.
    forward({ from, to, request, isYou = false }) {
      assertAttached();
      routed += 1;
      const { network, exit } = exitFor(to);
      if (to === exit) {
        return {
          from,
          to,
          request,
          isYou,
          response: `200 Router ${to} (cross-subnet edge)`,
        };
      }
      return { ...network.send({ from, to, request }), isYou };
    },

    // Queue path of the same hop: the frame exits toward its subnet with the
    // original sender address; the router's own interface accepts no queued
    // work (fail-loud over a silent drop).
    forwardQueue({ id, from, to, request, atTick, isYou = false }) {
      assertAttached();
      routed += 1;
      const { network, exit } = exitFor(to);
      if (to === exit) {
        throw new Error(`router: queued work for ${to} has no worker behind the router (stage 6a)`);
      }
      network.deliverToQueue({ id, from, to, request, atTick, isYou });
    },

    snapshot() {
      return { leftAddress, rightAddress, routed };
    },
  };
}
