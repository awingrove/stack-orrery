// DOCUMENTS: the Stage 6 inspector code entries — split from
// inspector-source.js by responsibility (guard-file-size): the DNS ledger
// and the cross-subnet Router mirror js/sim/dns.js and js/sim/router.js
// (the executable truth lives there; these entries render the same logic
// for learners).
export const COMPONENT_SOURCE_STAGE6 = {
  dns: {
    file: 'js/sim/dns.js',
    code: `createDns({ address = '10.60', ttlTicks = 300 } = {}) {
  // address must be "<net>.<host>" — a two-number mini-IP
  const authoritative = new Map([['example.com', '10.1']]);
  const ledger = new Map(); // name -> { target, cachedAtTick, expiresAtTick }
  let lookups = 0, cachedHits = 0, evictions = 0, lastLookup = null;
  function evictExpired(currentTick = 0) {
    for (const entry of ledger.values()) {
      if (currentTick >= entry.expiresAtTick) {  // TTL elapsed
        ledger.delete(entry.name);
        evictions += 1;
      }
    }
  }
  function lookup(name, currentTick = 0) {
    lookups += 1;
    evictExpired(currentTick);
    const entry = ledger.get(name);
    if (entry) {  // live ledger entry: no authoritative consult
      cachedHits += 1;
      lastLookup = { name, status: 'OK', source: 'cache', target: entry.target, atTick: currentTick };
      return { status: 'OK', target: entry.target, source: 'cache' };
    }
    const target = authoritative.get(name) ?? null;
    if (target !== null) {  // miss: consult, then fill the ledger
      ledger.set(name, { name, target, cachedAtTick: currentTick,
        expiresAtTick: currentTick + ttlTicks });
      lastLookup = { name, status: 'OK', source: 'authoritative', target, atTick: currentTick };
      return { status: 'OK', target, source: 'authoritative' };
    }
    lastLookup = { name, status: 'NX', source: 'authoritative', target: null, atTick: currentTick };
    return { status: 'NX' };  // unknown name: no throw, no cache entry
  }
  function snapshot(currentTick = 0) {
    evictExpired(currentTick);
    return { address, ttlTicks, lookups, cachedHits, evictions, lastLookup,
      authoritative: [...authoritative].map(([name, target]) => ({ name, target })),
      cache: [...ledger.values()].map((e) => ({ ...e,
        ttlRemaining: e.expiresAtTick - currentTick })) };
  }
  return { address, evictExpired, lookup, snapshot };
}`,
  },
  router: {
    file: 'js/sim/router.js',
    code: `createRouter({ leftAddress = '10.65', rightAddress = '20.1' } = {}) {
  // both interfaces must be mini-IPs on different subnets
  let left = null, right = null, routed = 0;
  function exitFor(to) {
    const net = netOf(to);  // exit on the interface that fronts the target
    if (net === netOf(rightAddress)) return { network: right, exit: rightAddress };
    if (net === netOf(leftAddress)) return { network: left, exit: leftAddress };
    throw new Error(\`router: no route to subnet \${net} (target \${to})\`);
  }
  return {
    attach({ left, right }) { left = left; right = right; },
    forward({ from, to, request, isYou = false }) {  // exactly one hop
      routed += 1;
      const { network, exit } = exitFor(to);
      if (to === exit) {  // the router's own interface ends the frame (6a)
        return { from, to, request, isYou,
          response: \`200 Router \${to} (cross-subnet edge)\` };
      }
      return { ...network.send({ from, to, request }), isYou };
    },
    forwardQueue({ id, from, to, request, atTick, isYou = false }) {
      routed += 1;
      const { network, exit } = exitFor(to);
      if (to === exit) throw new Error('no worker behind the router (stage 6a)');
      network.deliverToQueue({ id, from, to, request, atTick, isYou });
    },
    snapshot() { return { leftAddress, rightAddress, routed }; },
  };
}`,
  },
};
