// DOCUMENTS: Stage 6 orrery nodes — the DNS resolver card (#node-dns), the
// cross-subnet Router card (#node-router), their wire-lane chips, and the
// live stage-pill-6 button. Built here rather than in panel.html because
// that page sits at its 550-line cap (the same split the teaching drawer
// took); the cards are selected by panel.js's own .node-card wiring, and
// all content is textContent/attribute only — no inline handlers or styles
// (AGENTS.md CSP rule).
export function initStage6Nodes() {
  const world = document.getElementById('orrery-world');

  const dns = document.createElement('article');
  dns.className = 'node-card';
  dns.id = 'node-dns';
  dns.dataset.testid = 'node-dns';
  dns.dataset.component = 'dns';
  dns.hidden = true;
  const dnsHead = document.createElement('header');
  dnsHead.className = 'node-head';
  const dnsName = document.createElement('div');
  dnsName.className = 'node-name';
  const dnsRole = document.createElement('span');
  dnsRole.className = 'role-name';
  dnsRole.textContent = 'DNS';
  const dnsSub = document.createElement('span');
  dnsSub.className = 'node-subtitle';
  dnsSub.textContent = 'resolver + tick-TTL ledger';
  dnsName.append(dnsRole, dnsSub);
  const dnsChip = document.createElement('span');
  dnsChip.className = 'ip-chip';
  dnsChip.textContent = '10.60';
  const dnsCode = document.createElement('span');
  dnsCode.className = 'code-chip';
  dnsCode.textContent = '</> Code';
  dnsHead.append(dnsName, dnsChip, dnsCode);
  const dnsStats = document.createElement('p');
  dnsStats.id = 'dns-stats';
  dnsStats.dataset.testid = 'dns-stats';
  dnsStats.className = 'mono last-frame';
  dnsStats.textContent = 'Lookups: 0 · Cached hits: 0 · TTL: 300t';
  const dnsEntries = document.createElement('ul');
  dnsEntries.id = 'dns-entries-list';
  dnsEntries.dataset.testid = 'dns-entries-list';
  dnsEntries.className = 'route-list';
  dnsEntries.setAttribute('aria-label', 'Resolver cache');
  dns.append(dnsHead, dnsStats, dnsEntries);
  world.appendChild(dns);

  const router = document.createElement('article');
  router.className = 'node-card';
  router.id = 'node-router';
  router.dataset.testid = 'node-router';
  router.dataset.component = 'router';
  router.hidden = true;
  const routerHead = document.createElement('header');
  routerHead.className = 'node-head';
  const routerName = document.createElement('div');
  routerName.className = 'node-name';
  const routerRole = document.createElement('span');
  routerRole.className = 'role-name';
  routerRole.textContent = 'Router';
  const routerSub = document.createElement('span');
  routerSub.className = 'node-subtitle';
  routerSub.textContent = 'cross-subnet edge';
  routerName.append(routerRole, routerSub);
  const routerChip = document.createElement('span');
  routerChip.className = 'ip-chip';
  routerChip.textContent = '10.65 ⇄ 20.1';
  const routerCode = document.createElement('span');
  routerCode.className = 'code-chip';
  routerCode.textContent = '</> Code';
  routerHead.append(routerName, routerChip, routerCode);
  const routerStats = document.createElement('p');
  routerStats.id = 'router-stats';
  routerStats.dataset.testid = 'router-stats';
  routerStats.className = 'mono last-frame';
  routerStats.textContent = 'Routed: 0 · 10.65 ⇄ 20.1';
  router.append(routerHead, routerStats);
  world.appendChild(router);

  // The DNS wire lane chips ride the browser↔DNS wire in world space
  // (viewport.js anchors them through LANE_WIRES).
  const wire = document.createElement('div');
  wire.id = 'wire-dns';
  wire.className = 'wire-column';
  wire.hidden = true;
  wire.setAttribute('aria-hidden', 'true');
  const reqLane = document.createElement('div');
  reqLane.id = 'packet-req-dns';
  reqLane.className = 'wire-lane';
  reqLane.textContent = 'DNS ask =>';
  const resLane = document.createElement('div');
  resLane.id = 'packet-res-dns';
  resLane.className = 'wire-lane reverse';
  resLane.textContent = '<- answer';
  wire.append(reqLane, resLane);
  world.appendChild(wire);

  // The live Stage 6 pill: same shape as the static pills 1-5 (created
  // here only because panel.html sits at its 550-line cap).
  const pill = document.createElement('button');
  pill.type = 'button';
  pill.dataset.testid = 'stage-pill-6';
  pill.dataset.stage = '6';
  pill.className = 'stage-pill';
  pill.textContent = '6 · Multi-Net / CDN';
  document.querySelector('.stage-ladder').appendChild(pill);

  // Inspector tabs for the two new components (same shape as the static
  // comp-tab buttons).
  const tabs = document.querySelector('.comp-tabs');
  for (const name of ['dns', 'router']) {
    const tab = document.createElement('button');
    tab.type = 'button';
    tab.className = 'comp-tab';
    tab.dataset.select = name;
    tab.textContent = name;
    tabs.appendChild(tab);
  }
}
