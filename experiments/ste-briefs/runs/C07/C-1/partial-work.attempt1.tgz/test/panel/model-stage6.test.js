import { describe, it, expect } from 'vitest';
import { describeSnapshot } from '../../js/panel/model.js';
import { componentTitle, formatComponentState } from '../../js/panel/inspector-state.js';

// Stage-boundary extraction (guard-file-size): the Stage 6 DNS/hosted
// narrative and the dns/router inspector state are pinned here, following
// the model-stage34 / model-stage5 splits.

// A served GET record as the Stage 5 / Stage 6 traces carry it.
const traceBase = {
  hop: 6,
  method: 'GET',
  path: '/about',
  request: 'GET /about',
  targetServer: '10.11',
  cacheStatus: 'MISS',
  dbOp: 'SELECT',
  dbStale: false,
  response: '200 This is the about page',
  status: 200,
  body: 'This is the about page',
  routeId: 'about',
  asyncJob: false,
};

const stage6Env = {
  dns: {
    address: '10.60',
    ttlTicks: 300,
    lookups: 1,
    cachedHits: 1,
    evictions: 0,
    lastLookup: { name: 'example.com', status: 'OK', source: 'cache', target: '10.1', atTick: 2 },
    authoritative: [{ name: 'example.com', target: '10.1' }],
    cache: [
      {
        name: 'example.com',
        target: '10.1',
        cachedAtTick: 0,
        expiresAtTick: 300,
        ttlRemaining: 298,
      },
    ],
  },
  router: { leftAddress: '10.65', rightAddress: '20.1', routed: 0 },
};

describe('describeSnapshot stage 6', () => {
  it('describes Stage 6 hosted DNS trace labels and dns/router inspector state', () => {
    const snap = {
      stage: 6,
      tick: 3,
      users: 5,
      serverAddress: '10.1',
      queueDepth: 0,
      served: 1,
      avgLatencyTicks: 1,
      cache: { address: '10.20', ttlTicks: 10 },
      database: {
        primaryAddress: '10.30',
        replicaAddress: '10.31',
        replicationLagTicks: 3,
      },
      workerQueue: { address: '10.40', workerAddress: '10.41' },
      ...stage6Env,
      trace: {
        ...traceBase,
        hop: 2,
        hosted: true,
        host: 'example.com',
        httpPath: '/about',
        request: 'GET example.com/about',
        path: 'example.com/about',
        dnsStatus: 'OK',
        resolvedTarget: '10.1',
        nx: false,
      },
    };
    const labels = describeSnapshot(snap);
    expect(labels.stage).toBe(6);
    expect(labels.totalHops).toBe(10);
    expect(labels.hopStatus).toBe('Hop 2/10: DNS (10.60) -> 10.2 — example.com = 10.1');

    // Every hosted hop reads as its own sentence: 2 DNS hops in front of
    // the Stage 5 story.
    const hopLabels = (hop, over = {}) =>
      describeSnapshot({ ...snap, trace: { ...snap.trace, hop, ...over } }).hopStatus;
    expect(hopLabels(1)).toBe(
      'Hop 1/10: Browser (10.2) emits "GET example.com/about" — DNS ask example.com @ 10.60',
    );
    expect(hopLabels(3)).toBe(
      'Hop 3/10: Browser (10.2) emits "GET /about" (resolved example.com = 10.1)',
    );
    expect(hopLabels(4)).toBe('Hop 4/10: Network (10.x) routes to LoadBalancer (10.1)');
    expect(hopLabels(5)).toBe('Hop 5/10: LoadBalancer (10.1) -> 10.11 queue');
    expect(hopLabels(6)).toBe('Hop 6/10: Database SELECT @ Replica (10.31) — fresh');
    expect(hopLabels(7)).toBe(
      'Hop 7/10: WebServer (10.11) -> "200 This is the about page" (cache MISS)',
    );
    expect(hopLabels(8)).toBe('Hop 8/10: Network delivers 200 response to 10.2');
    expect(hopLabels(9)).toBe('Hop 9/10: Browser (10.2) received and displayed 200');
    expect(hopLabels(10)).toBe('Hop 10/10: Worker (10.41) idle — no async jobs in this trace');
    expect(hopLabels(11)).toBe('Idle — type a path and click Go or Step 1 Hop ->');

    // The HUD labels mirror the live ledger and the routed counter.
    expect(labels.dnsStatsLabel).toBe('Lookups: 1 · Cached hits: 1 · TTL: 300t');
    expect(labels.dnsEntries).toEqual(stage6Env.dns.cache);
    expect(labels.routerStatsLabel).toBe('Routed: 0 · 10.65 ⇄ 20.1');

    // The inspector carries the ledger row-for-row and the router hop count.
    const dnsState = JSON.parse(formatComponentState(snap, 'dns'));
    expect(dnsState).toEqual(stage6Env.dns);
    const routerState = JSON.parse(formatComponentState(snap, 'router'));
    expect(routerState).toEqual(stage6Env.router);
    expect(componentTitle(snap, 'dns')).toBe('DNS — mini-IP 10.60');
    expect(componentTitle(snap, 'router')).toBe('Router — 10.65 ⇄ 20.1');
  });

  it('a host-less GET /about on Stage 6 keeps the Stage 5 hop story byte-identical', () => {
    const hostLess = (stage) => ({
      stage,
      tick: 2,
      users: 5,
      serverAddress: '10.1',
      queueDepth: 0,
      served: 1,
      avgLatencyTicks: 1,
      cache: { address: '10.20', ttlTicks: 10 },
      database: {
        primaryAddress: '10.30',
        replicaAddress: '10.31',
        replicationLagTicks: 3,
      },
      workerQueue: { address: '10.40', workerAddress: '10.41' },
      ...(stage === 6 ? stage6Env : {}),
      trace: { ...traceBase, ...(stage === 6 ? { hosted: false, nx: false } : {}) },
    });
    // CHECKS (named counter-example): the same GET /about trace narrates the
    // Stage 5 sentences verbatim on Stage 6 — same denominator, same words.
    const stage5 = Array.from(
      { length: 8 },
      (_, i) => describeSnapshot({ ...hostLess(5), trace: { ...traceBase, hop: i + 1 } }).hopStatus,
    );
    const stage6 = Array.from(
      { length: 8 },
      (_, i) => describeSnapshot({ ...hostLess(6), trace: { ...traceBase, hop: i + 1 } }).hopStatus,
    );
    expect(stage6).toEqual(stage5);
    expect(stage6[0]).toBe('Hop 1/8: Browser (10.2) emits "GET /about"');
    expect(stage6[7]).toBe('Hop 8/8: Worker (10.41) idle — no async jobs in this trace');
    expect(describeSnapshot(hostLess(6)).totalHops).toBe(8);
  });

  it('the NX path narrates ask + answer + render with no GET hop', () => {
    const snap = {
      stage: 6,
      tick: 1,
      users: 5,
      serverAddress: '10.1',
      queueDepth: 0,
      served: 0,
      avgLatencyTicks: 0,
      ...stage6Env,
      dns: {
        ...stage6Env.dns,
        lookups: 1,
        cachedHits: 0,
        lastLookup: {
          name: 'nope.example',
          status: 'NX',
          source: 'authoritative',
          target: null,
          atTick: 0,
        },
        cache: [],
      },
      trace: {
        ...traceBase,
        hop: 2,
        hosted: true,
        host: 'nope.example',
        httpPath: '/about',
        request: 'GET nope.example/about',
        path: 'nope.example/about',
        dnsStatus: 'NX',
        resolvedTarget: null,
        nx: true,
      },
    };
    expect(describeSnapshot(snap).totalHops).toBe(3);
    const hopLabels = (hop) =>
      describeSnapshot({ ...snap, trace: { ...snap.trace, hop } }).hopStatus;
    expect(hopLabels(1)).toBe(
      'Hop 1/3: Browser (10.2) emits "GET nope.example/about" — DNS ask nope.example @ 10.60',
    );
    expect(hopLabels(2)).toBe('Hop 2/3: DNS (10.60) -> 10.2 — nope.example = NX no record');
    expect(hopLabels(3)).toBe('Hop 3/3: Browser (10.2) renders NX no record — no GET emitted');
  });
});
