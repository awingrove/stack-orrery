import { describe, it, expect } from 'vitest';
import { createRouter } from '../../js/sim/router.js';
import { createNetwork } from '../../js/sim/network.js';
import { createWebServer } from '../../js/sim/webserver.js';

describe('createRouter', () => {
  it('rejects invalid mini-IP interfaces and both interfaces on the same subnet', () => {
    expect(() => createRouter({ leftAddress: '1065' })).toThrow(/invalid mini-IP/);
    expect(() => createRouter({ rightAddress: '201' })).toThrow(/invalid mini-IP/);
    expect(() => createRouter({ leftAddress: '10.65', rightAddress: '10.1' })).toThrow(
      /different subnets/,
    );
  });

  it('same-subnet sends keep the network contract unchanged with the router attached', () => {
    const router = createRouter();
    const left = createNetwork({ subnet: '10', gateway: router });
    const right = createNetwork({ subnet: '20', gateway: router });
    router.attach({ left, right });
    left.registerServer('10.1', createWebServer({ address: '10.1' }));

    // A same-subnet frame resolves on the left network exactly as in
    // Stages 1-5 — the router never sees it.
    expect(left.send({ from: '10.2', to: '10.1', request: 'GET /about' })).toEqual({
      from: '10.2',
      to: '10.1',
      request: 'GET /about',
      response: '200 This is the about page',
    });
    expect(router.snapshot()).toEqual({ leftAddress: '10.65', rightAddress: '20.1', routed: 0 });

    // A subnet neither interface fronts fails loud at the router.
    expect(() => left.send({ from: '10.2', to: '11.1', request: 'GET /' })).toThrow(
      /no route to subnet 11/,
    );
  });

  it('a cross-subnet frame takes exactly one router hop and increments routed', () => {
    const router = createRouter();
    const left = createNetwork({ subnet: '10', gateway: router });
    const right = createNetwork({ subnet: '20', gateway: router });
    router.attach({ left, right });

    // CHECKS: the frame 10.x -> 20.1 rides exactly one router hop — the
    // counter increments once, and the router's 20-side interface is the
    // only reachable target in Stage 6a, so the frame terminates there.
    const record = left.send({ from: '10.2', to: '20.1', request: 'GET /' });
    expect(record).toEqual({
      from: '10.2',
      to: '20.1',
      request: 'GET /',
      isYou: false,
      response: '200 Router 20.1 (cross-subnet edge)',
    });
    expect(router.snapshot()).toEqual({ leftAddress: '10.65', rightAddress: '20.1', routed: 1 });

    // The next cross-subnet frame is its own single hop.
    left.send({ from: '10.2', to: '20.1', request: 'GET /about' });
    expect(router.snapshot().routed).toBe(2);
  });

  it('an unregistered subnet-20 host fails loud (20.9)', () => {
    const router = createRouter();
    const left = createNetwork({ subnet: '10', gateway: router });
    const right = createNetwork({ subnet: '20', gateway: router });
    router.attach({ left, right });
    // CHECKS: subnet 20 holds nothing but the router's own presence in 6a —
    // a send into 20.9 resolves on the right network and throws, mirroring
    // the fail-loud contract of the 10.x fabric.
    expect(() => left.send({ from: '10.2', to: '20.9', request: 'GET /' })).toThrow(
      /no server at 20\.9/,
    );
    // The queued path fails loud the same way.
    expect(() =>
      left.deliverToQueue({ id: '1:1', from: '10.2', to: '20.9', request: 'GET /', atTick: 1 }),
    ).toThrow(/no server at 20\.9/);
  });
});
