import { describe, it, expect } from 'vitest';
import { createDns } from '../../js/sim/dns.js';

describe('createDns', () => {
  it('consults the authoritative table only on a miss or an expired entry — a live ledger hit answers with no consult', () => {
    const dns = createDns({ address: '10.60', ttlTicks: 5 });

    // Cold lookup: one authoritative consult, and the ledger fills with the
    // resolved name (cached at tick 0, alive through tick 4).
    expect(dns.lookup('example.com', 0)).toEqual({
      status: 'OK',
      target: '10.1',
      source: 'authoritative',
    });
    let snap = dns.snapshot(0);
    expect(snap.lookups).toBe(1);
    expect(snap.cachedHits).toBe(0);
    expect(snap.cache).toEqual([
      {
        name: 'example.com',
        target: '10.1',
        cachedAtTick: 0,
        expiresAtTick: 5,
        ttlRemaining: 5,
      },
    ]);
    expect(snap.lastLookup).toEqual({
      name: 'example.com',
      status: 'OK',
      source: 'authoritative',
      target: '10.1',
      atTick: 0,
    });

    // CHECKS: a hit inside ttlTicks increments cachedHits with NO
    // authoritative consult — lastLookup records the cache branch.
    expect(dns.lookup('example.com', 4)).toEqual({
      status: 'OK',
      target: '10.1',
      source: 'cache',
    });
    snap = dns.snapshot(4);
    expect(snap.lookups).toBe(2);
    expect(snap.cachedHits).toBe(1);
    expect(snap.lastLookup).toEqual({
      name: 'example.com',
      status: 'OK',
      source: 'cache',
      target: '10.1',
      atTick: 4,
    });

    // CHECKS (named counter-example): an expired entry is NOT answered from
    // the ledger — tick 5 is the first tick the entry is gone, the lookup
    // evicts it and re-consults the authoritative table (cachedHits stays).
    expect(dns.lookup('example.com', 5)).toEqual({
      status: 'OK',
      target: '10.1',
      source: 'authoritative',
    });
    snap = dns.snapshot(5);
    expect(snap.cachedHits).toBe(1);
    expect(snap.evictions).toBe(1);
    expect(snap.cache[0]).toMatchObject({ expiresAtTick: 10, ttlRemaining: 5 });
    expect(snap.lastLookup).toEqual({
      name: 'example.com',
      status: 'OK',
      source: 'authoritative',
      target: '10.1',
      atTick: 5,
    });
  });

  it('an unknown name answers NX with no cache entry and no throw', () => {
    const dns = createDns();
    expect(dns.lookup('nope.example', 0)).toEqual({ status: 'NX' });
    const snap = dns.snapshot(0);
    expect(snap.cache).toEqual([]);
    expect(snap.cachedHits).toBe(0);
    expect(snap.lastLookup).toEqual({
      name: 'nope.example',
      status: 'NX',
      source: 'authoritative',
      target: null,
      atTick: 0,
    });
    // The authoritative table is in-component and Stage 6a carries exactly
    // one name (Stage 6b adds the CDN edge).
    expect(snap.authoritative).toEqual([{ name: 'example.com', target: '10.1' }]);
    expect(snap.address).toBe('10.60');
    expect(snap.ttlTicks).toBe(300);
  });

  it('rejects an invalid mini-IP address and a non-positive or non-integer ttlTicks', () => {
    expect(() => createDns({ address: '1060' })).toThrow(/invalid mini-IP/);
    expect(() => createDns({ ttlTicks: 0 })).toThrow(/ttlTicks/);
    expect(() => createDns({ ttlTicks: 2.5 })).toThrow(/ttlTicks/);
  });
});
