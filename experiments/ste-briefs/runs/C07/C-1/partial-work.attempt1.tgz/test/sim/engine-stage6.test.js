import { describe, it, expect } from 'vitest';
import { createEngine } from '../../js/sim/engine.js';

describe('stage 6 engine wiring', () => {
  it('instantiates DNS 10.60 and the cross-subnet Router and exposes them on the snapshot', () => {
    const engine = createEngine({ stage: 6 });
    const snap = engine.snapshot();
    expect(snap.dns).toMatchObject({
      address: '10.60',
      ttlTicks: 300,
      lookups: 0,
      cachedHits: 0,
    });
    expect(snap.router).toEqual({ leftAddress: '10.65', rightAddress: '20.1', routed: 0 });
    // The Stage 5 topology is untouched beneath the new components.
    expect(snap.servers.map((s) => s.address)).toEqual(['10.11', '10.12']);
    expect(snap.cache.address).toBe('10.20');
    expect(snap.database.primaryAddress).toBe('10.30');
    expect(snap.workerQueue.address).toBe('10.40');
    // Stages 1-5 expose neither component.
    expect(createEngine({ stage: 5 }).snapshot().dns).toBe(null);
    expect(createEngine({ stage: 5 }).snapshot().router).toBe(null);
    expect(createEngine({ stage: 1 }).snapshot().dns).toBe(null);
  });

  it('a hosted trace asks DNS 10.60, resolves example.com = 10.1, and rides the Stage 5 chain at 10 hops', () => {
    const engine = createEngine({ stage: 6 });
    engine.traceHop({ method: 'GET', path: 'example.com/about' });
    let snap = engine.snapshot();
    expect(snap.trace.hop).toBe(1);
    expect(snap.trace.hosted).toBe(true);
    expect(snap.trace.host).toBe('example.com');
    expect(snap.trace.request).toBe('GET example.com/about');
    expect(snap.dns.lookups).toBe(1);
    expect(snap.lastFrame).toBe('10.2 -> 10.60 | GET example.com/about (DNS ask example.com)');

    engine.traceHop({ method: 'GET', path: 'example.com/about' });
    snap = engine.snapshot();
    expect(snap.trace.resolvedTarget).toBe('10.1');
    expect(snap.dns.cachedHits).toBe(0);
    expect(snap.lastFrame).toBe('10.60 -> 10.2 | DNS answer example.com = 10.1');

    // Hops 3-10: the resolved GET rides the Stage 5 story; the ledger entry
    // lives for ttlTicks (300) and the 200 response lands on the browser.
    for (let hop = 0; hop < 8; hop++) {
      engine.traceHop({ method: 'GET', path: 'example.com/about' });
    }
    snap = engine.snapshot();
    expect(snap.trace.hop).toBe(10);
    expect(snap.trace.request).toBe('GET /about');
    expect(snap.browserDisplay).toMatchObject({ status: 200, body: 'This is the about page' });
    expect(snap.servers.map((s) => s.served)).toEqual([1, 0]);

    // The second hosted trace answers from the ledger: cachedHits +1 with
    // no authoritative consult (lastLookup records the cache branch).
    engine.traceHop({ method: 'GET', path: 'example.com/about' });
    snap = engine.snapshot();
    expect(snap.dns.cachedHits).toBe(1);
    expect(snap.dns.lookups).toBe(2);
    expect(snap.dns.lastLookup).toMatchObject({ source: 'cache', target: '10.1' });
  });

  it('a host-less GET /about keeps the Stage 5 trace shape with no DNS consult', () => {
    const engine = createEngine({ stage: 6 });
    for (let hop = 0; hop < 8; hop++) engine.traceHop({ method: 'GET', path: '/about' });
    const snap = engine.snapshot();
    expect(snap.trace.hop).toBe(8);
    expect(snap.trace.hosted).toBe(false);
    expect(snap.trace.request).toBe('GET /about');
    // Plain paths never touch DNS: zero lookups, an empty ledger.
    expect(snap.dns.lookups).toBe(0);
    expect(snap.dns.cache).toEqual([]);
    expect(snap.browserDisplay).toMatchObject({ status: 200, body: 'This is the about page' });
  });

  it('nope.example/about renders NX without emitting a GET', () => {
    const engine = createEngine({ stage: 6 });
    engine.traceHop({ method: 'GET', path: 'nope.example/about' });
    expect(engine.snapshot().trace.hop).toBe(1);
    engine.traceHop({ method: 'GET', path: 'nope.example/about' });
    let snap = engine.snapshot();
    expect(snap.trace.nx).toBe(true);
    expect(snap.lastFrame).toBe('10.60 -> 10.2 | DNS answer nope.example = NX no record');
    // No GET has left the browser: the servers stay drained.
    expect(snap.servers.every((s) => s.served === 0)).toBe(true);

    engine.traceHop({ method: 'GET', path: 'nope.example/about' });
    snap = engine.snapshot();
    expect(snap.trace.hop).toBe(3);
    expect(snap.browserDisplay).toMatchObject({ status: 'NX', body: 'no record' });
    expect(snap.servers.every((s) => s.served === 0)).toBe(true);
    expect(snap.dns.lookups).toBe(1);
    expect(snap.dns.cache).toEqual([]);
  });
});
