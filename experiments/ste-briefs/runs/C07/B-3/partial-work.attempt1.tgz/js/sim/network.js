// DOCUMENTS: the network — the wiring that lets two-number mini-IP
// addressable components exchange messages. Today it carries slim HTTP
// requests to a registered server; later stages attach more components
// without changing the send/enqueue contract. Stage 6 adds optional
// cross-subnet routing: a network declared with a subnet number hands any
// frame addressed outside that subnet to its attached Router (exactly one
// router hop), while undeclared networks keep the single-fabric behavior —
// resolve throws for any unknown host.
//
// CHECKS: every address crossing the wire is validated as a two-number
// mini-IP (<net>.<host>), and sends to unregistered hosts fail loud.
const MINI_IP = /^\d+\.\d+$/;

const netOf = (addr) => Number(String(addr).split('.')[0]);

export function createNetwork({ subnet = null } = {}) {
  const servers = new Map();
  let router = null;

  function validate(addr) {
    if (!MINI_IP.test(addr)) {
      throw new Error(`network: invalid mini-IP address ${addr}`);
    }
  }

  function resolve(address) {
    validate(address);
    const server = servers.get(address);
    if (!server) {
      throw new Error(`network: no server at ${address}`);
    }
    return server;
  }

  // CHECKS: the cross-subnet branch conditions on the declared subnet —
  // same-subnet targets resolve locally as always, foreign targets need an
  // attached router (loud throw without one), and an undeclared network
  // (subnet === null) keeps today's single-fabric behavior untouched.
  function gatewayFor(to) {
    if (subnet === null) return null;
    const net = netOf(to);
    if (net === subnet) return null;
    if (!router) {
      throw new Error(`network: no route to subnet ${net} — no router attached`);
    }
    return router;
  }

  return {
    registerServer(address, server) {
      validate(address);
      servers.set(address, server);
    },

    resolve,

    attachRouter(attached) {
      router = attached;
    },

    send({ from, to, request }) {
      validate(from);
      validate(to);
      const gateway = gatewayFor(to);
      if (gateway) return gateway.route({ from, to, request });
      const server = resolve(to);
      const response = server.handleRequest(request);
      return { from, to, request, response };
    },

    // `isYou` rides through untouched: the engine marks the learner's own
    // interactive-browser request, the server stores it on the queue row.
    deliverToQueue({ id, from, to, request, atTick, isYou = false }) {
      validate(from);
      validate(to);
      const gateway = gatewayFor(to);
      if (gateway) {
        gateway.routeToQueue({ id, from, to, request, atTick, isYou });
        return;
      }
      const server = resolve(to);
      server.enqueue({ id, from, to, request, atTick, isYou });
    },
  };
}
