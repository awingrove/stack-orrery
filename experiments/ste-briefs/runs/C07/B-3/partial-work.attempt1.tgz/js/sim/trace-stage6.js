// DOCUMENTS: the Stage 6 hop-by-hop trace machine — branches on whether the
// browser path carries a host ("example.com/about") or is host-less
// ("/about"). Host-less runs delegate to an inner Stage 5 machine, so the
// Stage 5 hop story stays byte-identical: no DNS hop, no cross-subnet hop.
// A hosted run spends exactly two DNS hops — the Browser ask (the resolver
// consults its ledger or table right there, so the hop total is known from
// hop 1), then the DNS answer delivery — before the browser emits the GET
// with the resolved mini-IP target, riding the same Stage 5 chain
// underneath (outer hop = inner hop + 2). An unknown name answers
// "NX no record" and the run ends at the answer: the browser renders the NX
// card and emits no GET.
//
// CHECKS: the machine is constructed only for Stage 6 (the engine wires it
// there); the inner machine keeps its own Stage 5 validation.
import { createTraceMachine } from './trace.js';

// CHECKS: the hosted-path grammar splits on the first "/" — a path that
// starts with "/" carries no host; anything else names one. Named
// counter-example: "/about" yields host null (the Stage 5 story),
// "example.com/about" yields host "example.com" + hostPath "/about", and a
// bare "example.com" reads as host with root path "/".
export function splitHostPath(path = '/') {
  const raw = String(path);
  if (raw.startsWith('/')) return { host: null, hostPath: raw };
  const cut = raw.indexOf('/');
  if (cut === -1) return { host: raw, hostPath: '/' };
  return { host: raw.slice(0, cut), hostPath: raw.slice(cut) };
}

const BLANK_TRACE = {
  targetServer: null,
  cacheStatus: null,
  dbOp: null,
  dbStale: false,
  asyncJob: false,
  response: null,
  status: null,
  body: null,
  routeId: null,
};

export function createStage6Trace({
  serverAddress,
  servers,
  lb,
  network,
  cache,
  database,
  workerQueue,
  dns,
  bumpTick,
  getTick,
  onServe,
  onFinish,
}) {
  if (!dns) {
    throw new Error('trace: stage 6 needs the DNS resolver attached');
  }
  // The inner Stage 5 machine owns the post-DNS hop chain verbatim: same
  // frames, same queue machinery, same served-record handling.
  const inner = createTraceMachine({
    stage: 5,
    serverAddress,
    servers,
    lb,
    network,
    cache,
    database,
    workerQueue,
    bumpTick,
    getTick,
    onServe,
    onFinish,
  });

  // The hosted run's state rides here, phase by phase (each names the next
  // pending hop): 'ask' (hop 1), 'answered' (hop 2 delivery), then 'chained'
  // while the inner Stage 5 machine walks hops 3..10 (outer = inner + 2).
  // run === null means a host-less run is live (or none started yet); done
  // marks the NX run as over.
  let run = null;

  function startRun({ method = 'GET', path = '/about', from = '10.2' } = {}) {
    const parsed = splitHostPath(path);
    if (!parsed.host) {
      run = null;
      return inner.step({ method, path, from });
    }
    run = {
      host: parsed.host,
      hostPath: parsed.hostPath,
      method,
      from,
      request: `${method} ${parsed.hostPath}`,
      dnsStatus: null,
      dnsTarget: null,
      phase: 'ask',
      nx: false,
      done: false,
    };
    return null;
  }

  return {
    // One hop per call. Returns the hop's lastFrame string, or null when
    // nothing moved (the engine keeps its previous frame then).
    step({ method = 'GET', path = '/about', from = '10.2' } = {}) {
      const innerHop = inner.snapshot().hop;
      // A new run starts only when no run is live: the NX run is done, or a
      // chained hosted run has walked the full inner chain (inner hop 8).
      // The ask/answer phases continue their own run instead. A host-less
      // start delegates straight to the inner machine (hop 1 executes in
      // this same call); a hosted start falls through to the ask below.
      if (run === null || run.done || (run.phase === 'chained' && innerHop >= 8)) {
        const started = startRun({ method, path, from });
        if (!run) return started;
      }
      if (run.phase === 'ask') {
        // Hop 1: the browser asks and the resolver consults its ledger or
        // its table right there — a live-entry hit, an authoritative fill,
        // or the NX dead end; the answer is known before it is delivered.
        const result = dns.lookup(run.host, getTick());
        run.dnsStatus = result.status;
        run.dnsTarget = result.target ?? null;
        run.nx = result.status === 'NX';
        run.phase = 'answered';
        return `Browser (${run.from}) asks DNS (${dns.address}) for "${run.host}"`;
      }
      if (run.phase === 'answered') {
        // Hop 2: the resolver delivers the answer it resolved at the ask.
        if (run.nx) {
          run.done = true;
          onFinish({
            from: dns.address,
            to: run.from,
            request: `DNS ${run.host}`,
            response: 'NX no record',
          });
          return `DNS (${dns.address}) -> Browser (${run.from}) | NX no record`;
        }
        run.phase = 'chained';
        return `DNS (${dns.address}) -> Browser (${run.from}) | ${
          run.dnsTarget
        } (${run.dnsStatus === 'HIT' ? 'cache HIT' : 'authoritative'})`;
      }
      // Hosted resolved run, outer hops 3..10: the inner Stage 5 machine
      // walks its chain with the host path (outer hop = inner hop + 2).
      return inner.step({ method: run.method, path: run.hostPath, from: run.from });
    },

    snapshot() {
      const innerSnap = inner.snapshot();
      if (!run) {
        return { ...innerSnap, host: null, dnsName: null, dnsStatus: null, dnsTarget: null };
      }
      const dnsFields = {
        host: run.host,
        dnsName: run.host,
        dnsStatus: run.dnsStatus,
        dnsTarget: run.dnsTarget,
      };
      if (run.done) {
        return {
          hop: 2,
          method: run.method,
          path: run.hostPath,
          from: run.from,
          request: `DNS ${run.host}`,
          ...BLANK_TRACE,
          response: 'NX no record',
          status: 'NX',
          body: 'no record',
          ...dnsFields,
        };
      }
      if (run.phase === 'ask' || run.phase === 'answered') {
        // The DNS-only phase of a hosted run: the inner machine has not
        // started this run's chain. The ask hop (1) already carries the
        // resolution when it executed; the answer delivery is hop 2.
        return {
          hop: 1,
          method: run.method,
          path: run.hostPath,
          from: run.from,
          request: run.request,
          ...BLANK_TRACE,
          ...dnsFields,
        };
      }
      const head =
        innerSnap.hop === 0
          ? { method: run.method, path: run.hostPath, from: run.from, request: run.request }
          : {};
      return { ...innerSnap, hop: innerSnap.hop + 2, ...head, ...dnsFields };
    },
  };
}
