// DOCUMENTS: the Stage 6 component — an authoritative DNS resolver with a
// tick-TTL cache ledger. The authoritative table is in-component
// (example.com -> 10.1; Stage 6b adds the CDN name). A lookup consults the
// table only on a cache miss or an expired entry: a hit inside ttlTicks is
// an incrementing cachedHits with NO authoritative consult, exactly like
// cache.js's Map lookup on the request path (a real Map check, not a rate).
//
// CHECKS: the constructor rejects an address that is not a two-number
// mini-IP, a ttlTicks that is not a positive integer, and a record table
// whose name is empty or whose target is not a mini-IP (fail-loud over
// silent mis-configuration). An unknown name answers { status: 'NX' }
// without throwing at the DNS layer; the throw rule belongs to cross-subnet
// addresses (router.js).
export function createDns({
  address = '10.60',
  ttlTicks = 300,
  records = { 'example.com': '10.1' },
} = {}) {
  if (!/^\d+\.\d+$/.test(address)) {
    throw new Error(`dns: invalid mini-IP address ${address}`);
  }
  if (!Number.isInteger(ttlTicks) || ttlTicks < 1) {
    throw new Error(`dns: ttlTicks must be a positive integer, got ${ttlTicks}`);
  }
  for (const [name, target] of Object.entries(records)) {
    if (typeof name !== 'string' || name.trim() === '') {
      throw new Error('dns: record names must be non-empty strings');
    }
    if (!/^\d+\.\d+$/.test(String(target))) {
      throw new Error(`dns: record ${name} targets invalid mini-IP ${target}`);
    }
  }
  const cache = new Map(); // name -> { name, target, expiresAtTick }
  let lookups = 0;
  let cachedHits = 0;
  let authoritative = 0;
  let lastLookup = null;

  // An entry answers from the ledger only while currentTick is strictly
  // before its expiry: cached at tick T with ttlTicks = 300 means alive
  // through tick T + 299.
  function evictExpired(currentTick = 0) {
    for (const entry of cache.values()) {
      if (currentTick >= entry.expiresAtTick) {
        cache.delete(entry.name);
      }
    }
  }

  function lookup(name, currentTick = 0) {
    if (typeof name !== 'string' || name.trim() === '') {
      throw new Error(`dns: lookup name must be a non-empty string, got ${name}`);
    }
    lookups += 1;
    evictExpired(currentTick);
    const entry = cache.get(name);
    if (entry) {
      cachedHits += 1;
      lastLookup = { name, status: 'HIT', atTick: currentTick };
      return { status: 'HIT', target: entry.target };
    }
    // Miss or expired entry: the authoritative table answers, and the reply
    // refills the ledger with a fresh TTL.
    authoritative += 1;
    const target = records[name];
    if (!target) {
      lastLookup = { name, status: 'NX', atTick: currentTick };
      return { status: 'NX' };
    }
    cache.set(name, { name, target, expiresAtTick: currentTick + ttlTicks });
    lastLookup = { name, status: 'AUTH', atTick: currentTick };
    return { status: 'AUTH', target };
  }

  function snapshot(currentTick = 0) {
    evictExpired(currentTick);
    return {
      address,
      ttlTicks,
      lookups,
      cachedHits,
      authoritative,
      lastLookup,
      cache: [...cache.values()].map((e) => ({
        name: e.name,
        target: e.target,
        expiresAtTick: e.expiresAtTick,
        ttlRemaining: e.expiresAtTick - currentTick,
      })),
    };
  }

  return {
    get address() {
      return address;
    },
    evictExpired,
    lookup,
    snapshot,
  };
}
