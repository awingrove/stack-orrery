// DOCUMENTS: the Stage 6 component — a cross-subnet Router joining the 10.x
// and 20.x network instances at its two interfaces (10.65 on the left, 20.1
// on the right). Any frame addressed outside its own subnet rides exactly
// one router hop (the routed counter), then the far network resolves the
// target with its own fail-loud rule — a send into subnet 20 to an
// unregistered host (20.9) throws from the far network's resolve, mirroring
// network.js today. Same-subnet sends bypass the router entirely.
//
// CHECKS: the constructor rejects an interface that is not a two-number
// mini-IP and both interfaces sitting on the same subnet (a router with one
// subnet is a defect, not a hub).
const MINI_IP = /^\d+\.\d+$/;

const netOf = (addr) => Number(String(addr).split('.')[0]);

export function createRouter({ leftAddress = '10.65', rightAddress = '20.1' } = {}) {
  if (!MINI_IP.test(leftAddress)) {
    throw new Error(`router: invalid mini-IP leftAddress ${leftAddress}`);
  }
  if (!MINI_IP.test(rightAddress)) {
    throw new Error(`router: invalid mini-IP rightAddress ${rightAddress}`);
  }
  const leftNet = netOf(leftAddress);
  const rightNet = netOf(rightAddress);
  if (leftNet === rightNet) {
    throw new Error(`router: both interfaces sit on subnet ${leftNet}`);
  }
  let left = null;
  let right = null;
  let routed = 0;
  let lastFrame = null;

  const self = {
    get leftAddress() {
      return leftAddress;
    },
    get rightAddress() {
      return rightAddress;
    },

    // Joins the two networks and registers the router itself at each
    // interface address, so the 20-side edge (20.1 in Stage 6a — the only
    // reachable 20.x target until Stage 6b parks the CDN edge there) answers
    // a direct send instead of failing.
    join(leftNetwork, rightNetwork) {
      leftNetwork.registerServer(leftAddress, self);
      rightNetwork.registerServer(rightAddress, self);
      left = leftNetwork;
      right = rightNetwork;
    },

    // The wire-visible reply at the router's own interface. The 20-side edge
    // is the reachable cross-subnet target in 6a, so the reply names it —
    // whatever request pinged the interface, the edge answers itself.
    handleRequest() {
      return '200 Router 20.1';
    },

    // One router hop: pick the joined network that owns the target's subnet,
    // count the hop, and hand the frame over unchanged — the far network
    // applies its own resolve (and its own loud throw for 20.9).
    // CHECKS: routed counts frames accepted at the router hop, including one
    // the far subnet then rejects (20.9): the hop happened, the delivery died.
    route({ from, to, request }) {
      const net = netOf(to);
      const peer = net === rightNet ? right : net === leftNet ? left : null;
      if (!peer) {
        throw new Error(`router: no route to subnet ${net} (joined ${leftNet} and ${rightNet})`);
      }
      routed += 1;
      lastFrame = `${from} -> ${to} | routed cross-subnet (${request})`;
      return peer.send({ from, to, request });
    },

    routeToQueue(frame) {
      const net = netOf(frame.to);
      const peer = net === rightNet ? right : net === leftNet ? left : null;
      if (!peer) {
        throw new Error(`router: no route to subnet ${net} (joined ${leftNet} and ${rightNet})`);
      }
      routed += 1;
      lastFrame = `${frame.from} -> ${frame.to} | routed cross-subnet (${frame.request})`;
      peer.deliverToQueue(frame);
    },

    snapshot() {
      return { leftAddress, rightAddress, routed, lastFrame };
    },
  };
  return self;
}
