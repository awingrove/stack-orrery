// DOCUMENTS: wire-lane anchor config, split from viewport.js by
// responsibility (guard-file-size). Each wire lane sits on its wire in world
// coordinates (col-left on browser↔network, col-right on
// network↔webserver/lb, lb-backends centered between the two backend wires,
// servers-cache centered between the two cache wires). A value may pin a
// lane at a fraction t down its wire: Stage 5+ anchors the cache→db lane at
// t=0.3 so it clears the queue→worker crossing. Stage 6 anchors the DNS
// ask/answer lane on the browser↔DNS wire.
export const LANE_WIRES = {
  1: { 'wire-col-left': 'wire-browser-network', 'wire-col-right': 'wire-network-webserver' },
  2: { 'wire-col-left': 'wire-browser-network', 'wire-col-right': 'wire-network-lb' },
  3: { 'wire-col-left': 'wire-browser-network', 'wire-col-right': 'wire-network-lb' },
  4: {
    'wire-col-left': 'wire-browser-network',
    'wire-col-right': 'wire-network-lb',
    'wire-cache-db': 'wire-cache-db',
  },
  5: {
    'wire-col-left': 'wire-browser-network',
    'wire-col-right': 'wire-network-lb',
    'wire-cache-db': ['wire-cache-db', 0.3],
    'wire-cache-queue': 'wire-cache-queue',
    'wire-queue-worker': 'wire-queue-worker',
  },
  6: {
    'wire-col-left': 'wire-browser-network',
    'wire-col-right': 'wire-network-lb',
    'wire-cache-db': ['wire-cache-db', 0.3],
    'wire-cache-queue': 'wire-cache-queue',
    'wire-queue-worker': 'wire-queue-worker',
    'wire-col-dns': 'wire-browser-dns',
  },
};

// Lanes anchored between parallel wires — lb-backends shared across stages
// 2-6; servers-cache capped left of the Cache card it would otherwise clip.
export const LANES_BETWEEN = [
  {
    laneId: 'wire-lb-backends',
    stages: [2, 3, 4, 5, 6],
    wireIds: ['wire-lb-webserver', 'wire-lb-webserver-2'],
  },
  {
    laneId: 'wire-servers-cache',
    stages: [3, 4, 5, 6],
    wireIds: ['wire-webserver-cache', 'wire-webserver-2-cache'],
    capTo: 'node-cache',
    capDx: -175, // 15.5rem card half + chip half + margin, in world px
  },
];
