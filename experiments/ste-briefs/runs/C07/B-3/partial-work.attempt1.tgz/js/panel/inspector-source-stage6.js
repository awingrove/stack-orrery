// DOCUMENTS: the Stage 6 inspector code mirrors (DNS resolver, cross-subnet
// Router), split from inspector-source.js by responsibility
// (guard-file-size). js/sim/dns.js and js/sim/router.js are the executable
// truth; these strings render the same logic for learners.
export const STAGE6_SOURCE = {
  dns: {
    file: 'js/sim/dns.js',
    code: `createDns({ address = '10.60', ttlTicks = 300,
  records = { 'example.com': '10.1' } } = {}) {
  const cache = new Map(); // name -> { name, target, expiresAtTick }
  let lookups = 0, cachedHits = 0, authoritative = 0, lastLookup = null;
  function evictExpired(currentTick = 0) {
    for (const entry of cache.values()) {
      if (currentTick >= entry.expiresAtTick) cache.delete(entry.name);
    }
  }
  function lookup(name, currentTick = 0) {
    lookups += 1;
    evictExpired(currentTick);
    const entry = cache.get(name);
    if (entry) {  // live inside ttlTicks: the ledger answers, no table read
      cachedHits += 1;
      lastLookup = { name, status: 'HIT', atTick: currentTick };
      return { status: 'HIT', target: entry.target };
    }
    authoritative += 1;  // miss or expired: the table answers
    const target = records[name];
    if (!target) {  // unknown name: NX, never a throw here
      lastLookup = { name, status: 'NX', atTick: currentTick };
      return { status: 'NX' };
    }
    cache.set(name, { name, target, expiresAtTick: currentTick + ttlTicks });
    lastLookup = { name, status: 'AUTH', atTick: currentTick };
    return { status: 'AUTH', target };
  }
  function snapshot(currentTick = 0) {
    evictExpired(currentTick);
    return { address, ttlTicks, lookups, cachedHits, authoritative, lastLookup,
      cache: [...cache.values()].map((e) => ({ ...e,
        ttlRemaining: e.expiresAtTick - currentTick })) };
  }
  return { address, lookup, evictExpired, snapshot };
}`,
  },
  router: {
    file: 'js/sim/router.js',
    code: `createRouter({ leftAddress = '10.65', rightAddress = '20.1' } = {}) {
  let left = null, right = null, routed = 0, lastFrame = null;
  function join(leftNetwork, rightNetwork) {
    leftNetwork.registerServer(leftAddress, self);
    rightNetwork.registerServer(rightAddress, self);
    left = leftNetwork; right = rightNetwork;
  }
  function handleRequest(request = 'GET /') { return '200 Router 20.1'; }
  function route({ from, to, request }) {  // one router hop, then the far
    const net = Number(String(to).split('.')[0]);  // network resolves it
    const peer = ...;  // the joined network owning that subnet
    routed += 1;
    lastFrame = \`\${from} -> \${to} | routed cross-subnet (\${request})\`;
    return peer.send({ from, to, request });  // 20.9 throws (fail loud)
  }
  function snapshot() { return { leftAddress, rightAddress, routed, lastFrame }; }
  return { leftAddress, rightAddress, join, handleRequest, route, snapshot };
}`,
  },
};
