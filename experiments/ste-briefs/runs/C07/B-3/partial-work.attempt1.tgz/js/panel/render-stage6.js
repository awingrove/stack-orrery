// DOCUMENTS: Stage 6 hop-highlight maps, split from render-stage.js by
// responsibility (guard-file-size). Host-less traces reuse the Stage 5
// owner/lane maps verbatim; hosted resolved runs shift them +2 behind the
// two DNS hops; the NX run lights only the ask and the answer — no card
// past the DNS ever carries an active hop on the NX path.
export function stage5Parts(t = {}) {
  const backendCard = t.targetServer === '10.12' ? 'node-webserver-2' : 'node-webserver';
  const dbLane = t.dbOp === 'WRITE' ? 'packet-req-db' : 'packet-res-db';
  const owners = t.asyncJob
    ? {
        1: 'node-browser',
        2: 'node-network',
        3: 'node-lb',
        4: 'node-queue',
        5: 'node-webserver',
        6: 'node-network',
        7: 'node-browser',
        8: 'node-worker',
      }
    : {
        1: 'node-browser',
        2: 'node-network',
        3: 'node-lb',
        4: 'node-db',
        5: backendCard,
        6: 'node-network',
        7: 'node-browser',
        8: 'node-worker',
      };
  const lanes = t.asyncJob
    ? {
        1: 'packet-req-left',
        2: 'packet-req-right',
        3: 'packet-req-lb',
        4: 'packet-req-queue',
        5: 'packet-res-cache',
        6: 'packet-res-right',
        7: 'packet-res-left',
        8: 'packet-res-db',
      }
    : {
        1: 'packet-req-left',
        2: 'packet-req-right',
        3: 'packet-req-lb',
        4: dbLane,
        5: 'packet-res-cache',
        6: 'packet-res-right',
        7: 'packet-res-left',
        8: 'packet-res-worker',
      };
  return { owners, lanes };
}

export function stage6HopTarget(snapshot) {
  const t = snapshot.trace ?? {};
  const { owners, lanes } = stage5Parts(t);
  // Host-less run: the Stage 5 story, unchanged.
  if (!t.host) {
    return {
      cardId: owners[t.hop] ?? 'node-browser',
      laneId: lanes[t.hop] ?? 'packet-req-left',
    };
  }
  // NX run: ask + answer only.
  if (t.dnsStatus === 'NX') {
    const nxOwners = { 1: 'node-browser', 2: 'node-dns' };
    const nxLanes = { 1: 'packet-req-dns', 2: 'packet-res-dns' };
    return {
      cardId: nxOwners[t.hop] ?? 'node-browser',
      laneId: nxLanes[t.hop] ?? 'packet-req-dns',
    };
  }
  // Hosted resolved run: hops 1-2 are the DNS ask/answer; hops 3-10 map the
  // Stage 5 chain (inner hop = outer hop - 2).
  if (t.hop <= 2) {
    const dnsOwners = { 1: 'node-browser', 2: 'node-dns' };
    const dnsLanes = { 1: 'packet-req-dns', 2: 'packet-res-dns' };
    return {
      cardId: dnsOwners[t.hop] ?? 'node-browser',
      laneId: dnsLanes[t.hop] ?? 'packet-req-dns',
    };
  }
  const innerHop = t.hop - 2;
  return {
    cardId: owners[innerHop] ?? 'node-browser',
    laneId: lanes[innerHop] ?? 'packet-req-left',
  };
}
