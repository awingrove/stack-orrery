// DOCUMENTS: Stage 6 DOM — the pieces the static page cannot carry without
// breaching the 550-line HTML cap (guard-file-size): the DNS resolver card,
// the Router side-card, their inspector tabs, the DNS ask/answer wire lane,
// and the now-live stage-pill-6. Injected once at panel boot, before the
// first render, with createElement/append only (no inline handlers, no
// inline styles — AGENTS.md CSP rule).
const $ = (id) => document.getElementById(id);

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function nodeCard({ id, component, role, subtitle, chip, statsId, statsTestId, statsText }) {
  const card = el('article', 'node-card');
  card.id = id;
  card.dataset.testid = component === 'dns' ? 'node-dns' : 'node-router';
  card.dataset.component = component;
  card.hidden = true;
  const head = el('header', 'node-head');
  const name = el('div', 'node-name');
  name.append(el('span', 'role-name', role), el('span', 'node-subtitle', subtitle));
  head.append(name, el('span', 'ip-chip', chip), el('span', 'code-chip', '</> Code'));
  card.append(head);
  if (statsId) {
    const stats = el('p', 'mono last-frame', statsText);
    stats.id = statsId;
    stats.dataset.testid = statsTestId;
    card.append(stats);
  }
  return card;
}

function dnsCard() {
  const card = nodeCard({
    id: 'node-dns',
    component: 'dns',
    role: 'DNS',
    subtitle: 'resolver ledger',
    chip: '10.60',
    statsId: 'dns-stats',
    statsTestId: 'dns-stats',
    statsText: 'Lookups: 0 · Hits: 0 · Auth: 0',
  });
  const list = el('ul', 'route-list');
  list.id = 'dns-entries-list';
  list.dataset.testid = 'dns-entries-list';
  list.setAttribute('aria-label', 'Resolver cache');
  card.append(list);
  return card;
}

function routerCard() {
  return nodeCard({
    id: 'node-router',
    component: 'router',
    role: 'Router',
    subtitle: 'cross-subnet edge',
    chip: '10.65 ⇄ 20.1',
    statsId: 'router-stats',
    statsTestId: 'router-stats',
    statsText: 'Routed: 0',
  });
}

function dnsWireColumn() {
  const col = el('div', 'wire-column');
  col.id = 'wire-col-dns';
  col.setAttribute('aria-hidden', 'true');
  col.hidden = true;
  const ask = el('div', 'wire-lane', 'dns ask =>');
  ask.id = 'packet-req-dns';
  const answer = el('div', 'wire-lane reverse', '<- answer');
  answer.id = 'packet-res-dns';
  col.append(ask, answer);
  return col;
}

// CHECKS: injection is idempotent and lands before the first render — a
// boot that runs twice (or a page without the placeholder span) must not
// duplicate cards or throw.
export function ensureStage6Nodes() {
  if ($('node-dns') && $('node-router') && $('wire-col-dns')) return;
  const world = $('orrery-world');
  world.append(dnsWireColumn(), dnsCard(), routerCard());
  const tabs = document.querySelector('.comp-tabs');
  for (const name of ['dns', 'router']) {
    if (!tabs.querySelector(`[data-select="${name}"]`)) {
      const tab = el('button', 'comp-tab', name);
      tab.type = 'button';
      tab.dataset.select = name;
      tabs.append(tab);
    }
  }
  // The planned stage-6 ladder pill becomes a live button (the placeholder
  // span it replaces is removed so the ladder keeps exactly six pills).
  const placeholder = document.querySelector('.stage-ladder .stage-pill:last-child');
  if (placeholder && placeholder.tagName === 'SPAN') {
    const pill = el('button', 'stage-pill', '6 · Multi-Net / CDN');
    pill.type = 'button';
    pill.dataset.testid = 'stage-pill-6';
    pill.dataset.stage = '6';
    placeholder.replaceWith(pill);
  }
}
