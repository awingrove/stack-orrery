import { describe, it, expect } from 'vitest';
import { describeSnapshot, totalHopsForTrace, totalHopsUpperBound } from '../../js/panel/model.js';
import { createEngine } from '../../js/sim/engine.js';

// Stage-boundary extraction (guard-file-size): the Stage 6 narrative-branch
// pins live here so model.test.js stays inside the 450-line test cap.
// All three brief negative-case contracts are pinned against the REAL
// engine: host-less keeps the Stage 5 story, hosted adds exactly two DNS
// hops, and the NX run ends at the answer and emits no GET.
describe('Stage 6 trace narrative branches', () => {
  // PINS: (brief negative case) "GET /about" on Stage 6 keeps the Stage 5
  // hop story byte-identical — same hop count, same sentences, and the trace
  // carries no DNS hop (the resolver is not consulted).
  it('keeps the Stage 5 hop story byte-identical on the host-less path', () => {
    const s5 = createEngine({ stage: 5 });
    const s6 = createEngine({ stage: 6 });
    for (let hop = 0; hop < 8; hop++) {
      s5.traceHop({ method: 'GET', path: '/about' });
      s6.traceHop({ method: 'GET', path: '/about' });
      const a = describeSnapshot(s5.snapshot());
      const b = describeSnapshot(s6.snapshot());
      expect(a.hopStatus).toBe(b.hopStatus);
      expect(a.totalHops).toBe(8);
      expect(b.totalHops).toBe(8);
      expect(b.hopStatus).toMatch(new RegExp(`Hop ${hop + 1}/8: `));
    }
    const trace = s6.snapshot().trace;
    expect(trace.host).toBe(null);
    expect(trace.dnsStatus).toBe(null);
    expect(s6.snapshot().dns.lookups).toBe(0);
    expect(s6.snapshot().browserDisplay.body).toBe('This is the about page');
    // The upper bound agrees: a host-less Stage 6 path stays 8.
    expect(totalHopsUpperBound(6, '/about')).toBe(8);
    expect(totalHopsForTrace(6, { host: null })).toBe(8);
  });

  // PINS (brief §3): a hosted run spends exactly two DNS hops ahead of the
  // Stage 5 chain, the resolved mini-IP rides the GET, and a second run of
  // the same host is a cached ledger hit.
  it('adds exactly two DNS hops on the hosted path and resolves example.com through the ledger', () => {
    const engine = createEngine({ stage: 6 });
    for (let hop = 0; hop < 10; hop++)
      engine.traceHop({ method: 'GET', path: 'example.com/about' });
    let labels = describeSnapshot(engine.snapshot());
    expect(labels.totalHops).toBe(10);
    expect(engine.snapshot().dns).toMatchObject({ lookups: 1, authoritative: 1, cachedHits: 0 });
    const hopLabel = (n) =>
      describeSnapshot({ ...engine.snapshot(), trace: { ...engine.snapshot().trace, hop: n } })
        .hopStatus;
    // The run ended at hop 10; the DNS answer sentence reads at hop 2.
    expect(hopLabel(2)).toBe('Hop 2/10: DNS (10.60) -> Browser (10.2) | 10.1 (authoritative)');
    expect(hopLabel(1)).toBe('Hop 1/10: Browser (10.2) asks DNS (10.60) for "example.com"');
    // Hops 3-10 read the Stage 5 chain renumbered: hop 3 is the GET emit.
    expect(hopLabel(3)).toBe('Hop 3/10: Browser (10.2) emits "GET /about"');
    expect(labels.hopStatus).toBe('Hop 10/10: Worker (10.41) idle — no async jobs in this trace');
    expect(engine.snapshot().browserDisplay.body).toBe('This is the about page');
    expect(engine.snapshot().trace.request).toBe('GET /about');

    // Second hosted run: the ledger answers inside ttlTicks (no table read).
    for (let hop = 0; hop < 10; hop++)
      engine.traceHop({ method: 'GET', path: 'example.com/about' });
    expect(engine.snapshot().dns).toMatchObject({ lookups: 2, cachedHits: 1, authoritative: 1 });
    expect(hopLabel(2)).toBe('Hop 2/10: DNS (10.60) -> Browser (10.2) | 10.1 (cache HIT)');
    // The upper bound for a hosted path is the full 10.
    expect(totalHopsUpperBound(6, 'example.com/about')).toBe(10);
    expect(totalHopsForTrace(6, { host: 'example.com', dnsStatus: 'HIT' })).toBe(10);
  });

  // PINS: (brief negative case) "nope.example/about" emits no GET — the run
  // is the DNS ask plus the "NX no record" answer only; the browser
  // renders the NX card and every server stays at zero served requests.
  it('ends the unknown-name run at the NX answer without emitting a GET', () => {
    const engine = createEngine({ stage: 6 });
    engine.traceHop({ method: 'GET', path: 'nope.example/about' });
    engine.traceHop({ method: 'GET', path: 'nope.example/about' });
    const snap = engine.snapshot();
    expect(snap.trace.hop).toBe(2);
    expect(snap.trace).toMatchObject({
      host: 'nope.example',
      dnsStatus: 'NX',
      dnsTarget: null,
      response: 'NX no record',
      status: 'NX',
      body: 'no record',
    });
    // A third call starts a fresh run (the NX run is over at hop 2) — the
    // ask hop of a new run, not a third hop of the dead one; the resolver
    // consults its table right at the ask, so lookups is already 2.
    engine.traceHop({ method: 'GET', path: 'nope.example/about' });
    expect(engine.snapshot().trace.hop).toBe(1);
    expect(engine.snapshot().dns.lookups).toBe(2);

    // Nothing downstream ever saw an HTTP request: no served requests, no
    // LB forwarding, no cache lookups — and the browser renders the NX card.
    const after = engine.snapshot();
    expect(after.served).toBe(0);
    expect(after.servers.every((s) => s.served === 0)).toBe(true);
    expect(after.loadBalancer.forwarded).toBe(0);
    expect(after.cache.misses).toBe(0);
    const labels = describeSnapshot({
      ...after,
      trace: { ...after.trace, hop: 2, dnsStatus: 'NX' },
    });
    expect(labels.totalHops).toBe(2);
    expect(labels.hopStatus).toBe('Hop 2/2: DNS (10.60) -> Browser (10.2) | NX no record');
    expect(labels.browserStatus).toBe('NX (DNS nope.example)');
    expect(labels.browserBody).toBe('no record');
    expect(totalHopsForTrace(6, { host: 'nope.example', dnsStatus: 'NX' })).toBe(2);
  });
});
