import { describe, it, expect } from 'vitest';
import { createDns } from '../../js/sim/dns.js';
import { createEngine } from '../../js/sim/engine.js';

describe('createDns', () => {
  // PINS: (brief §1) lookup(name, currentTick) consults the authoritative
  // table only on a cache miss or an expired entry; a hit inside ttlTicks
  // is an incrementing cachedHits with NO authoritative consult — the named
  // counter-example: an expired entry must NOT be answered from the ledger.
  it('answers a hit inside ttlTicks from the ledger and re-reads the table once the entry expires', () => {
    const dns = createDns({ address: '10.60', ttlTicks: 300 });

    // Cold lookup: the authoritative table answers and the ledger refills.
    expect(dns.lookup('example.com', 5)).toEqual({ status: 'AUTH', target: '10.1' });
    let snap = dns.snapshot(5);
    expect(snap).toMatchObject({
      address: '10.60',
      ttlTicks: 300,
      lookups: 1,
      cachedHits: 0,
      authoritative: 1,
    });
    expect(snap.cache).toEqual([
      { name: 'example.com', target: '10.1', expiresAtTick: 305, ttlRemaining: 300 },
    ]);

    // A hit inside ttlTicks: cachedHits +1 and the authoritative counter
    // stays at 1 — the table goes unread a second time.
    expect(dns.lookup('example.com', 304)).toEqual({ status: 'HIT', target: '10.1' });
    snap = dns.snapshot(304);
    expect(snap).toMatchObject({ lookups: 2, cachedHits: 1, authoritative: 1 });
    expect(snap.cache[0].ttlRemaining).toBe(1);

    // The tick the TTL names is the first tick the entry is gone: tick 305
    // expires the entry, the ledger must NOT answer, and the table is read
    // again (authoritative +1) before a fresh entry lands.
    expect(dns.lookup('example.com', 305)).toEqual({ status: 'AUTH', target: '10.1' });
    snap = dns.snapshot(305);
    expect(snap).toMatchObject({ lookups: 3, cachedHits: 1, authoritative: 2 });
    expect(snap.cache[0]).toEqual({
      name: 'example.com',
      target: '10.1',
      expiresAtTick: 605,
      ttlRemaining: 300,
    });
  });

  // PINS: (brief §1) an unknown name answers { status: 'NX' } without
  // throwing at the DNS layer, and fills nothing into the ledger.
  it('answers NX for unknown names without throwing, and validates its config', () => {
    const dns = createDns();
    expect(dns.lookup('nope.example', 0)).toEqual({ status: 'NX' });
    const snap = dns.snapshot(0);
    expect(snap).toMatchObject({ lookups: 1, cachedHits: 0, authoritative: 1 });
    expect(snap.cache).toEqual([]);

    // CHECKS: fail-loud over silent mis-configuration (mini-IP address,
    // positive integer ttlTicks, mini-IP record targets, non-empty names).
    expect(() => createDns({ address: '1060' })).toThrow(/invalid mini-IP/);
    expect(() => createDns({ ttlTicks: 0 })).toThrow(/ttlTicks/);
    expect(() => createDns({ ttlTicks: 1.5 })).toThrow(/ttlTicks/);
    expect(() => createDns({ records: { 'example.com': '101' } })).toThrow(/invalid mini-IP/);
    expect(() => dns.lookup('')).toThrow(/non-empty string/);
  });

  it('stage 6 engine instantiates DNS 10.60 and exposes its snapshot', () => {
    const snap = createEngine({ stage: 6 }).snapshot();
    expect(snap.dns).not.toBe(null);
    expect(snap.dns.address).toBe('10.60');
    expect(snap.dns.ttlTicks).toBe(300);
    // The first hosted trace resolves authoritatively and fills the ledger.
    const engine = createEngine({ stage: 6 });
    engine.traceHop({ method: 'GET', path: 'example.com/about' });
    engine.traceHop({ method: 'GET', path: 'example.com/about' });
    const afterAskAnswer = engine.snapshot();
    expect(afterAskAnswer.dns.lookups).toBe(1);
    expect(afterAskAnswer.dns.authoritative).toBe(1);
    expect(afterAskAnswer.dns.cache.map((e) => `${e.name} -> ${e.target}`)).toEqual([
      'example.com -> 10.1',
    ]);
    // Stages 1-5 expose no resolver at all.
    for (const stage of [1, 2, 3, 4, 5]) {
      expect(createEngine({ stage }).snapshot().dns).toBe(null);
    }
  });
});
