import { describe, it, expect } from 'vitest';
import { createNetwork } from '../../js/sim/network.js';
import { createRouter } from '../../js/sim/router.js';
import { createWebServer } from '../../js/sim/webserver.js';
import { createEngine } from '../../js/sim/engine.js';

describe('createRouter + cross-subnet networks', () => {
  // PINS: (brief §2) same-subnet sends are unchanged from today's
  // send/deliverToQueue contract; any cross-subnet frame takes exactly one
  // router hop, incrementing routed.
  it('routes cross-subnet sends through exactly one router hop and keeps same-subnet sends unchanged', () => {
    const net10 = createNetwork({ subnet: 10 });
    const net20 = createNetwork({ subnet: 20 });
    net10.registerServer('10.1', createWebServer({ address: '10.1' }));
    const router = createRouter({ leftAddress: '10.65', rightAddress: '20.1' });
    router.join(net10, net20);
    net10.attachRouter(router);
    net20.attachRouter(router);

    // Same subnet: the wire record is byte-identical to the Stage 1 contract
    // and the router is untouched.
    expect(net10.send({ from: '10.2', to: '10.1', request: 'GET /about' })).toEqual({
      from: '10.2',
      to: '10.1',
      request: 'GET /about',
      response: '200 This is the about page',
    });
    expect(router.snapshot().routed).toBe(0);

    // Cross-subnet: exactly one router hop; 20.1 (the router's 20-side) is
    // the only reachable 20.x target in Stage 6a.
    const frame = net10.send({ from: '10.2', to: '20.1', request: 'GET /' });
    expect(frame).toEqual({
      from: '10.2',
      to: '20.1',
      request: 'GET /',
      response: '200 Router 20.1',
    });
    expect(router.snapshot().routed).toBe(1);
    expect(router.snapshot().lastFrame).toBe('10.2 -> 20.1 | routed cross-subnet (GET /)');
  });

  // PINS: (brief §2 negative case) a send into subnet 20 to an unregistered
  // host (20.9) throws — the failure is loud, mirroring network.js today.
  it('fails loud for unregistered 20.x hosts, unattached routers, and bad config', () => {
    const net10 = createNetwork({ subnet: 10 });
    const net20 = createNetwork({ subnet: 20 });
    const router = createRouter();
    router.join(net10, net20);
    net10.attachRouter(router);
    net20.attachRouter(router);
    expect(() => net10.send({ from: '10.2', to: '20.9', request: 'GET /' })).toThrow(
      /no server at 20\.9/,
    );
    // The frame still took the router hop before the far subnet rejected it.
    expect(router.snapshot().routed).toBe(1);

    // A declared subnet without an attached router fails at the gateway.
    const lone = createNetwork({ subnet: 10 });
    expect(() => lone.send({ from: '10.2', to: '20.1', request: 'GET /' })).toThrow(
      /no route to subnet 20/,
    );

    // CHECKS: constructor validation — mini-IP interfaces on two subnets.
    expect(() => createRouter({ leftAddress: '1065' })).toThrow(/invalid mini-IP/);
    expect(() => createRouter({ rightAddress: '20.1.1' })).toThrow(/invalid mini-IP/);
    expect(() => createRouter({ leftAddress: '10.65', rightAddress: '10.1' })).toThrow(
      /both interfaces sit on subnet 10/,
    );
  });

  it('stage 6 engine exposes the Router snapshot while stages 1-5 stay free of it', () => {
    const snap = createEngine({ stage: 6 }).snapshot();
    expect(snap.router).not.toBe(null);
    expect(snap.router).toMatchObject({
      leftAddress: '10.65',
      rightAddress: '20.1',
      routed: 0,
      lastFrame: null,
    });
    for (const stage of [1, 2, 3, 4, 5]) {
      const quiet = createEngine({ stage }).snapshot();
      expect(quiet.router).toBe(null);
      expect(quiet.dns).toBe(null);
    }
  });
});
