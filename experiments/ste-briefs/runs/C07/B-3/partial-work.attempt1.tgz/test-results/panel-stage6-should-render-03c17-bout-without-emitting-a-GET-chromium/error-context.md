# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: panel-stage6.spec.js >> should render NX no record for nope.example/about without emitting a GET
- Location: e2e/panel-stage6.spec.js:120:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByTestId('hop-status')
Expected substring: "Hop 1/2: Browser (10.2) asks DNS (10.60) for \"nope.example\""
Received string:    "Hop 1/10: Browser (10.2) asks DNS (10.60) for \"nope.example\""
Timeout: 5000ms

Call log:
  - Expect "toContainText" getByTestId('hop-status') with timeout 5000ms
  - waiting for getByTestId('hop-status')
    14 × locator resolved to <span id="hop-status" class="hop-status" data-testid="hop-status">Hop 1/10: Browser (10.2) asks DNS (10.60) for "no…</span>
       - unexpected value "Hop 1/10: Browser (10.2) asks DNS (10.60) for "nope.example""

```

```yaml
- text: "Hop 1/10: Browser (10.2) asks DNS (10.60) for \"nope.example\""
```

# Test source

```ts
  28  |   // tick-TTL ledger; the second run is a cached hit inside ttlTicks.
  29  |   await page.getByTestId('url-input').fill('example.com/about');
  30  |   await page.getByTestId('btn-url-go').click();
  31  |   await expect(page.getByTestId('dns-stats')).toHaveText('Lookups: 1 · Hits: 0 · Auth: 1');
  32  |   await expect(page.getByTestId('dns-entries-list')).toContainText('example.com -> 10.1');
  33  |   await expect(page.getByTestId('browser-rendered-body')).toHaveText('This is the about page');
  34  |   await page.getByTestId('btn-url-go').click();
  35  |   await expect(page.getByTestId('dns-stats')).toHaveText('Lookups: 2 · Hits: 1 · Auth: 1');
  36  | 
  37  |   // The DNS and Router cards open their real code + live state in the
  38  |   // inspector (registered node-cards, not static prose).
  39  |   await page.getByTestId('node-dns').click();
  40  |   await expect(page.getByTestId('inspector-code')).toContainText('createDns');
  41  |   await expect(page.getByTestId('inspector-state')).toContainText('"cachedHits": 1');
  42  |   await expect(page.getByTestId('inspector-state')).toContainText('"authoritative": 1');
  43  |   await page.getByTestId('node-router').click();
  44  |   await expect(page.getByTestId('inspector-code')).toContainText('createRouter');
  45  |   await expect(page.getByTestId('inspector-state')).toContainText('"routed": 0');
  46  | });
  47  | 
  48  | test('should trace example.com/about with DNS ask + answer hops', async ({ page }) => {
  49  |   await page.goto('/panel.html');
  50  | 
  51  |   await page.getByTestId('stage-pill-6').click();
  52  |   await page.getByTestId('url-input').fill('example.com/about');
  53  | 
  54  |   // Hops 1-2 are the DNS ask and the authoritative answer; the resolved
  55  |   // mini-IP then rides the GET from hop 3 onward (the Stage 5 chain).
  56  |   await page.getByTestId('btn-next-hop').click();
  57  |   await expect(page.getByTestId('hop-status')).toContainText(
  58  |     'Hop 1/10: Browser (10.2) asks DNS (10.60) for "example.com"',
  59  |   );
  60  |   await page.getByTestId('btn-next-hop').click();
  61  |   await expect(page.getByTestId('hop-status')).toContainText(
  62  |     'Hop 2/10: DNS (10.60) -> Browser (10.2) | 10.1 (authoritative)',
  63  |   );
  64  |   await page.getByTestId('btn-next-hop').click();
  65  |   await expect(page.getByTestId('hop-status')).toContainText('Hop 3/10: Browser (10.2) emits');
  66  |   for (let hop = 0; hop < 7; hop++) await page.getByTestId('btn-next-hop').click();
  67  |   await expect(page.getByTestId('hop-status')).toContainText('Hop 10/10');
  68  |   await expect(page.getByTestId('browser-status-badge')).toContainText('200');
  69  | 
  70  |   // The journey log keeps the run whole: hops 1/10 .. 10/10 ascending.
  71  |   const labels = await page.getByTestId('journey-log').locator('.journey-entry').allTextContents();
  72  |   const hopRows = labels.map((text) => text.match(/^(hop \d+\/10)/)?.[1]);
  73  |   expect(hopRows.slice(0, 10)).toEqual([
  74  |     'hop 1/10',
  75  |     'hop 2/10',
  76  |     'hop 3/10',
  77  |     'hop 4/10',
  78  |     'hop 5/10',
  79  |     'hop 6/10',
  80  |     'hop 7/10',
  81  |     'hop 8/10',
  82  |     'hop 9/10',
  83  |     'hop 10/10',
  84  |   ]);
  85  | });
  86  | 
  87  | test('should keep GET /about on Stage 6 at the Stage 5 hop story', async ({ page }) => {
  88  |   await page.goto('/panel.html');
  89  | 
  90  |   await page.getByTestId('stage-pill-6').click();
  91  |   await page.getByTestId('url-input').fill('/about');
  92  |   for (let hop = 0; hop < 8; hop++) await page.getByTestId('btn-next-hop').click();
  93  | 
  94  |   // Byte-identical Stage 5 story: 8 hops, cache/database narrative, worker
  95  |   // idle tail — and no DNS hop anywhere in the run.
  96  |   await expect(page.getByTestId('hop-status')).toContainText('Hop 4/8: Database');
  97  |   await expect(page.getByTestId('hop-status')).toContainText(
  98  |     'Hop 8/8: Worker (10.41) idle — no async jobs in this trace',
  99  |   );
  100 |   await expect(page.getByTestId('hop-status')).toContainText('Hop 8/8');
  101 |   await expect(page.getByTestId('dns-stats')).toHaveText('Lookups: 0 · Hits: 0 · Auth: 0');
  102 |   await expect(page.getByTestId('dns-entries-list')).toHaveText('');
  103 |   await expect(page.getByTestId('browser-rendered-body')).toHaveText('This is the about page');
  104 | 
  105 |   // The journey log labels read hop 1/8 .. 8/8 — the Stage 5 denominators.
  106 |   const labels = await page.getByTestId('journey-log').locator('.journey-entry').allTextContents();
  107 |   const hopRows = labels.map((text) => text.match(/^(hop \d\/8)/)?.[1]);
  108 |   expect(hopRows.slice(0, 8)).toEqual([
  109 |     'hop 1/8',
  110 |     'hop 2/8',
  111 |     'hop 3/8',
  112 |     'hop 4/8',
  113 |     'hop 5/8',
  114 |     'hop 6/8',
  115 |     'hop 7/8',
  116 |     'hop 8/8',
  117 |   ]);
  118 | });
  119 | 
  120 | test('should render NX no record for nope.example/about without emitting a GET', async ({
  121 |   page,
  122 | }) => {
  123 |   await page.goto('/panel.html');
  124 | 
  125 |   await page.getByTestId('stage-pill-6').click();
  126 |   await page.getByTestId('url-input').fill('nope.example/about');
  127 |   await page.getByTestId('btn-next-hop').click();
> 128 |   await expect(page.getByTestId('hop-status')).toContainText(
      |                                                ^ Error: expect(locator).toContainText(expected) failed
  129 |     'Hop 1/2: Browser (10.2) asks DNS (10.60) for "nope.example"',
  130 |   );
  131 |   await page.getByTestId('btn-next-hop').click();
  132 |   await expect(page.getByTestId('hop-status')).toContainText(
  133 |     'Hop 2/2: DNS (10.60) -> Browser (10.2) | NX no record',
  134 |   );
  135 | 
  136 |   // The NX card renders in the browser viewport — no numeric status, no GET
  137 |   // downstream: the servers serve nothing and the LB forwards nothing.
  138 |   await expect(page.getByTestId('browser-status-badge')).toContainText('NX');
  139 |   await expect(page.getByTestId('browser-rendered-body')).toHaveText('no record');
  140 |   await expect(page.getByTestId('exchange-inspector')).toHaveText('No requests served yet');
  141 |   await expect(page.getByTestId('dns-stats')).toHaveText('Lookups: 1 · Hits: 0 · Auth: 1');
  142 |   await expect(page.getByTestId('dns-entries-list')).toHaveText('');
  143 | 
  144 |   // One more step starts a fresh run (the NX run ended at hop 2), no
  145 |   // phantom hop 3 of the dead trace; the fresh ask has not consulted the
  146 |   // ledger yet — that is the answer hop's work.
  147 |   await page.getByTestId('btn-next-hop').click();
  148 |   await expect(page.getByTestId('hop-status')).toContainText(
  149 |     'Hop 1/2: Browser (10.2) asks DNS (10.60) for "nope.example"',
  150 |   );
  151 |   await expect(page.getByTestId('dns-stats')).toHaveText('Lookups: 1 · Hits: 0 · Auth: 1');
  152 | });
  153 | 
  154 | test('should deep-link ?stage=6 to the DNS stage and fall back from unknown values', async ({
  155 |   page,
  156 | }) => {
  157 |   await page.goto('/panel.html?stage=6&users=3');
  158 |   await expect(page.getByTestId('stage-pill-6')).toHaveAttribute('aria-current', 'true');
  159 |   await expect(page.getByTestId('node-dns')).toBeVisible();
  160 |   await expect(page.getByTestId('node-router')).toBeVisible();
  161 |   await expect(page.locator('.orrery-ring')).toHaveCount(8);
  162 | 
  163 |   // Negative-case pin: unknown values still fall back to Stage 1.
  164 |   await page.goto('/panel.html?stage=99');
  165 |   await expect(page.getByTestId('stage-pill-1')).toHaveAttribute('aria-current', 'true');
  166 |   await expect(page.getByTestId('server-address')).toHaveText('10.1');
  167 |   await expect(page.locator('.orrery-ring')).toHaveCount(3);
  168 | });
  169 | 
```