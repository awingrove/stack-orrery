import { test, expect } from '@playwright/test';

// Stage 6a — DNS with tick-TTL ledger + cross-subnet Router. Split from
// panel.spec.js by responsibility (that spec sits at its 450-line cap).
// Titles are manifest pins (PANEL-6): do not reword. The sim runs from a
// fixed seed, so hop texts and counters are identical on every run.

test('should switch to Stage 6, resolve example.com through DNS 10.60, and inspect DNS code + TTL ledger', async ({
  page,
}) => {
  await page.goto('/panel.html');

  await page.getByTestId('stage-pill-6').click();
  await expect(page.getByTestId('stage-pill-6')).toHaveAttribute('aria-current', 'true');
  await expect(page.getByTestId('node-dns')).toBeVisible();
  await expect(page.getByTestId('node-router')).toBeVisible();
  await expect(page.getByTestId('node-queue')).toBeVisible();
  await expect(page.getByTestId('node-db')).toBeVisible();
  // 8 rings, r_k = k * ringGap: DNS on Ring 7 (2800), browsers on Ring 8.
  await expect(page.locator('.orrery-ring')).toHaveCount(8);
  await expect(page.locator('.orrery-ring').first()).toHaveAttribute('r', '400');
  await expect(page.locator('.orrery-ring').last()).toHaveAttribute('r', '3200');
  await expect(page.getByTestId('dns-stats')).toHaveText('Lookups: 0 · Hits: 0 · Auth: 0');
  await expect(page.getByTestId('router-stats')).toHaveText('Routed: 0');
  await expect(page.getByTestId('node-router')).toContainText('10.65 ⇄ 20.1');

  // A hosted path resolves authoritatively on the first run and fills the
  // tick-TTL ledger; the second run is a cached hit inside ttlTicks.
  await page.getByTestId('url-input').fill('example.com/about');
  await page.getByTestId('btn-url-go').click();
  await expect(page.getByTestId('dns-stats')).toHaveText('Lookups: 1 · Hits: 0 · Auth: 1');
  await expect(page.getByTestId('dns-entries-list')).toContainText('example.com -> 10.1');
  await expect(page.getByTestId('browser-rendered-body')).toHaveText('This is the about page');
  await page.getByTestId('btn-url-go').click();
  await expect(page.getByTestId('dns-stats')).toHaveText('Lookups: 2 · Hits: 1 · Auth: 1');

  // The DNS and Router cards open their real code + live state in the
  // inspector (registered node-cards, not static prose).
  await page.getByTestId('node-dns').click();
  await expect(page.getByTestId('inspector-code')).toContainText('createDns');
  await expect(page.getByTestId('inspector-state')).toContainText('"cachedHits": 1');
  await expect(page.getByTestId('inspector-state')).toContainText('"authoritative": 1');
  await page.getByTestId('node-router').click();
  await expect(page.getByTestId('inspector-code')).toContainText('createRouter');
  await expect(page.getByTestId('inspector-state')).toContainText('"routed": 0');
});

test('should trace example.com/about with DNS ask + answer hops', async ({ page }) => {
  await page.goto('/panel.html');

  await page.getByTestId('stage-pill-6').click();
  await page.getByTestId('url-input').fill('example.com/about');

  // Hops 1-2 are the DNS ask and the authoritative answer; the resolved
  // mini-IP then rides the GET from hop 3 onward (the Stage 5 chain).
  await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toContainText(
    'Hop 1/10: Browser (10.2) asks DNS (10.60) for "example.com"',
  );
  await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toContainText(
    'Hop 2/10: DNS (10.60) -> Browser (10.2) | 10.1 (authoritative)',
  );
  await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toContainText('Hop 3/10: Browser (10.2) emits');
  for (let hop = 0; hop < 7; hop++) await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toContainText('Hop 10/10');
  await expect(page.getByTestId('browser-status-badge')).toContainText('200');

  // The journey log keeps the run whole: hops 1/10 .. 10/10 ascending.
  const labels = await page.getByTestId('journey-log').locator('.journey-entry').allTextContents();
  const hopRows = labels.map((text) => text.match(/^(hop \d+\/10)/)?.[1]);
  expect(hopRows.slice(0, 10)).toEqual([
    'hop 1/10',
    'hop 2/10',
    'hop 3/10',
    'hop 4/10',
    'hop 5/10',
    'hop 6/10',
    'hop 7/10',
    'hop 8/10',
    'hop 9/10',
    'hop 10/10',
  ]);
});

test('should keep GET /about on Stage 6 at the Stage 5 hop story', async ({ page }) => {
  await page.goto('/panel.html');

  await page.getByTestId('stage-pill-6').click();
  await page.getByTestId('url-input').fill('/about');
  // Mid-trace: hop 4/8 reads the cache/database narrative the Stage 5 story
  // carries, with no DNS hop anywhere in the run.
  for (let hop = 0; hop < 4; hop++) await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toContainText('Hop 4/8: Database');
  for (let hop = 0; hop < 4; hop++) await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toContainText(
    'Hop 8/8: Worker (10.41) idle — no async jobs in this trace',
  );
  await expect(page.getByTestId('hop-status')).toContainText('Hop 8/8');
  await expect(page.getByTestId('dns-stats')).toHaveText('Lookups: 0 · Hits: 0 · Auth: 0');
  await expect(page.getByTestId('dns-entries-list')).toHaveText('');
  await expect(page.getByTestId('browser-rendered-body')).toHaveText('This is the about page');

  // The journey log labels read hop 1/8 .. 8/8 — the Stage 5 denominators.
  const labels = await page.getByTestId('journey-log').locator('.journey-entry').allTextContents();
  const hopRows = labels.map((text) => text.match(/^(hop \d\/8)/)?.[1]);
  expect(hopRows.slice(0, 8)).toEqual([
    'hop 1/8',
    'hop 2/8',
    'hop 3/8',
    'hop 4/8',
    'hop 5/8',
    'hop 6/8',
    'hop 7/8',
    'hop 8/8',
  ]);
});

test('should render NX no record for nope.example/about without emitting a GET', async ({
  page,
}) => {
  await page.goto('/panel.html');

  await page.getByTestId('stage-pill-6').click();
  await page.getByTestId('url-input').fill('nope.example/about');
  await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toContainText(
    'Hop 1/2: Browser (10.2) asks DNS (10.60) for "nope.example"',
  );
  await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toContainText(
    'Hop 2/2: DNS (10.60) -> Browser (10.2) | NX no record',
  );

  // The NX card renders in the browser viewport — no numeric status, no GET
  // downstream: the servers serve nothing and the LB forwards nothing.
  await expect(page.getByTestId('browser-status-badge')).toContainText('NX');
  await expect(page.getByTestId('browser-rendered-body')).toHaveText('no record');
  await expect(page.getByTestId('exchange-inspector')).toHaveText('No requests served yet');
  await expect(page.getByTestId('dns-stats')).toHaveText('Lookups: 1 · Hits: 0 · Auth: 1');
  await expect(page.getByTestId('dns-entries-list')).toHaveText('');

  // One more step starts a fresh run (the NX run ended at hop 2), no
  // phantom hop 3 of the dead trace; the resolver consults its table right
  // at the ask, so the counters move again.
  await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toContainText(
    'Hop 1/2: Browser (10.2) asks DNS (10.60) for "nope.example"',
  );
  await expect(page.getByTestId('dns-stats')).toHaveText('Lookups: 2 · Hits: 0 · Auth: 2');
});

test('should deep-link ?stage=6 to the DNS stage and fall back from unknown values', async ({
  page,
}) => {
  await page.goto('/panel.html?stage=6&users=3');
  await expect(page.getByTestId('stage-pill-6')).toHaveAttribute('aria-current', 'true');
  await expect(page.getByTestId('node-dns')).toBeVisible();
  await expect(page.getByTestId('node-router')).toBeVisible();
  await expect(page.locator('.orrery-ring')).toHaveCount(8);

  // Negative-case pin: unknown values still fall back to Stage 1.
  await page.goto('/panel.html?stage=99');
  await expect(page.getByTestId('stage-pill-1')).toHaveAttribute('aria-current', 'true');
  await expect(page.getByTestId('server-address')).toHaveText('10.1');
  await expect(page.locator('.orrery-ring')).toHaveCount(3);
});
