// DOCUMENTS: lane-anchor tables — which wire lane sits on which wire in
// world coordinates, split from viewport.js by responsibility
// (guard-file-size): this module owns the per-stage anchor tables;
// viewport.js owns the camera and applies them.
//
// PINS: each wire lane sits on its wire in world coordinates (col-left on
// browser↔network, col-right on network↔webserver/lb, lb-backends centered
// between the two backend wires, servers-cache centered between the two
// cache wires). A value may pin a lane at a fraction t down its wire:
// Stage 5 anchors the cache→db lane at t=0.3 so it clears the queue→worker
// crossing. Stage 6 adds the DNS ask/answer wire and the router forward
// wire on top of Stage 5's anchors.
const LANE_WIRES = {
  1: { 'wire-col-left': 'wire-browser-network', 'wire-col-right': 'wire-network-webserver' },
  2: { 'wire-col-left': 'wire-browser-network', 'wire-col-right': 'wire-network-lb' },
  3: { 'wire-col-left': 'wire-browser-network', 'wire-col-right': 'wire-network-lb' },
  4: {
    'wire-col-left': 'wire-browser-network',
    'wire-col-right': 'wire-network-lb',
    'wire-cache-db': 'wire-cache-db',
  },
  5: {
    'wire-col-left': 'wire-browser-network',
    'wire-col-right': 'wire-network-lb',
    'wire-cache-db': ['wire-cache-db', 0.3],
    'wire-cache-queue': 'wire-cache-queue',
    'wire-queue-worker': 'wire-queue-worker',
  },
};
LANE_WIRES[6] = {
  ...LANE_WIRES[5],
  'wire-browser-dns': 'wire-browser-dns',
  'wire-network-router': 'wire-network-router',
};

// Lanes anchored between parallel wires — lb-backends shared across stages
// 2-6; servers-cache capped left of the Cache card it would otherwise clip.
const LANES_BETWEEN = [
  {
    laneId: 'wire-lb-backends',
    stages: [2, 3, 4, 5, 6],
    wireIds: ['wire-lb-webserver', 'wire-lb-webserver-2'],
  },
  {
    laneId: 'wire-servers-cache',
    stages: [3, 4, 5, 6],
    wireIds: ['wire-webserver-cache', 'wire-webserver-2-cache'],
    capTo: 'node-cache',
    capDx: -175, // 15.5rem card half + chip half + margin, in world px
  },
];

export { LANE_WIRES, LANES_BETWEEN };
