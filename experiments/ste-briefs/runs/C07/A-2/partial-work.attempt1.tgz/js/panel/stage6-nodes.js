// DOCUMENTS: Stage 6 edge nodes — the #node-dns and #node-router cards,
// their wire lanes, the live stage-pill-6, and the dns/router inspector
// tabs, built here because panel.html sits at its 550-line cap (the same
// pattern teaching-drawer.js uses for the teaching drawer). All nodes are
// created with createElement/textContent only — no inline handlers, no
// inline styles (AGENTS.md CSP rule) — and hidden by default; render-stage
// reveals them when stage >= 6 and layout.js positions them.
const $ = (id) => document.getElementById(id);

function el(tag, { id, testid, className, text, hidden = false, attrs = {} } = {}) {
  const node = document.createElement(tag);
  if (id) node.id = id;
  if (testid) node.dataset.testid = testid;
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  if (hidden) node.hidden = true;
  for (const [key, value] of Object.entries(attrs)) node.setAttribute(key, value);
  return node;
}

function nodeHead(roleName, subtitle, chipText) {
  const head = el('header', { className: 'node-head' });
  const name = el('div', { className: 'node-name' });
  name.append(
    el('span', { className: 'role-name', text: roleName }),
    el('span', { className: 'node-subtitle', text: subtitle }),
  );
  head.append(name, el('span', { className: 'ip-chip', text: chipText }));
  head.append(el('span', { className: 'code-chip', text: '</> Code' }));
  return head;
}

function wireColumn(id, lanes) {
  const column = el('div', {
    id,
    className: 'wire-column',
    hidden: true,
    attrs: { 'aria-hidden': 'true' },
  });
  for (const [laneId, text, reverse] of lanes) {
    column.append(
      el('div', { id: laneId, className: `wire-lane${reverse ? ' reverse' : ''}`, text }),
    );
  }
  return column;
}

function edgeCard({ id, component, roleName, subtitle, chipText, body }) {
  const card = el('article', {
    id,
    testid: id,
    className: 'node-card',
    hidden: true,
    attrs: { 'data-component': component },
  });
  card.append(nodeHead(roleName, subtitle, chipText), ...body);
  return card;
}

export function buildStage6Nodes() {
  const ladder = document.querySelector('.stage-ladder');
  ladder.append(
    el('button', {
      id: 'stage-pill-6',
      testid: 'stage-pill-6',
      className: 'stage-pill',
      text: '6 · Multi-Net / CDN',
      attrs: { 'data-stage': '6', type: 'button' },
    }),
  );

  const dnsCard = edgeCard({
    id: 'node-dns',
    component: 'dns',
    roleName: 'DNS',
    subtitle: 'name resolver ledger',
    chipText: '10.60',
    body: [
      el('p', {
        id: 'dns-stats',
        testid: 'dns-stats',
        className: 'mono last-frame',
        text: 'Lookups: 0 · Cached hits: 0 · Authoritative: 0 · TTL: 300t',
      }),
      el('ul', {
        id: 'dns-entries-list',
        testid: 'dns-entries-list',
        className: 'route-list',
        attrs: { 'aria-label': 'DNS ledger entries' },
      }),
    ],
  });

  const routerCard = edgeCard({
    id: 'node-router',
    component: 'router',
    roleName: 'Router',
    subtitle: 'cross-subnet gateway',
    chipText: '10.65 ⇄ 20.1',
    body: [
      el('p', {
        id: 'router-stats',
        testid: 'router-stats',
        className: 'mono last-frame',
        text: 'Routed: 0 · 10.65 ⇄ 20.1',
      }),
    ],
  });

  const dnsLane = wireColumn('wire-browser-dns', [
    ['packet-req-dns', 'dns ask =>', false],
    ['packet-res-dns', '<- answer', true],
  ]);
  const routerLane = wireColumn('wire-network-router', [
    ['packet-req-router', 'forward =>', false],
    ['packet-res-router', '<- return', true],
  ]);

  const world = $('orrery-world');
  world.append(dnsCard, routerCard, dnsLane, routerLane);

  const tabs = document.querySelector('.comp-tabs');
  for (const name of ['dns', 'router']) {
    tabs.append(
      el('button', {
        className: 'comp-tab',
        text: name,
        attrs: { type: 'button', 'data-select': name },
      }),
    );
  }
}
