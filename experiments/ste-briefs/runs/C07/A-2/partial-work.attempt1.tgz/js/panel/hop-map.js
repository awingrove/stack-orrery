// DOCUMENTS: hop ownership map — which node card executes each trace hop
// and which wire lane carries it, per stage and trace shape. Pure mapping:
// snapshots in, { cardId, laneId } out (render-stage.js applies the DOM
// classes). Split from render-stage.js by responsibility
// (guard-file-size): this module owns the per-stage hop tables; that
// module owns the DOM writes.
//
// Stage 1 is emit / route / serve / render; Stage 2 inserts the LB's
// round-robin pick; Stage 3 splits the backend serve into the cache
// lookup (Cache 10.20 answers) and the response emission; Stage 4 adds
// the database hop; Stage 5 adds async worker queue processing. Stage 6
// branches on host syntax: a hosted path spends hops 2-3 on DNS 10.60
// (ask, then the answer naming the resolved target) before the stage-5
// chain, a host-less path reuses the stage-5 tables, and an NX answer
// keeps the whole trace on DNS.
export function hopTarget(snapshot) {
  const hop = snapshot.trace?.hop ?? 0;
  if (snapshot.stage === 6 && snapshot.trace?.hosted) {
    const t = snapshot.trace;
    const backendCard = t.targetServer === '10.12' ? 'node-webserver-2' : 'node-webserver';
    const dbLane = t.dbOp === 'WRITE' ? 'packet-req-db' : 'packet-res-db';
    if (t.dnsStatus === 'NX') {
      const owners = { 1: 'node-browser', 2: 'node-dns', 3: 'node-dns' };
      const lanes = {
        1: 'packet-req-left',
        2: 'packet-req-dns',
        3: 'packet-res-dns',
      };
      return { cardId: owners[hop] ?? 'node-dns', laneId: lanes[hop] ?? 'packet-req-dns' };
    }
    const owners = t.asyncJob
      ? {
          1: 'node-browser',
          2: 'node-dns',
          3: 'node-dns',
          4: 'node-network',
          5: 'node-lb',
          6: 'node-queue',
          7: backendCard,
          8: 'node-network',
          9: 'node-browser',
          10: 'node-worker',
        }
      : {
          1: 'node-browser',
          2: 'node-dns',
          3: 'node-dns',
          4: 'node-network',
          5: 'node-lb',
          6: 'node-db',
          7: backendCard,
          8: 'node-network',
          9: 'node-browser',
          10: 'node-worker',
        };
    const lanes = t.asyncJob
      ? {
          1: 'packet-req-left',
          2: 'packet-req-dns',
          3: 'packet-res-dns',
          4: 'packet-req-right',
          5: 'packet-req-lb',
          6: 'packet-req-queue',
          7: 'packet-res-cache',
          8: 'packet-res-right',
          9: 'packet-res-left',
          10: 'packet-res-db',
        }
      : {
          1: 'packet-req-left',
          2: 'packet-req-dns',
          3: 'packet-res-dns',
          4: 'packet-req-right',
          5: 'packet-req-lb',
          6: dbLane,
          7: 'packet-res-cache',
          8: 'packet-res-right',
          9: 'packet-res-left',
          10: 'packet-res-worker',
        };
    return { cardId: owners[hop] ?? 'node-browser', laneId: lanes[hop] ?? 'packet-req-left' };
  }
  if (snapshot.stage === 5 || (snapshot.stage === 6 && !snapshot.trace?.hosted)) {
    // Async POST /jobs walks browser -> lb -> enqueue -> 202 -> worker
    // commit; every other request keeps the Stage 4 cache/db story and the
    // worker reads idle on the tail hop.
    const backendCard =
      snapshot.trace?.targetServer === '10.12' ? 'node-webserver-2' : 'node-webserver';
    const dbLane = snapshot.trace?.dbOp === 'WRITE' ? 'packet-req-db' : 'packet-res-db';
    const owners = snapshot.trace?.asyncJob
      ? {
          1: 'node-browser',
          2: 'node-network',
          3: 'node-lb',
          4: 'node-queue',
          5: 'node-webserver',
          6: 'node-network',
          7: 'node-browser',
          8: 'node-worker',
        }
      : {
          1: 'node-browser',
          2: 'node-network',
          3: 'node-lb',
          4: 'node-db',
          5: backendCard,
          6: 'node-network',
          7: 'node-browser',
          8: 'node-worker',
        };
    const lanes = snapshot.trace?.asyncJob
      ? {
          1: 'packet-req-left',
          2: 'packet-req-right',
          3: 'packet-req-lb',
          4: 'packet-req-queue',
          5: 'packet-res-cache',
          6: 'packet-res-right',
          7: 'packet-res-left',
          8: 'packet-res-db',
        }
      : {
          1: 'packet-req-left',
          2: 'packet-req-right',
          3: 'packet-req-lb',
          4: dbLane,
          5: 'packet-res-cache',
          6: 'packet-res-right',
          7: 'packet-res-left',
          8: 'packet-res-worker',
        };
    return { cardId: owners[hop] ?? 'node-browser', laneId: lanes[hop] ?? 'packet-req-left' };
  }
  if (snapshot.stage === 4) {
    const backendCard =
      snapshot.trace?.targetServer === '10.12' ? 'node-webserver-2' : 'node-webserver';
    const dbLane = snapshot.trace?.dbOp === 'WRITE' ? 'packet-req-db' : 'packet-res-db';
    const owners = {
      1: 'node-browser',
      2: 'node-network',
      3: 'node-lb',
      4: 'node-cache',
      5: 'node-db',
      6: backendCard,
      7: 'node-browser',
    };
    const lanes = {
      1: 'packet-req-left',
      2: 'packet-req-right',
      3: 'packet-req-lb',
      4: 'packet-req-cache',
      5: dbLane,
      6: 'packet-res-cache',
      7: 'packet-res-left',
    };
    return { cardId: owners[hop], laneId: lanes[hop] };
  }
  if (snapshot.stage === 3) {
    const backendCard =
      snapshot.trace?.targetServer === '10.12' ? 'node-webserver-2' : 'node-webserver';
    const owners = {
      1: 'node-browser',
      2: 'node-network',
      3: 'node-lb',
      4: 'node-cache',
      5: backendCard,
      6: 'node-browser',
    };
    const lanes = {
      1: 'packet-req-left',
      2: 'packet-req-right',
      3: 'packet-req-lb',
      4: 'packet-req-cache',
      5: 'packet-res-cache',
      6: 'packet-res-left',
    };
    return { cardId: owners[hop], laneId: lanes[hop] };
  }
  if (snapshot.stage === 2) {
    const backendCard =
      snapshot.trace?.targetServer === '10.12' ? 'node-webserver-2' : 'node-webserver';
    const owners = {
      1: 'node-browser',
      2: 'node-network',
      3: 'node-lb',
      4: backendCard,
      5: 'node-browser',
    };
    const lanes = {
      1: 'packet-req-left',
      2: 'packet-req-right',
      3: 'packet-req-lb',
      4: 'packet-res-lb',
      5: 'packet-res-left',
    };
    return { cardId: owners[hop], laneId: lanes[hop] };
  }
  const owners = { 1: 'node-browser', 2: 'node-network', 3: 'node-webserver', 4: 'node-browser' };
  const lanes = {
    1: 'packet-req-left',
    2: 'packet-req-right',
    3: 'packet-res-right',
    4: 'packet-res-left',
  };
  return { cardId: owners[hop], laneId: lanes[hop] };
}
