// DOCUMENTS: stage-shape DOM writes, split from render.js by
// responsibility (guard-file-size): which cards and wire lanes are visible
// per stage, which card and wire lane carries the active hop, the crowd
// dots, and the compact browser nodes on the outer client ring. Zero
// engine knowledge: snapshots and layout geometry in, DOM writes out.
// The hop-ownership tables live in hop-map.js (pure mapping).
import { hopTarget } from './hop-map.js';

const $ = (id) => document.getElementById(id);

// Lane ids are looked up lazily: Stage 6's DNS/Router lanes are built by
// stage6-nodes.js at panel boot, after this module loads.
const LANE_IDS = [
  'packet-req-left',
  'packet-res-left',
  'packet-req-right',
  'packet-res-right',
  'packet-req-lb',
  'packet-res-lb',
  'packet-req-cache',
  'packet-res-cache',
  'packet-req-db',
  'packet-res-db',
  'packet-req-queue',
  'packet-res-queue',
  'packet-req-worker',
  'packet-res-worker',
  'packet-req-dns',
  'packet-res-dns',
  'packet-req-router',
  'packet-res-router',
];

// Stage-switch hook: viewport.js registers a callback so camera + world
// layout resync the moment the topology toggles.
let stageRenderedHook = null;

export function onStageRendered(fn) {
  stageRenderedHook = fn;
}

export function renderStageTopology(stage) {
  const hasLb = stage >= 2;
  const hasCache = stage >= 3;
  const hasDb = stage >= 4;
  const hasWorkers = stage >= 5;
  const hasEdge = stage >= 6;
  $('node-lb').hidden = !hasLb;
  $('wire-lb-backends').hidden = !hasLb;
  $('node-webserver-2').hidden = !hasLb;
  $('node-cache').hidden = !hasCache;
  $('wire-servers-cache').hidden = !hasCache;
  $('node-db').hidden = !hasDb;
  $('wire-cache-db').hidden = !hasDb;
  $('node-queue').hidden = !hasWorkers;
  $('wire-cache-queue').hidden = !hasWorkers;
  $('node-worker').hidden = !hasWorkers;
  $('wire-queue-worker').hidden = !hasWorkers;
  // Stage 6 edge nodes and their wire lanes (built in stage6-nodes.js —
  // the page sits at its 550-line cap).
  const dnsCard = $('node-dns');
  if (dnsCard) dnsCard.hidden = !hasEdge;
  const routerCard = $('node-router');
  if (routerCard) routerCard.hidden = !hasEdge;
  for (const laneId of ['wire-browser-dns', 'wire-network-router']) {
    const lane = $(laneId);
    if (lane) lane.hidden = !hasEdge;
  }
  $('network-role-10-1').textContent = hasLb ? 'LoadBalancer -> 10.11, 10.12' : 'WebServer';
  for (const pill of document.querySelectorAll('.stage-pill[data-stage]')) {
    const active = Number(pill.dataset.stage) === stage;
    pill.classList.toggle('active-stage', active);
    if (active) pill.setAttribute('aria-current', 'true');
    else pill.removeAttribute('aria-current');
  }
  if (stageRenderedHook) stageRenderedHook(stage);
}

export function renderHopHighlights(snapshot, selectedComponent) {
  const { cardId, laneId } = hopTarget(snapshot);
  for (const card of document.querySelectorAll('.node-card')) {
    card.classList.toggle('active-hop', card.id === cardId);
    card.classList.toggle('selected-node', card.dataset.component === selectedComponent);
  }
  for (const id of LANE_IDS) {
    const node = document.getElementById(id);
    if (node) node.classList.toggle('lane-active', id === laneId);
  }
}

export function renderDots(n) {
  $('user-dots').replaceChildren(
    ...Array.from({ length: n }, () => {
      const dot = document.createElement('span');
      dot.className = 'user-dot';
      return dot;
    }),
  );
}

// CHECKS: compact outer-ring browser nodes rebuild from the layout's
// browser slots so a re-spaced or re-populated ring leaves no stale or
// ghost buttons behind.
export function renderRingBrowsers(slots, activeAddress) {
  const ring = $('browser-ring-nodes');
  if (!ring) return;
  ring.replaceChildren(
    ...slots
      .filter((slot) => slot.address !== activeAddress)
      .map((slot) => {
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'browser-compact';
        button.dataset.testid = `browser-node-${slot.address}`;
        button.dataset.address = slot.address;
        button.style.left = `${slot.x}px`;
        button.style.top = `${slot.y}px`;
        const chip = document.createElement('span');
        chip.className = 'ip-chip';
        chip.textContent = slot.address;
        const status = document.createElement('span');
        status.className = 'browser-compact-status';
        status.textContent = slot.lastDisplay ? String(slot.lastDisplay.status) : 'idle';
        button.replaceChildren(chip, status);
        return button;
      }),
  );
}
