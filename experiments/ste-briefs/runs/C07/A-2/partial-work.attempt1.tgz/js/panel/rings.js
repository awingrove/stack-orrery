// DOCUMENTS: the ring registry — one concentric ring per architectural
// layer per stage (r_k = k * ringGap), split from layout.js by
// responsibility (guard-file-size): this module owns which layers a stage
// shows; layout.js owns where the components sit on them.
export const DEFAULT_RING_GAP = 400;

const STAGE_RINGS = {
  1: [
    ['ring-compute', 'RING 1 · WEBSERVER'],
    ['ring-network', 'RING 2 · NETWORK'],
    ['ring-clients', 'RING 3 · BROWSERS'],
  ],
  2: [
    ['ring-compute', 'RING 1 · WEBSERVERS'],
    ['ring-lb', 'RING 2 · LOADBALANCER'],
    ['ring-network', 'RING 3 · NETWORK'],
    ['ring-clients', 'RING 4 · BROWSERS'],
  ],
  3: [
    ['ring-cache', 'RING 1 · CACHE'],
    ['ring-compute', 'RING 2 · WEBSERVERS'],
    ['ring-lb', 'RING 3 · LOADBALANCER'],
    ['ring-network', 'RING 4 · NETWORK'],
    ['ring-clients', 'RING 5 · BROWSERS'],
  ],
  4: [
    ['ring-db', 'RING 1 · DATABASE'],
    ['ring-cache', 'RING 2 · CACHE'],
    ['ring-compute', 'RING 3 · WEBSERVERS'],
    ['ring-lb', 'RING 4 · LOADBALANCER'],
    ['ring-network', 'RING 5 · NETWORK'],
    ['ring-clients', 'RING 6 · BROWSERS'],
  ],
  5: [
    ['ring-db', 'RING 1 · DATABASE'],
    ['ring-workers', 'RING 2 · WORKERS'],
    ['ring-cache', 'RING 3 · CACHE'],
    ['ring-compute', 'RING 4 · WEBSERVERS'],
    ['ring-lb', 'RING 5 · LOADBALANCER'],
    ['ring-network', 'RING 6 · NETWORK'],
    ['ring-clients', 'RING 7 · BROWSERS'],
  ],
  6: [
    ['ring-db', 'RING 1 · DATABASE'],
    ['ring-workers', 'RING 2 · WORKERS'],
    ['ring-cache', 'RING 3 · CACHE'],
    ['ring-compute', 'RING 4 · WEBSERVERS'],
    ['ring-lb', 'RING 5 · LOADBALANCER'],
    ['ring-network', 'RING 6 · NETWORK'],
    ['ring-dns', 'RING 7 · DNS'],
    ['ring-clients', 'RING 8 · BROWSERS'],
  ],
};

export const ORRERY_RINGS = buildOrreryRings(DEFAULT_RING_GAP, 1);

// CHECKS: buildOrreryRings validates the ring gap and the stage range
// rather than silently rendering an unknown topology as empty space.
export function buildOrreryRings(ringGap = DEFAULT_RING_GAP, stage = 1) {
  if (!Number.isFinite(ringGap) || ringGap <= 0) {
    throw new Error('layout: ringGap must be a finite number > 0');
  }
  const ringSpecs = STAGE_RINGS[stage];
  if (!ringSpecs) {
    throw new Error(`layout: unknown stage ${stage} (expected 1-6)`);
  }
  const gap = Math.round(ringGap);
  return ringSpecs.map(([id, label], k) => ({ id, radius: (k + 1) * gap, label }));
}
