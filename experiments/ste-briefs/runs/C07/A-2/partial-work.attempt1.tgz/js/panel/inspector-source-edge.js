// DOCUMENTS: the Stage 6 edge services' inspector code — DNS 10.60 (the
// authoritative name table with its tick-TTL ledger) and the cross-subnet
// Router (10.65 ⇄ 20.1). Split from inspector-source.js by responsibility
// (guard-file-size): that file keeps the Stage 1-5 components; this one
// spreads into COMPONENT_SOURCE as the edge entries.
export const EDGE_SOURCE = {
  dns: {
    file: 'js/sim/dns.js',
    code: `createDns({ address = '10.60', ttlTicks = 300 } = {}) {
  // address must be "<net>.<host>" — a two-number mini-IP
  const records = new Map([['example.com', '10.1']]);  // Stage 6b adds a CDN name
  const cache = new Map();  // name -> { target, expiresAtTick }
  let lookups = 0, cachedHits = 0, authoritative = 0, lastLookup = null;
  function evictExpired(currentTick = 0) {
    for (const entry of cache.values()) {
      if (currentTick >= entry.expiresAtTick) cache.delete(entry.name);
    }
  }
  function lookup(name, currentTick = 0) {
    evictExpired(currentTick);
    lookups += 1;
    const entry = cache.get(name);
    if (entry) {  // hit inside ttlTicks: no authoritative consult
      cachedHits += 1;
      lastLookup = { name, status: 'HIT', target: entry.target, atTick: currentTick };
      return entry.target;
    }
    authoritative += 1;
    const target = records.get(name) ?? null;
    if (target === null) {  // unknown name: an answer, not a throw
      lastLookup = { name, status: 'NX', target: null, atTick: currentTick };
      return { status: 'NX' };
    }
    cache.set(name, { name, target, expiresAtTick: currentTick + ttlTicks });
    lastLookup = { name, status: 'MISS', target, atTick: currentTick };
    return target;
  }
  function snapshot(currentTick = 0) {
    evictExpired(currentTick);
    return { address, ttlTicks, lookups, cachedHits, authoritative, lastLookup,
      entries: [...cache.values()].map((e) => ({ ...e,
        ttlRemaining: e.expiresAtTick - currentTick })) };
  }
  return { address, evictExpired, lookup, snapshot };
}`,
  },
  router: {
    file: 'js/sim/router.js',
    code: `createRouter({ leftAddress = '10.65', rightAddress = '20.1' } = {}) {
  // both interfaces must be two-number mini-IPs on different subnets
  let leftNetwork = null, rightNetwork = null, routed = 0;
  function join({ left, right }) { leftNetwork = left; rightNetwork = right; }
  function networkFor(to) {
    return to.split('.')[0] === rightAddress.split('.')[0] ? rightNetwork : leftNetwork;
  }
  function forward({ to, request }) {  // exactly one router hop
    routed += 1;
    const net = networkFor(to);
    const exitFrom = to.split('.')[0] === rightAddress.split('.')[0]
      ? leftAddress : rightAddress;
    return net.send({ from: exitFrom, to, request });
  }
  function forwardQueue({ id, to, request, atTick, isYou = false }) {
    routed += 1;
    const net = networkFor(to);
    const exitFrom = to.split('.')[0] === rightAddress.split('.')[0]
      ? leftAddress : rightAddress;
    net.deliverToQueue({ id, from: exitFrom, to, request, atTick, isYou });
  }
  function handleRequest() {  // the 20-side interface endpoint in 6a
    return \`200 Router \${rightAddress}\`;
  }
  return { address: leftAddress, rightAddress, join, forward, forwardQueue,
    handleRequest, snapshot: () => ({ leftAddress, rightAddress, routed }) };
}`,
  },
};
