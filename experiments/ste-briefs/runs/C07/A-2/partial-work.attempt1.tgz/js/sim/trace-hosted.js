// DOCUMENTS: the Stage 6 trace machine — the hosted/host-less/NX branch of
// the hop-by-hop trace, split from trace.js by responsibility
// (guard-file-size). A hosted browser path (`example.com/about`) resolves
// its host first: the browser asks DNS 10.60, the DNS answers from its
// tick-TTL ledger, and only then does the browser emit the GET with the
// resolved target — stage 5's served chain follows with two DNS hops
// prepended. A host-less path (`/about`) is the stage-5 story byte for
// byte: no DNS hop, no cross-subnet hop. An unknown name stops at the NX
// answer: the DNS ask is answered `NX no record`, the browser renders the
// NX card, and no GET is ever emitted.
//
// CHECKS: the narrative consumes the DNS component's actual lookup record
// (`lastLookup` status HIT/MISS/NX and target) — the ask/answer frames and
// the browser's NX card are that record, not a hardcoded story.
export function createHostedTrace({
  serverAddress,
  servers,
  lb,
  dns,
  cache = null,
  workerQueue = null,
  database = null,
  bumpTick,
  getTick,
  onServe,
  onFinish,
}) {
  let trace = freshTrace();
  let served = null; // the drained response record, held between hops

  function freshTrace() {
    return {
      hop: 0,
      method: 'GET',
      path: '/about',
      from: '10.2',
      request: 'GET /about',
      hosted: false,
      host: null,
      dnsTarget: null,
      dnsStatus: null,
      targetServer: null,
      cacheStatus: null,
      dbOp: null,
      dbStale: false,
      asyncJob: false,
      response: null,
      status: null,
      body: null,
      routeId: null,
    };
  }

  function finalHop() {
    if (!trace.hosted) return 8;
    return trace.dnsStatus === 'NX' ? 3 : 10;
  }

  function drainUntilYou(targetServer) {
    for (;;) {
      const batch = targetServer.step(getTick());
      const you = batch.find((item) => item.isYou);
      if (you || batch.length === 0) return you;
    }
  }

  function backendFor(targetAddress) {
    return servers.find((s) => s.address === targetAddress) ?? servers[0];
  }

  function serve(you) {
    trace.response = you.response;
    trace.status = you.status;
    trace.body = you.body;
    trace.routeId = you.routeId;
    onServe(you);
  }

  function finish(toAddress) {
    onFinish({
      from: trace.from ?? '10.2',
      to: toAddress,
      request: trace.request,
      response: trace.response,
    });
  }

  // The stage-5 served chain, shared by the host-less story (identical hop
  // numbers) and the hosted story (shifted +2 past the DNS ask/answer).
  function routeToLb(toAddress, wireRequest) {
    return `routed ${trace.from} -> ${toAddress} (${wireRequest}) to LoadBalancer`;
  }

  function lbEnqueue(toAddress, wireRequest) {
    const atTick = bumpTick();
    const target = lb.enqueue({
      id: `you:${atTick}`,
      from: trace.from,
      to: toAddress,
      request: wireRequest,
      atTick,
      isYou: true,
    });
    trace.targetServer = target;
    return `LB ${serverAddress} -> ${target} (${wireRequest}) queued`;
  }

  function backendNarrate(narratePath) {
    const backend = backendFor(trace.targetServer);
    served = drainUntilYou(backend);
    if (served) {
      trace.cacheStatus = served.cacheStatus ?? null;
      trace.dbOp = served.dbOp ?? null;
      trace.dbStale = Boolean(served.dbStale);
      trace.asyncJob = Boolean(served.asyncJob);
      if (served.asyncJob) {
        return `${backend.address} -> ${workerQueue ? workerQueue.address : '10.40'} | enqueued async job (${narratePath})`;
      }
      if (trace.dbOp === 'WRITE') {
        return `Database WRITE ${narratePath} @ ${database.primaryAddress} (replica ${database.replicaAddress} lags ${database.replicationLagTicks}t)`;
      }
      if (trace.dbOp === 'SELECT') {
        return `Database SELECT ${narratePath} @ ${database.replicaAddress} (${trace.dbStale ? 'STALE' : 'fresh'})`;
      }
      return `Database SKIP ${narratePath} (warm cache HIT @ ${cache.address})`;
    }
    return null;
  }

  function responseEmit() {
    if (served) {
      serve(served);
      return served.asyncJob
        ? `${trace.targetServer} -> ${trace.from} | ${served.response}`
        : `${trace.targetServer} -> ${trace.from} | ${served.response} (cache ${trace.cacheStatus})`;
    }
    return null;
  }

  function networkDelivers() {
    return `Network delivered ${trace.status} response to ${trace.from}`;
  }

  function browserReceived() {
    finish(trace.targetServer ?? serverAddress);
    return `Browser ${trace.from} received and displayed ${trace.status}`;
  }

  function workerTail() {
    const dbTarget = database ? database.primaryAddress : '10.30';
    const workerAddr = workerQueue ? workerQueue.workerAddress : '10.41';
    return trace.asyncJob
      ? `Worker ${workerAddr} finished job and committed to Database ${dbTarget}`
      : `Worker ${workerAddr} idle — no async jobs in this trace`;
  }

  // The stage-5 chain keyed by its own hop number (1..7 transitions).
  function stage5Hop(hop, toAddress, wireRequest, narratePath) {
    switch (hop) {
      case 1:
        return routeToLb(toAddress, wireRequest);
      case 2:
        return lbEnqueue(toAddress, wireRequest);
      case 3:
        return backendNarrate(narratePath);
      case 4:
        return responseEmit();
      case 5:
        return networkDelivers();
      case 6:
        return browserReceived();
      case 7:
        return workerTail();
      default:
        return null;
    }
  }

  return {
    // One hop per call; returns the hop's lastFrame string or null.
    step({ method = 'GET', path = '/about', from = '10.2' } = {}) {
      let frame;
      if (trace.hop === 0 || trace.hop >= finalHop()) {
        // CHECKS: the host branch is the leading-token shape — a path that
        // starts with `/` is host-less and skips DNS entirely (named
        // counter-example: `GET /about` keeps the stage-5 8-hop story);
        // `example.com/about` splits host/path on the first `/`.
        const slashAt = String(path).indexOf('/');
        const hosted = slashAt > 0;
        trace = {
          ...freshTrace(),
          hop: 1,
          method,
          path,
          from,
          request: `${method} ${path}`,
          hosted,
          host: hosted ? String(path).slice(0, slashAt) : null,
        };
        served = null;
        if (hosted) {
          const answer = dns.lookup(trace.host, getTick());
          if (typeof answer === 'string') {
            trace.dnsTarget = answer;
            trace.dnsStatus = dns.lastLookup.status;
          } else {
            trace.dnsStatus = 'NX';
          }
          frame = `${from} -> ${dns.address} | ${trace.request}`;
        } else {
          frame = `${from} -> ${serverAddress} | ${trace.request}`;
        }
      } else if (!trace.hosted) {
        // Host-less: the stage-5 story at its own hop numbers — hop 2 is
        // the route frame, hop 3 the LB enqueue, and so on through the
        // worker tail, byte-identical to trace.js's stage-5 chain.
        trace.hop += 1;
        frame = stage5Hop(trace.hop - 1, serverAddress, trace.request, trace.path);
      } else if (trace.hop === 1) {
        // Hop 2/N: the browser asks DNS 10.60 for the host.
        trace.hop = 2;
        frame = `${trace.from} -> ${dns.address} | DNS ask ${trace.host}`;
      } else if (trace.hop === 2) {
        // Hop 3/N: the DNS answers from its ledger (or NX); an NX answer
        // renders on the browser card and the trace ends — no GET follows.
        trace.hop = 3;
        if (trace.dnsStatus === 'NX') {
          trace.response = 'NX no record';
          trace.status = 'NX';
          trace.body = 'no record';
          onFinish({
            from: trace.from,
            to: dns.address,
            request: trace.request,
            response: trace.response,
          });
          frame = `DNS ${dns.address} -> ${trace.from} | NX no record for ${trace.host}`;
        } else {
          frame = `DNS ${dns.address} -> ${trace.from} | ${trace.host} = ${trace.dnsTarget}${
            trace.dnsStatus === 'HIT' ? ' (cache HIT)' : ' (authoritative)'
          }`;
        }
      } else {
        // Hops 4..10: the stage-5 chain shifted +2 past the DNS hops, with
        // the GET carrying the resolved target and the plain path.
        trace.hop += 1;
        const wireRequest = `${trace.method} ${trace.path.slice(trace.path.indexOf('/'))}`;
        frame = stage5Hop(
          trace.hop - 3,
          trace.dnsTarget ?? serverAddress,
          wireRequest,
          trace.path.slice(trace.path.indexOf('/')),
        );
      }
      return frame;
    },

    snapshot() {
      return { ...trace };
    },
  };
}
