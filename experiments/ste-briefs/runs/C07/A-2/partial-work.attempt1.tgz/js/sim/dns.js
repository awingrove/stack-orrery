// DOCUMENTS: the Stage 6 component — an authoritative name table with a
// tick-TTL resolver ledger, mirroring the Cache's Map-lookup pattern. A
// lookup consults the authoritative table only on a cache miss or an
// expired entry; a hit inside ttlTicks is an incrementing `cachedHits`
// with no authoritative consult. Deterministic by construction: no clock,
// no RNG — time arrives as the `currentTick` argument.
//
// CHECKS: the constructor rejects an address that is not a two-number
// mini-IP and a ttlTicks that is not a positive integer (fail-loud over
// silent mis-configuration), and an expired ledger entry is evicted before
// the answer is produced, so it can never be served from the ledger.
export function createDns({ address = '10.60', ttlTicks = 300 } = {}) {
  if (!/^\d+\.\d+$/.test(address)) {
    throw new Error(`dns: invalid mini-IP address ${address}`);
  }
  if (!Number.isInteger(ttlTicks) || ttlTicks < 1) {
    throw new Error(`dns: ttlTicks must be a positive integer, got ${ttlTicks}`);
  }
  // The authoritative table: name -> mini-IP. Stage 6b adds a CDN name.
  const records = new Map([['example.com', '10.1']]);
  const cache = new Map(); // name -> { name, target, expiresAtTick }
  let lookups = 0;
  let cachedHits = 0;
  let authoritative = 0;
  let lastLookup = null;

  // A ledger entry is stale the moment the current tick reaches its
  // expiry: resolved at tick T with ttlTicks = 300 lives through T + 299.
  function evictExpired(currentTick = 0) {
    for (const entry of cache.values()) {
      if (currentTick >= entry.expiresAtTick) cache.delete(entry.name);
    }
  }

  function lookup(name, currentTick = 0) {
    evictExpired(currentTick);
    lookups += 1;
    const entry = cache.get(name);
    if (entry) {
      cachedHits += 1;
      lastLookup = { name, status: 'HIT', target: entry.target, atTick: currentTick };
      return entry.target;
    }
    authoritative += 1;
    const target = records.get(name) ?? null;
    if (target === null) {
      lastLookup = { name, status: 'NX', target: null, atTick: currentTick };
      // CHECKS: an unknown name is an answer, not a crash — the browser
      // renders the NX card and no GET leaves it.
      return { status: 'NX' };
    }
    cache.set(name, { name, target, expiresAtTick: currentTick + ttlTicks });
    lastLookup = { name, status: 'MISS', target, atTick: currentTick };
    return target;
  }

  function snapshot(currentTick = 0) {
    evictExpired(currentTick);
    return {
      address,
      ttlTicks,
      lookups,
      cachedHits,
      authoritative,
      lastLookup,
      entries: [...cache.values()].map((e) => ({
        name: e.name,
        target: e.target,
        expiresAtTick: e.expiresAtTick,
        ttlRemaining: e.expiresAtTick - currentTick,
      })),
    };
  }

  return {
    get address() {
      return address;
    },
    get lastLookup() {
      return lastLookup;
    },
    evictExpired,
    lookup,
    snapshot,
  };
}
