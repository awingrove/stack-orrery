// DOCUMENTS: the Stage 6 component — a cross-subnet Router joining the
// `10.x` and `20.x` network instances at two interface addresses
// (leftAddress `10.65`, rightAddress `20.1`). Any cross-subnet frame takes
// exactly one router hop (the `routed` counter); same-subnet sends stay on
// the plain network send/deliverToQueue contract untouched. Subnet 20
// holds the router's own interface in 6a — stage 6b occupies `20.1` with
// the CDN edge — so an unregistered `20.x` host fails loud through the
// destination network's own resolution.
//
// CHECKS: the constructor rejects a non two-number mini-IP on either
// interface and a configuration whose two interfaces share one subnet.
export function createRouter({ leftAddress = '10.65', rightAddress = '20.1' } = {}) {
  if (!/^\d+\.\d+$/.test(leftAddress)) {
    throw new Error(`router: invalid mini-IP address ${leftAddress}`);
  }
  if (!/^\d+\.\d+$/.test(rightAddress)) {
    throw new Error(`router: invalid mini-IP address ${rightAddress}`);
  }
  const netOf = (addr) => String(addr).split('.')[0];
  if (netOf(leftAddress) === netOf(rightAddress)) {
    throw new Error(
      `router: interfaces must sit on different subnets, got ${leftAddress} and ${rightAddress}`,
    );
  }
  let leftNetwork = null;
  let rightNetwork = null;
  let routed = 0;

  // The engine wires both network instances in once, after construction.
  function join({ left, right }) {
    if (!left || !right) throw new Error('router: join needs both network instances');
    leftNetwork = left;
    rightNetwork = right;
  }

  function networkFor(to) {
    if (!leftNetwork || !rightNetwork) {
      throw new Error('router: no networks attached');
    }
    return netOf(to) === netOf(rightAddress) ? rightNetwork : leftNetwork;
  }

  function forward({ to, request }) {
    routed += 1;
    const net = networkFor(to);
    const exitFrom = netOf(to) === netOf(rightAddress) ? leftAddress : rightAddress;
    return net.send({ from: exitFrom, to, request });
  }

  // `isYou` rides through untouched, like the plain network's queue path.
  function forwardQueue({ id, to, request, atTick, isYou = false }) {
    routed += 1;
    const net = networkFor(to);
    const exitFrom = netOf(to) === netOf(rightAddress) ? leftAddress : rightAddress;
    net.deliverToQueue({ id, from: exitFrom, to, request, atTick, isYou });
  }

  // CHECKS: the router's 20-side interface is the endpoint itself in 6a —
  // it answers a direct frame as the interface, not as an HTTP service.
  function handleRequest() {
    return `200 Router ${rightAddress}`;
  }

  return {
    get address() {
      return leftAddress;
    },
    get rightAddress() {
      return rightAddress;
    },
    join,
    forward,
    forwardQueue,
    handleRequest,
    snapshot() {
      return { leftAddress, rightAddress, routed };
    },
  };
}
