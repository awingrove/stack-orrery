// DOCUMENTS: the network — the wiring that lets two-number mini-IP
// addressable components exchange messages. Today it carries slim HTTP
// requests to a registered server; later stages attach more components
// without changing the send/enqueue contract.
//
// Stage 6: a cross-subnet Router can be attached (`attachRouter`). When a
// frame's destination sits on a different subnet than its origin and is
// not registered locally, the frame hands off to the router for exactly
// one hop; the destination network's own resolution still decides whether
// the host exists, so unregistered cross-subnet hosts fail loud the same
// way local ones do. Same-subnet sends are untouched.
//
// CHECKS: every address crossing the wire is validated as a two-number
// mini-IP (<net>.<host>), and sends to unregistered hosts fail loud.
const MINI_IP = /^\d+\.\d+$/;

export function createNetwork() {
  const servers = new Map();
  let router = null;

  function validate(addr) {
    if (!MINI_IP.test(addr)) {
      throw new Error(`network: invalid mini-IP address ${addr}`);
    }
  }

  function resolve(address) {
    validate(address);
    const server = servers.get(address);
    if (!server) {
      throw new Error(`network: no server at ${address}`);
    }
    return server;
  }

  // CHECKS: the cross-subnet branch fires only when the destination is
  // absent locally AND sits on another subnet — a plain unknown host on
  // the local subnet still throws, exactly as it did before Stage 6.
  function crossSubnet(from, to) {
    return (
      router !== null && !servers.has(to) && String(from).split('.')[0] !== String(to).split('.')[0]
    );
  }

  return {
    registerServer(address, server) {
      validate(address);
      servers.set(address, server);
    },

    resolve,

    attachRouter(crossRouter) {
      router = crossRouter;
    },

    send({ from, to, request }) {
      validate(from);
      if (crossSubnet(from, to)) return router.forward({ from, to, request });
      const server = resolve(to);
      const response = server.handleRequest(request);
      return { from, to, request, response };
    },

    // `isYou` rides through untouched: the engine marks the learner's own
    // interactive-browser request, the server stores it on the queue row.
    deliverToQueue({ id, from, to, request, atTick, isYou = false }) {
      validate(from);
      if (crossSubnet(from, to)) {
        router.forwardQueue({ id, from, to, request, atTick, isYou });
        return;
      }
      const server = resolve(to);
      server.enqueue({ id, from, to, request, atTick, isYou });
    },
  };
}
