import { describe, it, expect } from 'vitest';
import { createDns } from '../../js/sim/dns.js';
import { createEngine } from '../../js/sim/engine.js';

describe('createDns', () => {
  // PINS: the TTL branch — a hit inside ttlTicks is an incrementing
  // cachedHits with no authoritative consult, and an expired entry is
  // evicted before the answer is produced, so it can never be answered
  // from the ledger (named counter-example below).
  it('resolves example.com to 10.1 and consults the authoritative table only on miss or expiry', () => {
    const dns = createDns({ address: '10.60', ttlTicks: 300 });

    // Cold lookup: the authoritative table answers and the ledger fills.
    expect(dns.lookup('example.com', 1)).toBe('10.1');
    let snap = dns.snapshot(1);
    expect(snap).toMatchObject({
      address: '10.60',
      ttlTicks: 300,
      lookups: 1,
      cachedHits: 0,
      authoritative: 1,
    });
    expect(snap.entries).toEqual([
      { name: 'example.com', target: '10.1', expiresAtTick: 301, ttlRemaining: 300 },
    ]);
    expect(dns.lastLookup).toEqual({
      name: 'example.com',
      status: 'MISS',
      target: '10.1',
      atTick: 1,
    });

    // Hit inside ttlTicks: cachedHits climbs, the authoritative count does
    // not move — the table is not consulted.
    expect(dns.lookup('example.com', 150)).toBe('10.1');
    expect(dns.lookup('example.com', 300)).toBe('10.1');
    snap = dns.snapshot(300);
    expect(snap).toMatchObject({ lookups: 3, cachedHits: 2, authoritative: 1 });
    expect(dns.lastLookup.status).toBe('HIT');

    // Named counter-example: the entry expired at tick 301 — the lookup
    // evicts it (the ledger is empty) and answers from a fresh
    // authoritative consult; the expired ledger row is not the answer
    // source.
    expect(dns.lookup('example.com', 301)).toBe('10.1');
    snap = dns.snapshot(301);
    expect(snap).toMatchObject({ lookups: 4, cachedHits: 2, authoritative: 2 });
    expect(snap.entries).toEqual([
      { name: 'example.com', target: '10.1', expiresAtTick: 601, ttlRemaining: 300 },
    ]);
    expect(dns.lastLookup.status).toBe('MISS');

    // CHECKS: the constructor rejects a non-mini-IP address and a
    // non-positive or non-integer ttlTicks (fail-loud over misconfig).
    expect(() => createDns({ address: '1060' })).toThrow(/invalid mini-IP/);
    expect(() => createDns({ ttlTicks: 0 })).toThrow(/ttlTicks/);
    expect(() => createDns({ ttlTicks: 1.5 })).toThrow(/ttlTicks/);
  });

  // PINS: the NX branch — an unknown name is an answer object, not a
  // throw, and it never enters the ledger (the browser renders the NX
  // card; the throw rule belongs to cross-subnet addresses).
  it('answers unknown names with NX without a throw and leaves the ledger empty', () => {
    const dns = createDns();
    expect(() => dns.lookup('nope.example', 0)).not.toThrow();
    expect(dns.lookup('nope.example', 0)).toEqual({ status: 'NX' });
    expect(dns.lastLookup).toEqual({
      name: 'nope.example',
      status: 'NX',
      target: null,
      atTick: 0,
    });
    const snap = dns.snapshot(0);
    expect(snap).toMatchObject({ lookups: 2, cachedHits: 0, authoritative: 2 });
    expect(snap.entries).toEqual([]);
  });
});

describe('stage 6 dns wiring', () => {
  // PINS: the engine instantiates DNS 10.60 from stage 6 on and exposes it
  // on the snapshot; a hosted trace consumes the real ledger while a
  // host-less path (GET /about) leaves the ledger untouched.
  it('exposes DNS 10.60 on the snapshot and hosted traces consume the ledger', () => {
    const engine = createEngine({ stage: 6 });
    let snap = engine.snapshot();
    expect(snap.dns).not.toBe(null);
    expect(snap.dns.address).toBe('10.60');
    expect(snap.dns.ttlTicks).toBe(300);

    for (let hop = 0; hop < 10; hop++) {
      engine.traceHop({ method: 'GET', path: 'example.com/about' });
    }
    snap = engine.snapshot();
    expect(snap.trace.hop).toBe(10);
    expect(snap.trace.dnsStatus).toBe('MISS');
    expect(snap.trace.dnsTarget).toBe('10.1');
    expect(snap.dns).toMatchObject({ lookups: 1, cachedHits: 0, authoritative: 1 });
    expect(snap.browserDisplay.body).toBe('This is the about page');

    for (let hop = 0; hop < 10; hop++) {
      engine.traceHop({ method: 'GET', path: 'example.com/about' });
    }
    snap = engine.snapshot();
    expect(snap.trace.dnsStatus).toBe('HIT');
    expect(snap.dns).toMatchObject({ lookups: 2, cachedHits: 1, authoritative: 1 });

    // The host-less path skips DNS entirely: the ledger counters do not move.
    for (let hop = 0; hop < 8; hop++) {
      engine.traceHop({ method: 'GET', path: '/about' });
    }
    snap = engine.snapshot();
    expect(snap.trace.hop).toBe(8);
    expect(snap.trace.hosted).toBe(false);
    expect(snap.dns).toMatchObject({ lookups: 2, cachedHits: 1, authoritative: 1 });

    // Stages 1-5 expose no DNS at all.
    expect(createEngine({ stage: 5 }).snapshot().dns).toBe(null);
    expect(createEngine({ stage: 1 }).snapshot().dns).toBe(null);
  });
});
