import { describe, it, expect } from 'vitest';
import { createNetwork } from '../../js/sim/network.js';
import { createRouter } from '../../js/sim/router.js';
import { createWebServer } from '../../js/sim/webserver.js';
import { createEngine } from '../../js/sim/engine.js';

describe('createRouter', () => {
  // PINS: the cross-subnet branch — a frame into subnet 20 takes exactly
  // one router hop (routed +1) through the destination network's own
  // resolution, an unregistered 20.x host (20.9) fails loud, and
  // same-subnet sends stay on the plain contract with routed untouched.
  it('forwards cross-subnet sends through exactly one router hop and fails loud on unregistered 20.x hosts', () => {
    const left = createNetwork();
    const right = createNetwork();
    const router = createRouter({ leftAddress: '10.65', rightAddress: '20.1' });
    router.join({ left, right });
    left.attachRouter(router);
    right.registerServer('20.1', router);
    const server = createWebServer({ address: '10.1' });
    left.registerServer('10.1', server);

    // Same-subnet passthrough is unchanged: the plain send resolves
    // locally and the router's counter does not move.
    expect(left.send({ from: '10.2', to: '10.1', request: 'GET /' })).toEqual({
      from: '10.2',
      to: '10.1',
      request: 'GET /',
      response: '200 Welcome to the home page',
    });
    expect(router.snapshot()).toEqual({ leftAddress: '10.65', rightAddress: '20.1', routed: 0 });

    // Cross-subnet: exactly one hop, answered by the router's own 20-side
    // interface — the only endpoint subnet 20 holds in 6a. The wire record
    // names the router's exit interface as the hop's sender.
    expect(left.send({ from: '10.2', to: '20.1', request: 'GET /' })).toEqual({
      from: '10.65',
      to: '20.1',
      request: 'GET /',
      response: '200 Router 20.1',
    });
    expect(router.snapshot().routed).toBe(1);

    // CHECKS: an unregistered 20.x host throws through the destination
    // network's resolution (DL-1 fail-loud, mirroring local unknowns).
    expect(() => left.send({ from: '10.2', to: '20.9', request: 'GET /' })).toThrow(
      /no server at 20\.9/,
    );
    expect(() =>
      left.deliverToQueue({ id: '1:0', from: '10.2', to: '20.9', request: 'GET /', atTick: 1 }),
    ).toThrow(/no server at 20\.9/);
    // Each forwarded frame takes its router hop; the destination network's
    // fail-loud resolution then drops it — the two 20.9 attempts crossed.
    expect(router.snapshot().routed).toBe(3);

    // A network without an attached router keeps the old fail-loud shape.
    const detached = createNetwork();
    detached.registerServer('10.1', server);
    expect(() => detached.send({ from: '10.2', to: '20.1', request: 'GET /' })).toThrow(
      /no server at 20\.1/,
    );

    // CHECKS: the constructor rejects a non-mini-IP interface and a
    // same-subnet pair.
    expect(() => createRouter({ leftAddress: '1065' })).toThrow(/invalid mini-IP/);
    expect(() => createRouter({ rightAddress: '20' })).toThrow(/invalid mini-IP/);
    expect(() => createRouter({ leftAddress: '10.65', rightAddress: '10.66' })).toThrow(
      /different subnets/,
    );
    expect(() => createRouter().forward({ from: '10.2', to: '20.1', request: 'GET /' })).toThrow(
      /no networks attached/,
    );
  });

  // PINS: the engine joins subnet 20 through the router from stage 6 on
  // and exposes the routed counter on the snapshot; stages 1-5 expose none.
  it('stage 6 engine joins subnet 20 through the router and exposes routed counters', () => {
    const engine = createEngine({ stage: 6 });
    const snap = engine.snapshot();
    expect(snap.router).toEqual({ leftAddress: '10.65', rightAddress: '20.1', routed: 0 });

    // Crowd ticks are same-subnet (10.x -> 10.1): the router stays idle.
    engine.step();
    engine.step();
    expect(engine.snapshot().router.routed).toBe(0);
    expect(engine.snapshot().served).toBeGreaterThan(0);

    expect(createEngine({ stage: 5 }).snapshot().router).toBe(null);
    expect(createEngine({ stage: 1 }).snapshot().router).toBe(null);
  });
});
