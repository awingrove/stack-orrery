import { describe, it, expect } from 'vitest';
import { describeSnapshot } from '../../js/panel/model.js';
import { componentTitle, formatComponentState } from '../../js/panel/inspector-state.js';
import { computeStageLayout } from '../../js/panel/layout.js';
import { createEngine } from '../../js/sim/engine.js';

// PINS: Stage-boundary extraction (guard-file-size): the Stage 6 narrative
// branches are pinned here — the counter-example pins the host-less story
// byte-identical to Stage 5, the hosted path adds exactly two DNS hops,
// and the NX path stops before any GET is emitted.
describe('describeSnapshot — Stage 6 traces', () => {
  const base = (trace) => ({
    stage: 6,
    tick: 2,
    users: 5,
    serverAddress: '10.1',
    queueDepth: 0,
    served: 1,
    avgLatencyTicks: 1,
    loadBalancer: { address: '10.1', nextBackend: '10.11', perBackend: {} },
    cache: { address: '10.20', ttlTicks: 10, hits: 0, misses: 1, entries: [] },
    database: {
      primaryAddress: '10.30',
      replicaAddress: '10.31',
      replicationLagTicks: 3,
      rows: [],
    },
    workerQueue: { address: '10.40', workerAddress: '10.41', pendingJobs: [] },
    dns: {
      address: '10.60',
      ttlTicks: 300,
      lookups: 1,
      cachedHits: 0,
      authoritative: 1,
      entries: [],
    },
    router: { leftAddress: '10.65', rightAddress: '20.1', routed: 0 },
    trace,
  });

  const syncTrace = {
    hop: 6,
    method: 'GET',
    path: '/about',
    request: 'GET /about',
    targetServer: '10.11',
    cacheStatus: 'MISS',
    dbOp: 'SELECT',
    dbStale: false,
    asyncJob: false,
    response: '200 This is the about page',
    status: 200,
    body: 'This is the about page',
    routeId: 'about',
  };

  it('keeps the host-less GET /about story byte-identical to Stage 5', () => {
    // CHECKS: the named counter-example — the same trace shape rendered as
    // Stage 5 and as Stage 6's host-less path must produce identical hop
    // sentences, hop counts, and trace frames. No DNS hop, no cross-subnet
    // hop, 8 hops.
    const stage6Snap = base({ ...syncTrace, hosted: false, host: null });
    for (let hop = 1; hop <= 8; hop++) {
      const t5 = { ...syncTrace, hop };
      const t6 = { ...syncTrace, hop, hosted: false, host: null };
      expect(describeSnapshot({ ...base(t5), stage: 5, dns: null }).hopStatus).toBe(
        describeSnapshot({ ...base(t6) }).hopStatus,
      );
      expect(describeSnapshot({ ...base(t6) }).totalHops).toBe(8);
    }
    expect(describeSnapshot(stage6Snap).hop).toBe(6);

    // The engines agree too: same seed, same /about path, hop-for-hop
    // identical lastFrame strings across Stage 5 and Stage 6.
    const e5 = createEngine({ stage: 5 });
    const e6 = createEngine({ stage: 6 });
    const frames5 = [];
    const frames6 = [];
    for (let hop = 0; hop < 8; hop++) {
      e5.traceHop({ method: 'GET', path: '/about' });
      e6.traceHop({ method: 'GET', path: '/about' });
      frames5.push(e5.snapshot().lastFrame);
      frames6.push(e6.snapshot().lastFrame);
    }
    expect(frames6).toEqual(frames5);
    expect(e6.snapshot().dns).toMatchObject({ lookups: 0, cachedHits: 0, authoritative: 0 });
  });

  it('adds exactly two DNS hops to the hosted path — 10 hops with the ask and the answer', () => {
    const hostedTrace = {
      ...syncTrace,
      hop: 6,
      path: 'example.com/about',
      request: 'GET example.com/about',
      hosted: true,
      host: 'example.com',
      dnsTarget: '10.1',
      dnsStatus: 'MISS',
    };
    const labels = describeSnapshot(base(hostedTrace));
    expect(labels.totalHops).toBe(10);
    expect(labels.hopStatus).toBe('Hop 6/10: Database SELECT @ Replica (10.31) — fresh');

    const hopLabel = (hop, over = {}) =>
      describeSnapshot(base({ ...hostedTrace, hop, ...over })).hopStatus;
    expect(hopLabel(1)).toBe('Hop 1/10: Browser (10.2) emits "GET example.com/about"');
    expect(hopLabel(2)).toBe('Hop 2/10: Browser (10.2) asks DNS (10.60) — resolve example.com');
    expect(hopLabel(3)).toBe('Hop 3/10: DNS (10.60) -> 10.2 | example.com = 10.1 (authoritative)');
    expect(hopLabel(3, { dnsStatus: 'HIT' })).toBe(
      'Hop 3/10: DNS (10.60) -> 10.2 | example.com = 10.1 (cache HIT)',
    );
    // The served chain replays Stage 5's sentences at their shifted hops.
    expect(hopLabel(4)).toBe('Hop 4/10: Network (10.x) routes to LoadBalancer (10.1)');
    expect(hopLabel(5)).toBe('Hop 5/10: LoadBalancer (10.1) -> 10.11 queue');
    expect(hopLabel(7)).toBe(
      'Hop 7/10: WebServer (10.11) -> "200 This is the about page" (cache MISS)',
    );
    expect(hopLabel(9)).toBe('Hop 9/10: Browser (10.2) received and displayed 200');
    expect(hopLabel(10)).toBe('Hop 10/10: Worker (10.41) idle — no async jobs in this trace');
  });

  it('stops the NX path at the DNS answer after 3 hops — no GET is emitted', () => {
    const nxTrace = {
      ...syncTrace,
      hop: 3,
      path: 'nope.example/about',
      request: 'GET nope.example/about',
      hosted: true,
      host: 'nope.example',
      dnsTarget: null,
      dnsStatus: 'NX',
      cacheStatus: null,
      dbOp: null,
      response: 'NX no record',
      status: 'NX',
      body: 'no record',
      routeId: null,
      targetServer: null,
    };
    const nxSnap = {
      ...base(nxTrace),
      browserDisplay: {
        from: '10.2',
        to: '10.60',
        request: 'GET nope.example/about',
        response: 'NX no record',
        status: 'NX',
        body: 'no record',
      },
    };
    const labels = describeSnapshot(nxSnap);
    expect(labels.totalHops).toBe(3);
    const hopLabel = (hop) => describeSnapshot(base({ ...nxTrace, hop })).hopStatus;
    expect(hopLabel(1)).toBe('Hop 1/3: Browser (10.2) emits "GET nope.example/about"');
    expect(hopLabel(2)).toBe('Hop 2/3: Browser (10.2) asks DNS (10.60) — resolve nope.example');
    expect(hopLabel(3)).toBe('Hop 3/3: DNS (10.60) -> 10.2 | NX no record for nope.example');
    // The browser card renders the NX answer (status NX, body no record).
    expect(labels.browserStatus).toBe('NX (GET nope.example/about)');
    expect(labels.browserBody).toBe('no record');
  });

  it('mirrors the DNS ledger and Router counters in the inspector state', () => {
    const snap = base({
      ...syncTrace,
      hosted: true,
      host: 'example.com',
      dnsTarget: '10.1',
      dnsStatus: 'MISS',
    });
    const dnsState = JSON.parse(formatComponentState(snap, 'dns'));
    expect(dnsState).toEqual({
      address: '10.60',
      ttlTicks: 300,
      lookups: 1,
      cachedHits: 0,
      authoritative: 1,
      lastLookup: null,
      entries: [],
    });
    const routerState = JSON.parse(formatComponentState(snap, 'router'));
    expect(routerState).toEqual({ leftAddress: '10.65', rightAddress: '20.1', routed: 0 });
    const networkState = JSON.parse(formatComponentState(snap, 'network'));
    expect(networkState.interfaces['10.60']).toBe('DNS');
    expect(networkState.interfaces['10.65']).toBe('Router (10.x side)');
    expect(networkState.interfaces['20.1']).toBe('Router (20.x side)');
    expect(componentTitle(snap, 'dns')).toBe('DNS — mini-IP 10.60');
    expect(componentTitle(snap, 'router')).toBe('Router — 10.65 ⇄ 20.1');
  });

  it('lays out the 8-ring Stage 6 orrery with DNS on Ring 7 and the Router beside the 10.x hub', () => {
    const layout = computeStageLayout(6, 5);
    expect(layout.rings.map((r) => r.radius)).toEqual([
      400, 800, 1200, 1600, 2000, 2400, 2800, 3200,
    ]);
    expect(layout.rings.map((r) => r.id)).toEqual([
      'ring-db',
      'ring-workers',
      'ring-cache',
      'ring-compute',
      'ring-lb',
      'ring-network',
      'ring-dns',
      'ring-clients',
    ]);
    expect(layout.nodes['node-dns']).toMatchObject({ radius: 2800, ring: 'ring-dns' });
    expect(layout.nodes['node-router']).toMatchObject({ radius: 2400, ring: 'ring-network' });
    expect(layout.nodes['node-browser']).toMatchObject({ radius: 3200, ring: 'ring-clients' });
    expect(layout.wires.map((w) => w.id)).toEqual([
      'wire-browser-network',
      'wire-network-lb',
      'wire-lb-webserver',
      'wire-lb-webserver-2',
      'wire-webserver-cache',
      'wire-webserver-2-cache',
      'wire-cache-db',
      'wire-cache-queue',
      'wire-queue-worker',
      'wire-worker-db',
      'wire-browser-dns',
      'wire-network-router',
    ]);
    expect(layout.bounds).toEqual({ minX: -3380, maxX: 120, minY: -540, maxY: 540 });
    // CHECKS: the stage range stays fail-loud beyond the live set.
    expect(() => computeStageLayout(7)).toThrow(/stage/);
    expect(() => computeStageLayout(0)).toThrow(/stage/);
  });
});
