import { test, expect } from '@playwright/test';

// Stage 6 (stage6a brief): DNS 10.60 with its tick-TTL ledger and the
// cross-subnet Router 10.65 ⇄ 20.1 on an 8-ring orrery. The trace branches
// on host syntax — a hosted path resolves through DNS before the GET, a
// host-less path keeps the Stage 5 story, and an unknown name stops at NX.
// These assertions live in their own spec (guard-file-size splits e2e by
// responsibility; panel.spec.js sits at its 450-line cap).

test('should switch to Stage 6, resolve example.com through DNS 10.60, and inspect DNS code + TTL ledger', async ({
  page,
}) => {
  await page.goto('/panel.html?stage=6&users=3');
  await expect(page.getByTestId('stage-pill-6')).toHaveAttribute('aria-current', 'true');
  await expect(page.getByTestId('node-dns')).toBeVisible();
  await expect(page.getByTestId('node-router')).toBeVisible();
  await expect(page.locator('.orrery-ring')).toHaveCount(8);
  await expect(page.locator('.orrery-ring').first()).toHaveAttribute('r', '400');
  await expect(page.locator('.orrery-ring').last()).toHaveAttribute('r', '3200');
  await expect(page.getByTestId('dns-stats')).toHaveText(
    'Lookups: 0 · Cached hits: 0 · Authoritative: 0 · TTL: 300t',
  );
  await expect(page.getByTestId('router-stats')).toHaveText('Routed: 0 · 10.65 ⇄ 20.1');
  await expect(page.locator('#node-router .ip-chip')).toHaveText('10.65 ⇄ 20.1');

  // First hosted trace: the cold ledger lookup misses and fills the entry.
  await page.getByTestId('url-input').fill('example.com/about');
  for (let hop = 0; hop < 10; hop++) await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toContainText('Hop 10/10');
  await expect(page.getByTestId('browser-rendered-body')).toHaveText('This is the about page');
  await expect(page.getByTestId('dns-stats')).toHaveText(
    'Lookups: 1 · Cached hits: 0 · Authoritative: 1 · TTL: 300t',
  );
  await expect(page.getByTestId('dns-entries-list')).toContainText('example.com = 10.1 · ttl');

  // Second hosted trace: the ledger answers a warm hit — the authoritative
  // table was consulted only once.
  for (let hop = 0; hop < 10; hop++) await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('dns-stats')).toHaveText(
    'Lookups: 2 · Cached hits: 1 · Authoritative: 1 · TTL: 300t',
  );

  // The DNS card's code and live ledger state open in the bottom inspector.
  await page.getByTestId('node-dns').click();
  await expect(page.getByTestId('inspector-code')).toContainText('createDns');
  await expect(page.getByTestId('inspector-state')).toContainText('"cachedHits": 1');
  await expect(page.getByTestId('inspector-title')).toHaveText('DNS — mini-IP 10.60');
});

test('should trace example.com/about with DNS ask + answer hops', async ({ page }) => {
  await page.goto('/panel.html');
  await page.getByTestId('stage-pill-6').click();
  await page.getByTestId('url-input').fill('example.com/about');

  // Hop 1 emits, hop 2 is the DNS ask, hop 3 the answer naming the
  // resolved target — then the GET leaves toward 10.1.
  await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toHaveText(
    'Hop 1/10: Browser (10.2) emits "GET example.com/about"',
  );
  await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toHaveText(
    'Hop 2/10: Browser (10.2) asks DNS (10.60) — resolve example.com',
  );
  await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toHaveText(
    'Hop 3/10: DNS (10.60) -> 10.2 | example.com = 10.1 (authoritative)',
  );
  await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toHaveText(
    'Hop 4/10: Network (10.x) routes to LoadBalancer (10.1)',
  );

  // The second hosted trace's answer hop reads the warm ledger hit.
  for (let hop = 0; hop < 6; hop++) await page.getByTestId('btn-next-hop').click();
  await page.getByTestId('url-input').fill('example.com/about');
  for (let hop = 0; hop < 3; hop++) await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toHaveText(
    'Hop 3/10: DNS (10.60) -> 10.2 | example.com = 10.1 (cache HIT)',
  );
});

test('should keep GET /about on Stage 6 at the Stage 5 hop story', async ({ page }) => {
  // Counter-example pin: a host-less path skips DNS entirely — 8 hops,
  // byte-identical Stage 5 sentences, an untouched resolver ledger.
  await page.goto('/panel.html');
  await page.getByTestId('stage-pill-6').click();
  await expect(page.getByTestId('node-dns')).toBeVisible();
  await page.getByTestId('url-input').fill('/about');
  for (let hop = 0; hop < 4; hop++) await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toHaveText(
    'Hop 4/8: Database SELECT @ Replica (10.31) — fresh',
  );
  for (let hop = 0; hop < 4; hop++) await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toContainText('Hop 8/8');
  await expect(page.getByTestId('browser-rendered-body')).toHaveText('This is the about page');
  await expect(page.getByTestId('dns-stats')).toHaveText(
    'Lookups: 0 · Cached hits: 0 · Authoritative: 0 · TTL: 300t',
  );
  await expect(page.getByTestId('dns-entries-list')).toHaveText('');
});

test('should stop nope.example/about at DNS NX without emitting a GET', async ({ page }) => {
  await page.goto('/panel.html');
  await page.getByTestId('stage-pill-6').click();
  await page.getByTestId('url-input').fill('nope.example/about');
  for (let hop = 0; hop < 3; hop++) await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toHaveText(
    'Hop 3/3: DNS (10.60) -> 10.2 | NX no record for nope.example',
  );
  await expect(page.getByTestId('browser-status-badge')).toHaveText('NX (GET nope.example/about)');
  await expect(page.getByTestId('browser-rendered-body')).toHaveText('no record');
  // No GET left the browser: no served exchange, no LB forwarding, and the
  // ledger records exactly the one authoritative NX consult.
  await expect(page.getByTestId('exchange-inspector')).toHaveText('No requests served yet');
  await expect(page.getByTestId('dns-stats')).toHaveText(
    'Lookups: 1 · Cached hits: 0 · Authoritative: 1 · TTL: 300t',
  );
  await expect(page.getByTestId('lb-next-backend')).toHaveText('Next -> 10.11');
});
