// DOCUMENTS: the Stage 6 component — a cross-subnet router joining the
// 10.x and 20.x network instances. Its left interface (10.65) rides the
// 10.x fabric; its right interface (20.1) is registered inside the 20.x
// network as the subnet's gateway, so a frame addressed into 20.x crosses
// in exactly one router hop (routed +1) and the far network's own
// fail-loud rule still applies: an unregistered host (20.9) throws from
// network.js before the hop is counted.
//
// CHECKS: the constructor rejects addresses that are not two-number
// mini-IPs and a router whose two interfaces share one subnet (it would
// not join anything). The gateway itself answers a synchronous send with
// a slim diagnostic — no queue lives behind it, so a queue delivery aimed
// at the gateway fails loud instead of vanishing.
const MINI_IP = /^\d+\.\d+$/;

export function createRouter({ leftAddress = '10.65', rightAddress = '20.1' } = {}) {
  if (!MINI_IP.test(leftAddress)) {
    throw new Error(`router: invalid mini-IP address ${leftAddress}`);
  }
  if (!MINI_IP.test(rightAddress)) {
    throw new Error(`router: invalid mini-IP address ${rightAddress}`);
  }
  if (leftAddress.split('.')[0] === rightAddress.split('.')[0]) {
    throw new Error(
      `router: interfaces must join distinct subnets, got ${leftAddress} and ${rightAddress}`,
    );
  }
  let routed = 0;
  let lastRoute = null;
  let sides = null; // { left, right } — the joined network instances

  function netOf(address) {
    return String(address).split('.')[0];
  }

  // The far network is the one whose subnet owns the destination address.
  function farNetwork(to) {
    if (!sides) throw new Error('router: no networks joined');
    return netOf(to) === netOf(leftAddress) ? sides.left : sides.right;
  }

  return {
    get leftAddress() {
      return leftAddress;
    },
    get rightAddress() {
      return rightAddress;
    },

    // Join the two network instances and stand as the gateway inside the
    // far (20.x) network at the right interface.
    join(left, right) {
      sides = { left, right };
      left.setRouter(this);
      right.setRouter(this);
      right.registerServer(rightAddress, this);
    },

    // One cross-subnet hop: the far network resolves first (unregistered
    // hosts throw before routed counts), then the hop is recorded.
    route({ from, to, request }) {
      const response = farNetwork(to).send({ from, to, request }).response;
      routed += 1;
      lastRoute = { from, to, request };
      return { from, to, request, response };
    },

    // Queue delivery across the subnet boundary; `isYou` rides through
    // untouched, exactly like the same-subnet deliverToQueue contract.
    routeQueue({ id, from, to, request, atTick, isYou = false }) {
      if (to === leftAddress || to === rightAddress) {
        throw new Error(`router: no queue behind the gateway at ${to}`);
      }
      farNetwork(to).deliverToQueue({ id, from, to, request, atTick, isYou });
      routed += 1;
      lastRoute = { from, to, request };
    },

    // The gateway's own slim answer (registered at 20.1 inside the 20.x
    // network) — a diagnostic, not a page: Stage 6b occupies subnet 20
    // with the CDN edge.
    handleRequest() {
      return '200 Router 20.1';
    },

    snapshot() {
      return { leftAddress, rightAddress, routed, lastRoute };
    },
  };
}
