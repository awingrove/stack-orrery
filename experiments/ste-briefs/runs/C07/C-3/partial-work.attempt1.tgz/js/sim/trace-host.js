// DOCUMENTS: the Stage 6 hosted-path grammar — a browser URL that carries a
// host (`example.com/about`) resolves through DNS 10.60 before any GET is
// emitted: hop 1 is the ask, hop 2 the answer (or NX), and only a resolved
// host continues into the request's Stage 5 journey. Host-less paths
// (`/about`) never touch DNS — their hop story stays byte-identical to
// Stage 5's. Split from trace.js by responsibility (guard-file-size): this
// module owns the URL split and the two DNS-phase hops; trace.js owns the
// machine's hop transitions.
//
// CHECKS: the host/path split is the first-slash rule — a leading slash is
// host-less, and a bare host with no path resolves to path `/`. The DNS
// consult happens exactly once per hosted trace, at the ask hop, so the
// ledger counters (lookups / cachedHits / authoritative) match the hops
// the learner watches. An NX answer ends the trace: no GET is ever
// emitted, the browser renders the NX card.
export function splitHostPath(path) {
  const raw = String(path);
  const slash = raw.indexOf('/');
  if (slash === -1) {
    return { host: raw.length > 0 ? raw : null, path: '/' };
  }
  if (slash === 0) {
    return { host: null, path: raw };
  }
  return { host: raw.slice(0, slash), path: raw.slice(slash) };
}

// Hop 1 of a hosted trace: the browser asks the resolver. The lookup runs
// here — once — so the answer, the counters, and the trace's final hop
// count are all known before the answer hop renders.
export function dnsAsk({ from, host, dns, currentTick }) {
  const answer = dns.lookup(host, currentTick);
  return {
    answer,
    frame: `${from} -> ${dns.address} | ask ${host}`,
  };
}

// Hop 2 of a hosted trace: the resolver answers the ask it stored. NX ends
// the trace at the answer itself — the browser renders the NX card.
export function dnsAnswer({ trace, dns, onFinish }) {
  if (trace.dnsStatus === 'NX') {
    const response = `NX no record for ${trace.host}`;
    trace.response = response;
    onFinish({
      from: trace.from ?? '10.2',
      to: dns.address,
      request: `ask ${trace.host}`,
      response,
    });
    return `${dns.address} -> ${trace.from} | ${response}`;
  }
  return `${dns.address} -> ${trace.from} | ${trace.host} is ${trace.dnsTarget}`;
}
