// DOCUMENTS: the network — the wiring that lets two-number mini-IP
// addressable components exchange messages. Today it carries slim HTTP
// requests to a registered server; later stages attach more components
// without changing the send/enqueue contract.
//
// Stage 6 adds cross-subnet support additively: a network constructed with
// a `subnet` tag (e.g. '10') hands any frame addressed into a different
// subnet to its attached Router — exactly one router hop, `isYou` rides
// through — and keeps every same-subnet send/deliver byte-identical to
// today's contract. A subnet-less network (Stages 1-5) behaves exactly as
// before: no subnet check, no router.
//
// CHECKS: every address crossing the wire is validated as a two-number
// mini-IP (<net>.<host>), and sends to unregistered hosts fail loud — the
// far network's own fail-loud rule covers cross-subnet frames (20.9 throws
// from the 20.x network before the router hop is counted).
const MINI_IP = /^\d+\.\d+$/;

export function createNetwork({ subnet = null, router = null } = {}) {
  const servers = new Map();
  if (subnet !== null && !/^\d+$/.test(String(subnet))) {
    throw new Error(`network: subnet must be a number, got ${subnet}`);
  }
  const subnetTag = subnet === null ? null : String(subnet);

  function netOf(address) {
    return String(address).split('.')[0];
  }

  function validate(addr) {
    if (!MINI_IP.test(addr)) {
      throw new Error(`network: invalid mini-IP address ${addr}`);
    }
  }

  function resolve(address) {
    validate(address);
    const server = servers.get(address);
    if (!server) {
      throw new Error(`network: no server at ${address}`);
    }
    return server;
  }

  // A frame addressed outside this network's subnet leaves through the
  // router; without an attached router (or without a subnet tag) there is
  // no route and the send fails loud.
  function crossSubnet(message) {
    if (subnetTag === null || !router) {
      throw new Error(`network: no route from ${subnetTag ?? 'this'} subnet to ${message.to}`);
    }
    return router;
  }

  return {
    registerServer(address, server) {
      validate(address);
      servers.set(address, server);
    },

    // Stage 6 wiring: the router attaches itself to both joined networks.
    setRouter(next) {
      router = next;
    },

    resolve,

    send({ from, to, request }) {
      validate(from);
      if (subnetTag !== null && netOf(to) !== subnetTag) {
        return crossSubnet({ to }).route({ from, to, request });
      }
      const server = resolve(to);
      const response = server.handleRequest(request);
      return { from, to, request, response };
    },

    // `isYou` rides through untouched: the engine marks the learner's own
    // interactive-browser request, the server stores it on the queue row.
    deliverToQueue({ id, from, to, request, atTick, isYou = false }) {
      validate(from);
      if (subnetTag !== null && netOf(to) !== subnetTag) {
        crossSubnet({ to }).routeQueue({ id, from, to, request, atTick, isYou });
        return;
      }
      const server = resolve(to);
      server.enqueue({ id, from, to, request, atTick, isYou });
    },
  };
}
