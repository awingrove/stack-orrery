// DOCUMENTS: the single-request hop-by-hop state machine behind the panel's
// "Step 1 Hop ->" trace — one hop per call, running across the same
// network/LB/queue/cache machinery the crowd uses (it does not fake a
// shortcut). 4 hops in Stage 1 (emit, route, serve, render); 5 in Stage 2
// (the LB's round-robin pick becomes its own hop); 6 in Stage 3 (the
// backend's cache-aside lookup and the HTTP response emission split into
// two hops so the learner can watch Cache 10.20 answer, then the backend
// emit); 7 in Stage 4 (the Database hop after the cache check, narrated by
// trace-db.js); 8 in Stage 5 (the async worker tail).
//
// Stage 6 branches on the URL shape (trace-host.js): a hosted path
// (`example.com/about`) spends two hops asking DNS 10.60 and receiving the
// answer before the Stage 5 journey starts at hop 3 — or ends at hop 2 on
// NX with no GET emitted; a host-less path (`/about`) keeps Stage 5's hop
// story byte-identical.
//
// The machine owns the trace state and hop transitions; the engine owns
// the clock, the served-exchange record, and browser delivery, handed in
// as the four callbacks below.
//
// CHECKS: an out-of-range stage fails loud at construction instead of
// building a trace that can never advance.
import { splitHostPath, dnsAsk, dnsAnswer } from './trace-host.js';
import { databaseFrame } from './trace-db.js';

export function createTraceMachine({
  stage,
  serverAddress,
  servers,
  lb = null,
  network,
  cache = null,
  database = null,
  workerQueue = null,
  dns = null,
  bumpTick,
  getTick,
  onServe,
  onFinish,
}) {
  if (stage !== 1 && stage !== 2 && stage !== 3 && stage !== 4 && stage !== 5 && stage !== 6) {
    throw new Error(`trace: stage must be 1, 2, 3, 4, 5, or 6, got ${stage}`);
  }
  // Run length per stage's trace shape; Stage 6 starts from the Stage 5
  // 8-hop story — each trace stores its own finalHop at creation.
  const staticFinalHop = stage >= 5 ? 8 : stage === 4 ? 7 : stage === 3 ? 6 : stage === 2 ? 5 : 4;
  let trace = freshTrace();
  let served = null; // the drained response record, held between hops 4/6 and 5/6

  function freshTrace(over = {}) {
    return {
      hop: 0,
      method: 'GET',
      path: '/about',
      from: '10.2',
      host: null,
      request: 'GET /about',
      targetServer: null,
      cacheStatus: null,
      dbOp: null,
      dbStale: false,
      response: null,
      status: null,
      body: null,
      routeId: null,
      dnsStatus: null,
      dnsTarget: null,
      dnsSource: null,
      finalHop: staticFinalHop,
      ...over,
    };
  }

  // Serve from the front of the target's queue until the trace's own
  // request (isYou) comes back, or the queue runs dry this tick.
  function drainUntilYou(targetServer) {
    for (;;) {
      const batch = targetServer.step(getTick());
      const you = batch.find((item) => item.isYou);
      if (you || batch.length === 0) return you;
    }
  }

  function backendFor(targetAddress) {
    return servers.find((s) => s.address === targetAddress) ?? servers[0];
  }

  function serve(you) {
    trace.response = you.response;
    trace.status = you.status;
    trace.body = you.body;
    trace.routeId = you.routeId;
    onServe(you);
  }

  // Final hop: the rendered response lands on the originating browser.
  function finish(toAddress) {
    onFinish({
      from: trace.from ?? '10.2',
      to: toAddress,
      request: trace.request,
      response: trace.response,
    });
  }

  return {
    // One hop per call. Returns the hop's lastFrame string, or null when
    // nothing moved (the engine keeps its previous frame then).
    step({ method = 'GET', path = '/about', from = '10.2' } = {}) {
      // Stage 6 hosted paths shift the Stage 5 journey two hops late; the
      // restart branch and host-less paths run at offset 0.
      const off = stage === 6 && trace.host ? 2 : 0;
      let frame = null;
      if (trace.hop === 0 || trace.hop >= trace.finalHop) {
        const shape = stage === 6 ? splitHostPath(path) : { host: null, path };
        trace = freshTrace({
          hop: 1,
          method,
          path: shape.path,
          host: shape.host,
          from,
          request: `${method} ${shape.path}`,
          targetServer: stage === 1 ? serverAddress : null,
        });
        served = null;
        if (stage === 6 && shape.host) {
          // Hop 1: the browser asks DNS 10.60 — one lookup here fixes the
          // answer, the counters, and this trace's run length.
          const ask = dnsAsk({ from, host: shape.host, dns, currentTick: getTick() });
          trace.dnsStatus = ask.answer.status === 'OK' ? 'OK' : 'NX';
          trace.dnsTarget = trace.dnsStatus === 'OK' ? ask.answer.target : null;
          trace.dnsSource = trace.dnsStatus === 'OK' ? ask.answer.source : null;
          trace.finalHop = trace.dnsStatus === 'NX' ? 2 : staticFinalHop + 2;
          frame = ask.frame;
        } else {
          frame = `${from} -> ${serverAddress} | ${trace.request}`;
        }
      } else if (stage === 1 && trace.hop === 1) {
        trace.hop = 2;
        const atTick = bumpTick();
        network.deliverToQueue({
          id: `you:${atTick}`,
          from: trace.from,
          to: serverAddress,
          request: trace.request,
          atTick,
          isYou: true,
        });
        frame = `routed ${trace.from} -> ${serverAddress} (${trace.request}) into queue`;
      } else if (stage === 1 && trace.hop === 2) {
        trace.hop = 3;
        const you = drainUntilYou(servers[0]);
        if (you) {
          serve(you);
          frame = `${serverAddress} -> ${trace.from} | ${you.response}`;
        }
      } else if (stage === 1 && trace.hop === 3) {
        trace.hop = 4;
        finish(serverAddress);
      } else if (stage === 6 && trace.host && trace.hop === 1) {
        // Hop 2: the resolver answers the ask. A resolved host continues
        // the journey; an NX answer ends it right here — the browser
        // renders the NX card and no GET is ever emitted.
        trace.hop = 2;
        frame = dnsAnswer({ trace, dns, onFinish });
      } else if (stage === 6 && trace.host && trace.hop === 2) {
        // Hop 3: the browser emits the GET toward the resolved target —
        // the Stage 5 journey starts, two hops late.
        trace.hop = 3;
        frame = `${trace.from} -> ${trace.dnsTarget} | ${trace.request}`;
      } else if (trace.hop === 1 + off) {
        trace.hop = 2 + off;
        frame = `routed ${trace.from} -> ${serverAddress} (${trace.request}) to LoadBalancer`;
      } else if (trace.hop === 2 + off) {
        trace.hop = 3 + off;
        const atTick = bumpTick();
        const target = lb.enqueue({
          id: `you:${atTick}`,
          from: trace.from,
          to: serverAddress,
          request: trace.request,
          atTick,
          isYou: true,
        });
        trace.targetServer = target;
        frame = `LB ${serverAddress} -> ${target} (${trace.request}) queued`;
      } else if (stage === 2 && trace.hop === 3) {
        trace.hop = 4;
        const backend = backendFor(trace.targetServer);
        const you = drainUntilYou(backend);
        if (you) {
          serve(you);
          frame = `${backend.address} -> ${trace.from} | ${you.response}`;
        }
      } else if (stage === 2 && trace.hop === 4) {
        trace.hop = 5;
        finish(trace.targetServer ?? serverAddress);
      } else if (stage === 3 && trace.hop === 3) {
        // Hop 4/6: the target backend checks Cache and serves the queued
        // request; the response record is held one hop so the learner sees
        // the cache lookup before the response leaves the backend.
        trace.hop = 4;
        const backend = backendFor(trace.targetServer);
        served = drainUntilYou(backend);
        if (served) {
          trace.cacheStatus = served.cacheStatus ?? null;
          frame = `${backend.address} -> ${cache.address} | cache ${trace.cacheStatus} (${trace.path})`;
        }
      } else if (stage === 3 && trace.hop === 4) {
        trace.hop = 5;
        if (served) {
          serve(served);
          frame = `${trace.targetServer} -> ${trace.from} | ${served.response} (${trace.cacheStatus})`;
        }
      } else if (stage === 3 && trace.hop === 5) {
        trace.hop = 6;
        finish(trace.targetServer ?? serverAddress);
      } else if (stage === 4 && trace.hop === 3) {
        // Hop 4/7: the target backend checks Cache and serves the queued
        // request (a POST write-through carries cacheStatus INVALIDATE);
        // the response record is held so the learner watches the cache
        // lookup, then the database hop.
        trace.hop = 4;
        const backend = backendFor(trace.targetServer);
        served = drainUntilYou(backend);
        if (served) {
          trace.cacheStatus = served.cacheStatus ?? null;
          frame = `${backend.address} -> ${cache.address} | cache ${trace.cacheStatus} (${trace.path})`;
        }
      } else if (stage === 4 && trace.hop === 4) {
        // Hop 5/7: the database hop — the WRITE landed on Primary, the
        // SELECT read the Replica fresh or stale, a warm HIT skips it.
        trace.hop = 5;
        if (served) {
          trace.dbOp = served.dbOp ?? null;
          trace.dbStale = Boolean(served.dbStale);
          frame = databaseFrame({ served, path: trace.path, database, cache });
        }
      } else if (stage === 4 && trace.hop === 5) {
        trace.hop = 6;
        if (served) {
          serve(served);
          frame = `${trace.targetServer} -> ${trace.from} | ${served.response} (cache ${trace.cacheStatus})`;
        }
      } else if (stage === 4 && trace.hop === 6) {
        trace.hop = 7;
        finish(trace.targetServer ?? serverAddress);
      } else if ((stage === 5 || stage === 6) && trace.hop === 3 + off) {
        // Hop 4/8: an async POST /jobs enqueues to WorkerQueue 10.40; other
        // requests narrate the cache/database hop they actually took — no
        // phantom async jobs on GET traces (DL-4).
        trace.hop = 4 + off;
        const backend = backendFor(trace.targetServer);
        served = drainUntilYou(backend);
        if (served) {
          trace.cacheStatus = served.cacheStatus ?? null;
          trace.dbOp = served.dbOp ?? null;
          trace.dbStale = Boolean(served.dbStale);
          trace.asyncJob = Boolean(served.asyncJob);
          frame = served.asyncJob
            ? `${backend.address} -> ${workerQueue ? workerQueue.address : '10.40'} | enqueued async job (${trace.path})`
            : databaseFrame({ served, path: trace.path, database, cache });
        }
      } else if ((stage === 5 || stage === 6) && trace.hop === 4 + off) {
        // Hop 5/8: the webserver answers — an immediate 202 for async jobs,
        // the actually-served response for everything else.
        trace.hop = 5 + off;
        if (served) {
          serve(served);
          frame = served.asyncJob
            ? `${trace.targetServer} -> ${trace.from} | ${served.response}`
            : `${trace.targetServer} -> ${trace.from} | ${served.response} (cache ${trace.cacheStatus})`;
        }
      } else if ((stage === 5 || stage === 6) && trace.hop === 5 + off) {
        // Hop 6/8: WebServer returns its response via Network
        trace.hop = 6 + off;
        frame = `Network delivered ${trace.status} response to ${trace.from}`;
      } else if ((stage === 5 || stage === 6) && trace.hop === 6 + off) {
        // Hop 7/8: Browser receives and displays the response
        trace.hop = 7 + off;
        finish(trace.targetServer ?? serverAddress);
        frame = `Browser ${trace.from} received and displayed ${trace.status}`;
      } else if ((stage === 5 || stage === 6) && trace.hop === 7 + off) {
        // Hop 8/8: async job tails with the worker's commit; a request that
        // was served synchronously finds the worker idle.
        trace.hop = 8 + off;
        const dbTarget = database ? database.primaryAddress : '10.30';
        const workerAddr = workerQueue ? workerQueue.workerAddress : '10.41';
        frame = trace.asyncJob
          ? `Worker ${workerAddr} finished job and committed to Database ${dbTarget}`
          : `Worker ${workerAddr} idle — no async jobs in this trace`;
      }
      return frame;
    },

    snapshot() {
      return { ...trace };
    },
  };
}
