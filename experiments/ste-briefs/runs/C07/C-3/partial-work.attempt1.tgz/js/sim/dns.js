// DOCUMENTS: the Stage 6 component — a resolver at mini-IP 10.60 holding an
// authoritative name table (example.com -> 10.1) in front of a tick-TTL
// cache. It mirrors the Cache 10.20 ledger pattern: a lookup is a real Map
// probe on the request path, entries carry cachedAtTick/expiresAtTick, and
// an entry past its TTL does not answer — the resolver falls through to the
// authoritative table and re-arms the TTL. Deterministic by construction:
// no clock, no RNG — time arrives as the `currentTick` argument.
//
// CHECKS: the constructor rejects an address that is not a two-number
// mini-IP and a ttlTicks that is not a positive integer (fail-loud over
// silent mis-configuration). An unknown name does not throw at the DNS
// layer — it answers { status: 'NX' } and the browser renders the NX card;
// the fail-loud throw rule belongs to cross-subnet addresses (network.js).
export function createDns({ address = '10.60', ttlTicks = 300 } = {}) {
  if (!/^\d+\.\d+$/.test(address)) {
    throw new Error(`dns: invalid mini-IP address ${address}`);
  }
  if (!Number.isInteger(ttlTicks) || ttlTicks < 1) {
    throw new Error(`dns: ttlTicks must be a positive integer, got ${ttlTicks}`);
  }
  // Stage 6a authoritative table; Stage 6b adds a CDN name beside it.
  const authoritativeTable = new Map([['example.com', '10.1']]);
  const cache = new Map(); // name -> { name, target, cachedAtTick, expiresAtTick }
  let lookups = 0;
  let cachedHits = 0;
  let authoritative = 0;
  let lastLookup = null;

  // An entry is stale the moment the current tick reaches its expiry:
  // cached at tick T with ttlTicks = 300 means alive through tick T + 299.
  function evictExpired(currentTick = 0) {
    for (const entry of cache.values()) {
      if (currentTick >= entry.expiresAtTick) {
        cache.delete(entry.name);
      }
    }
  }

  // The browser's ask: consult the ledger first; only a miss or an expired
  // entry falls through to the authoritative table (the branch the TTL
  // tests pin — a hit never costs a consult, an expired entry never
  // answers from the ledger).
  function lookup(name, currentTick = 0) {
    lookups += 1;
    evictExpired(currentTick);
    const entry = cache.get(name);
    if (entry) {
      cachedHits += 1;
      lastLookup = { name, status: 'HIT', atTick: currentTick, target: entry.target };
      return { status: 'OK', target: entry.target, source: 'cache' };
    }
    authoritative += 1;
    const target = authoritativeTable.get(name) ?? null;
    if (target === null) {
      lastLookup = { name, status: 'NX', atTick: currentTick };
      return { status: 'NX' };
    }
    cache.set(name, {
      name,
      target,
      cachedAtTick: currentTick,
      expiresAtTick: currentTick + ttlTicks,
    });
    lastLookup = { name, status: 'AUTHORITATIVE', atTick: currentTick, target };
    return { status: 'OK', target, source: 'authoritative' };
  }

  function snapshot(currentTick = 0) {
    evictExpired(currentTick);
    return {
      address,
      ttlTicks,
      lookups,
      cachedHits,
      authoritative,
      lastLookup,
      cache: [...cache.values()].map((e) => ({
        name: e.name,
        target: e.target,
        cachedAtTick: e.cachedAtTick,
        expiresAtTick: e.expiresAtTick,
        ttlRemaining: e.expiresAtTick - currentTick,
      })),
    };
  }

  return {
    get address() {
      return address;
    },
    evictExpired,
    lookup,
    snapshot,
  };
}
