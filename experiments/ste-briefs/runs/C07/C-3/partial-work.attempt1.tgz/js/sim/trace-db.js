// DOCUMENTS: the per-record database narration shared by the Stage 4 and
// Stage 5/6 hop chains — the WRITE landed on Primary (replication queued
// toward the Replica), the fresh or stale SELECT read Replica, or the SKIP
// a warm cache HIT earns. Split from trace.js by responsibility
// (guard-file-size): trace.js owns the machine's hop transitions; this
// module owns the frame the database hop actually shows.
//
// CHECKS: the branch reads the served record's own fields (dbOp / dbStale)
// — the frame narrates what the record did, never a hardcoded story.
export function databaseFrame({ served, path, database, cache }) {
  const dbOp = served.dbOp ?? null;
  const stale = Boolean(served.dbStale);
  if (dbOp === 'WRITE') {
    return `Database WRITE ${path} @ ${database.primaryAddress} (replica ${database.replicaAddress} lags ${database.replicationLagTicks}t)`;
  }
  if (dbOp === 'SELECT') {
    return `Database SELECT ${path} @ ${database.replicaAddress} (${stale ? 'STALE' : 'fresh'})`;
  }
  return `Database SKIP ${path} (warm cache HIT @ ${cache.address})`;
}
