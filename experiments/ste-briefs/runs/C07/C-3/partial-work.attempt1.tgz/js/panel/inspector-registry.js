// DOCUMENTS: the Component Code & State Inspector's registry — the merged
// source map for every selectable component. Split by responsibility
// (guard-file-size): the Stage 1-5 mirrors live in inspector-source.js,
// the Stage 6 mirrors (DNS, Router) in inspector-source6.js; this module
// owns only the merge. panel.js and render.js read the registry; the
// live-state builders live in inspector-state.js.
import { COMPONENT_SOURCE as CORE_SOURCE } from './inspector-source.js';
import { COMPONENT_SOURCE_6 } from './inspector-source6.js';

export const COMPONENT_SOURCE = { ...CORE_SOURCE, ...COMPONENT_SOURCE_6 };
