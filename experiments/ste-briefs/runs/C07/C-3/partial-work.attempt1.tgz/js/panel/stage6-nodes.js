// DOCUMENTS: the Stage 6 orrery cards — #node-dns (resolver + tick-TTL
// ledger) and #node-router (cross-subnet gateway) with their ask/answer
// and route wire lanes. Built here and appended to #orrery-world: the
// static panel.html sits at its 550-line cap, so the Stage 6 cards come up
// with the panel boot (this module evaluates before panel.js's own wiring
// and render.js's els lookups read them — import order is the contract).
//
// CHECKS: every card carries the .node-card class, a data-component key
// for the inspector registry, and a data-testid matching its id for the
// e2e pins; cards and lanes start hidden so Stages 1-5 render untouched
// (render-stage.js toggles them from stage 6 on).
function el(tag, className, text = null) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== null) node.textContent = text;
  return node;
}

function buildCard({ id, component, role, subtitle, ip, stats }) {
  const card = el('article', 'node-card');
  card.id = id;
  card.setAttribute('data-testid', id);
  card.dataset.component = component;
  card.hidden = true;
  const header = el('header', 'node-head');
  const name = el('div', 'node-name');
  name.append(el('span', 'role-name', role), el('span', 'node-subtitle', subtitle));
  header.append(name, el('span', 'ip-chip', ip), el('span', 'code-chip', '</> Code'));
  card.append(header, ...stats);
  return card;
}

function statsLine({ id, text }) {
  const line = el('p', 'mono last-frame', text);
  line.id = id;
  line.setAttribute('data-testid', id);
  return line;
}

function buildWireColumn({ id, lanes }) {
  const column = el('div', 'wire-column');
  column.id = id;
  column.setAttribute('aria-hidden', 'true');
  column.hidden = true;
  for (const [laneId, text, reverse] of lanes) {
    const lane = el('div', `wire-lane${reverse ? ' reverse' : ''}`, text);
    lane.id = laneId;
    column.append(lane);
  }
  return column;
}

function dnsStats() {
  const line = statsLine({
    id: 'dns-stats',
    text: 'Lookups: 0 · Cached hits: 0 · Authoritative: 0',
  });
  const entries = el('ul', 'route-list');
  entries.id = 'dns-entries-list';
  entries.setAttribute('data-testid', 'dns-entries-list');
  entries.setAttribute('aria-label', 'Resolver ledger');
  return [line, entries];
}

function routerStats() {
  return [
    statsLine({ id: 'router-stats', text: 'Routed: 0' }),
    statsLine({ id: 'router-last-route', text: 'No cross-subnet frames routed yet' }),
  ];
}

const world = document.getElementById('orrery-world');
world.append(
  buildWireColumn({
    id: 'wire-router-col',
    lanes: [
      ['packet-req-router', 'route =>', false],
      ['packet-res-router', '<- routed', true],
    ],
  }),
  buildCard({
    id: 'node-router',
    component: 'router',
    role: 'Router',
    subtitle: 'cross-subnet gateway',
    ip: '10.65 ⇄ 20.1',
    stats: routerStats(),
  }),
  buildWireColumn({
    id: 'wire-dns-col',
    lanes: [
      ['packet-req-dns', 'ask =>', false],
      ['packet-res-dns', '<- answer', true],
    ],
  }),
  buildCard({
    id: 'node-dns',
    component: 'dns',
    role: 'DNS',
    subtitle: 'resolver + tick-TTL ledger',
    ip: '10.60',
    stats: dnsStats(),
  }),
);
