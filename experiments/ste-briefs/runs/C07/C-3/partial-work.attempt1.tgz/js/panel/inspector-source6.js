// DOCUMENTS: the Stage 6 component mirrors — DNS 10.60 (tick-TTL resolver
// ledger) and the cross-subnet Router. Split from inspector-source.js by
// responsibility (guard-file-size): the Stage 1-5 mirrors live there, the
// registry merged for the inspector lives in inspector-registry.js. The
// live-state builders live in inspector-state.js.
export const COMPONENT_SOURCE_6 = {
  dns: {
    file: 'js/sim/dns.js',
    code: `createDns({ address = '10.60', ttlTicks = 300 } = {}) {
  // address must be "<net>.<host>" — a two-number mini-IP
  const authoritativeTable = new Map([['example.com', '10.1']]);
  const cache = new Map();  // name -> { target, cachedAtTick, expiresAtTick }
  let lookups = 0, cachedHits = 0, authoritative = 0, lastLookup = null;
  function evictExpired(currentTick = 0) {
    for (const entry of cache.values()) {
      if (currentTick >= entry.expiresAtTick) cache.delete(entry.name);
    }
  }
  function lookup(name, currentTick = 0) {
    lookups += 1;
    evictExpired(currentTick);
    const entry = cache.get(name);
    if (entry) {  // a hit inside ttlTicks never consults the table
      cachedHits += 1;
      lastLookup = { name, status: 'HIT', atTick: currentTick, target: entry.target };
      return { status: 'OK', target: entry.target, source: 'cache' };
    }
    authoritative += 1;
    const target = authoritativeTable.get(name) ?? null;
    if (target === null) {  // NX never throws at the DNS layer
      lastLookup = { name, status: 'NX', atTick: currentTick };
      return { status: 'NX' };
    }
    cache.set(name, { name, target, cachedAtTick: currentTick,
      expiresAtTick: currentTick + ttlTicks });
    lastLookup = { name, status: 'AUTHORITATIVE', atTick: currentTick, target };
    return { status: 'OK', target, source: 'authoritative' };
  }
  function snapshot(currentTick = 0) {
    evictExpired(currentTick);
    return { address, ttlTicks, lookups, cachedHits, authoritative, lastLookup,
      cache: [...cache.values()].map((e) => ({ ...e,
        ttlRemaining: e.expiresAtTick - currentTick })) };
  }
  return { address, evictExpired, lookup, snapshot };
}`,
  },
  router: {
    file: 'js/sim/router.js',
    code: `createRouter({ leftAddress = '10.65', rightAddress = '20.1' } = {}) {
  // both interfaces must be "<net>.<host>" in distinct subnets
  let routed = 0, lastRoute = null, sides = null;
  function farNetwork(to) {  // the network whose subnet owns the target
    return to.split('.')[0] === leftAddress.split('.')[0] ? sides.left : sides.right;
  }
  return {
    join(left, right) {  // stand as the gateway inside the far network
      sides = { left, right };
      left.setRouter(this);
      right.setRouter(this);
      right.registerServer(rightAddress, this);
    },
    route({ from, to, request }) {  // exactly one cross-subnet hop
      const response = farNetwork(to).send({ from, to, request }).response;
      routed += 1;  // counted only after the far network accepts
      lastRoute = { from, to, request };
      return { from, to, request, response };
    },
    routeQueue({ id, from, to, request, atTick, isYou = false }) {
      if (to === leftAddress || to === rightAddress) {
        throw new Error(\`no queue behind the gateway at \${to}\`);
      }
      farNetwork(to).deliverToQueue({ id, from, to, request, atTick, isYou });
      routed += 1;
      lastRoute = { from, to, request };
    },
    handleRequest() { return '200 Router 20.1'; },  // gateway diagnostic
    snapshot() { return { leftAddress, rightAddress, routed, lastRoute }; },
  };
}`,
  },
};
