import { describe, it, expect } from 'vitest';
import { createEngine } from '../../js/sim/engine.js';
import { createRng } from '../../js/sim/rng.js';

describe('createRng', () => {
  it('is deterministic per seed and differs across seeds', () => {
    const a = Array.from({ length: 10 }, createRng(7));
    const b = Array.from({ length: 10 }, createRng(7));
    const c = Array.from({ length: 10 }, createRng(8));
    expect(a).toEqual(b);
    expect(a).not.toEqual(c);
    expect(a.every((v) => v >= 0 && v < 1)).toBe(true);
  });
});

describe('createEngine', () => {
  it('same seed replays the identical tick sequence', () => {
    const run = () => {
      const engine = createEngine({ seed: 7, users: 12, serviceRate: 4, arrivalProb: 0.6 });
      return Array.from({ length: 50 }, () => engine.step());
    };
    const first = run();
    const second = run();
    expect(first).toEqual(second);

    const other = createEngine({ seed: 8, users: 12, serviceRate: 4, arrivalProb: 0.6 });
    const otherRun = Array.from({ length: 50 }, () => other.step());
    expect(otherRun).not.toEqual(first);
  });

  it('advances exactly one tick per step and snapshots UI state', () => {
    const engine = createEngine({ seed: 1 });
    expect(engine.snapshot()).toMatchObject({ tick: 0, users: 5, queueDepth: 0, served: 0 });
    engine.step();
    expect(engine.snapshot().tick).toBe(1);
    engine.step();
    expect(engine.snapshot().tick).toBe(2);
    const snap = engine.snapshot();
    expect(typeof snap.avgLatencyTicks).toBe('number');
    expect(snap.avgLatencyTicks).toBeGreaterThanOrEqual(0);
  });

  it('setUsers changes the simulated user count', () => {
    const engine = createEngine({ seed: 1, users: 5 });
    engine.setUsers(30);
    expect(engine.snapshot().users).toBe(30);
  });

  it('rejects an arrivalProb outside [0, 1]', () => {
    expect(() => createEngine({ arrivalProb: 1.5 })).toThrow(/arrivalProb/);
  });

  it('stage 6 runs hosted traces through DNS 10.60 and keeps host-less paths at the Stage 5 shape', () => {
    const engine = createEngine({ stage: 6 });
    let snap = engine.snapshot();
    expect(snap.router).toEqual({
      leftAddress: '10.65',
      rightAddress: '20.1',
      routed: 0,
      lastRoute: null,
    });
    expect(snap.dns.address).toBe('10.60');

    // Hosted path: 10 hops — 2 DNS hops ride ahead of the Stage 5 story.
    for (let hop = 0; hop < 10; hop++) engine.traceHop({ path: 'example.com/about' });
    snap = engine.snapshot();
    expect(snap.trace.hop).toBe(10);
    expect(snap.trace.finalHop).toBe(10);
    expect(snap.trace.dnsStatus).toBe('OK');
    expect(snap.trace.dnsTarget).toBe('10.1');
    expect(snap.trace.dnsSource).toBe('authoritative');
    expect(snap.trace.targetServer).toBe('10.11');
    expect(snap.browserDisplay.body).toBe('This is the about page');

    // CHECKS: nope.example never emits a GET — the trace ends at hop 2/2
    // with the NX answer; no backend serves anything for it.
    const servedBefore = snap.servers.reduce((sum, s) => sum + s.served, 0);
    for (let hop = 0; hop < 2; hop++) engine.traceHop({ path: 'nope.example/about' });
    snap = engine.snapshot();
    expect(snap.trace.hop).toBe(2);
    expect(snap.trace.finalHop).toBe(2);
    expect(snap.trace.dnsStatus).toBe('NX');
    expect(snap.trace.targetServer).toBe(null);
    expect(snap.servers.reduce((sum, s) => sum + s.served, 0)).toBe(servedBefore);
    expect(snap.browserDisplay.request).toBe('ask nope.example');
    expect(snap.browserDisplay.body).toBe('no record for nope.example');

    // Host-less path: 8 hops, the Stage 5 story — no DNS consult at all.
    for (let hop = 0; hop < 8; hop++) engine.traceHop({ path: '/about' });
    snap = engine.snapshot();
    expect(snap.trace.hop).toBe(8);
    expect(snap.trace.finalHop).toBe(8);
    expect(snap.trace.host).toBe(null);
    expect(snap.trace.dnsStatus).toBe(null);
    expect(snap.browserDisplay.body).toBe('This is the about page');
    // Ledger total: one hosted consult + one NX consult; the host-less
    // path added nothing.
    expect(snap.dns).toMatchObject({ lookups: 2, cachedHits: 0, authoritative: 2 });

    // CHECKS: an out-of-range stage fails loud (7 is not a shipped stage).
    expect(() => createEngine({ stage: 7 })).toThrow(
      /stage must be 1, 2, 3, 4, 5, or 6, got 7/,
    );
  });
});
