import { describe, it, expect } from 'vitest';
import { createDns } from '../../js/sim/dns.js';
import { createEngine } from '../../js/sim/engine.js';

describe('createDns', () => {
  it('serves a cache hit inside ttlTicks with no authoritative consult, and an expired entry never answers from the ledger', () => {
    const dns = createDns({ address: '10.60', ttlTicks: 300 });

    // Cold ask: the authoritative table answers and arms the ledger at
    // expiresAtTick = 0 + 300.
    expect(dns.lookup('example.com', 0)).toEqual({
      status: 'OK',
      target: '10.1',
      source: 'authoritative',
    });

    // A hit inside the TTL increments cachedHits with NO authoritative
    // consult — the ledger answers by itself.
    expect(dns.lookup('example.com', 299)).toEqual({
      status: 'OK',
      target: '10.1',
      source: 'cache',
    });
    expect(dns.snapshot(299)).toMatchObject({ lookups: 2, cachedHits: 1, authoritative: 1 });

    // CHECKS: the tick the TTL names is the first tick the entry is gone —
    // tick 300 reaches expiresAtTick, the expired entry is evicted and the
    // resolver falls through to the authoritative table (never a stale
    // answer from the ledger, the pinned counter-example).
    expect(dns.lookup('example.com', 300)).toEqual({
      status: 'OK',
      target: '10.1',
      source: 'authoritative',
    });
    const snap = dns.snapshot(300);
    expect(snap).toMatchObject({ lookups: 3, cachedHits: 1, authoritative: 2 });
    expect(snap.cache).toEqual([
      {
        name: 'example.com',
        target: '10.1',
        cachedAtTick: 300,
        expiresAtTick: 600,
        ttlRemaining: 300,
      },
    ]);

    // CHECKS: the constructor rejects a non-mini-IP address and a
    // non-positive or non-integer ttlTicks (fail-loud over silent
    // mis-configuration).
    expect(() => createDns({ address: '1060' })).toThrow(/invalid mini-IP/);
    expect(() => createDns({ ttlTicks: 0 })).toThrow(/ttlTicks/);
    expect(() => createDns({ ttlTicks: 2.5 })).toThrow(/ttlTicks/);
  });

  it('answers NX for an unknown name without ever throwing at the DNS layer', () => {
    const dns = createDns();
    expect(dns.lookup('nope.example', 5)).toEqual({ status: 'NX' });
    const snap = dns.snapshot(5);
    // The table was consulted (authoritative +1) but nothing was cached.
    expect(snap).toMatchObject({ lookups: 1, cachedHits: 0, authoritative: 1 });
    expect(snap.cache).toEqual([]);
    expect(snap.lastLookup).toEqual({ name: 'nope.example', status: 'NX', atTick: 5 });
    // A second ask consults the table again — NX names never enter the ledger.
    expect(dns.lookup('nope.example', 6)).toEqual({ status: 'NX' });
    expect(dns.snapshot(6).authoritative).toBe(2);
  });

  it('stage 6 engine exposes DNS 10.60 and drives its ledger from the hosted trace', () => {
    const engine = createEngine({ stage: 6 });
    let snap = engine.snapshot();
    expect(snap.dns).not.toBe(null);
    expect(snap.dns.address).toBe('10.60');
    expect(snap.dns).toMatchObject({ lookups: 0, cachedHits: 0, authoritative: 0 });
    // Stages 1-5 expose no DNS at all.
    expect(createEngine({ stage: 5 }).snapshot().dns).toBe(null);

    // The hosted trace consults exactly once: ask + answer is one lookup.
    for (let hop = 0; hop < 10; hop++) engine.traceHop({ path: 'example.com/about' });
    snap = engine.snapshot();
    expect(snap.dns).toMatchObject({ lookups: 1, cachedHits: 0, authoritative: 1 });
    expect(snap.dns.cache.map((e) => `${e.name} -> ${e.target}`)).toEqual([
      'example.com -> 10.1',
    ]);

    // The second hosted trace rides the ledger: cachedHits +1, no consult.
    for (let hop = 0; hop < 10; hop++) engine.traceHop({ path: 'example.com/about' });
    snap = engine.snapshot();
    expect(snap.dns).toMatchObject({ lookups: 2, cachedHits: 1, authoritative: 1 });

    // A host-less path never touches the resolver.
    for (let hop = 0; hop < 8; hop++) engine.traceHop({ path: '/about' });
    expect(engine.snapshot().dns).toMatchObject({ lookups: 2, cachedHits: 1, authoritative: 1 });
  });
});
