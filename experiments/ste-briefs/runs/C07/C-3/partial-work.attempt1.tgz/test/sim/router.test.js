import { describe, it, expect } from 'vitest';
import { createNetwork } from '../../js/sim/network.js';
import { createRouter } from '../../js/sim/router.js';
import { createWebServer } from '../../js/sim/webserver.js';

describe('createRouter + cross-subnet network', () => {
  it('passes same-subnet sends through unchanged and takes exactly one router hop across subnets', () => {
    const router = createRouter({ leftAddress: '10.65', rightAddress: '20.1' });
    const net10 = createNetwork({ subnet: '10', router });
    const net20 = createNetwork({ subnet: '20', router });
    router.join(net10, net20);
    net10.registerServer('10.1', createWebServer({ address: '10.1' }));

    // Same-subnet send: byte-identical to the Stage 1 network contract.
    expect(net10.send({ from: '10.2', to: '10.1', request: 'GET /about' })).toEqual({
      from: '10.2',
      to: '10.1',
      request: 'GET /about',
      response: '200 This is the about page',
    });
    expect(router.snapshot().routed).toBe(0);

    // Cross-subnet: exactly one router hop; the gateway answers its own
    // right interface (nothing lives in subnet 20 in Stage 6a).
    expect(net10.send({ from: '10.2', to: '20.1', request: 'GET /' })).toEqual({
      from: '10.2',
      to: '20.1',
      request: 'GET /',
      response: '200 Router 20.1',
    });
    const snapshot = router.snapshot();
    expect(snapshot.routed).toBe(1);
    expect(snapshot.lastRoute).toEqual({ from: '10.2', to: '20.1', request: 'GET /' });

    // The second crossing increments again — one hop per frame.
    net10.send({ from: '10.2', to: '20.1', request: 'GET /' });
    expect(router.snapshot().routed).toBe(2);

    // CHECKS: the constructor rejects non-mini-IP interfaces and a router
    // whose two interfaces share one subnet (it would join nothing).
    expect(() => createRouter({ leftAddress: '1065' })).toThrow(/invalid mini-IP/);
    expect(() => createRouter({ rightAddress: '201' })).toThrow(/invalid mini-IP/);
    expect(() => createRouter({ leftAddress: '20.65', rightAddress: '20.1' })).toThrow(
      /distinct subnets/,
    );
  });

  it('fails loud on unregistered 20.x hosts before counting a router hop', () => {
    const router = createRouter();
    const net10 = createNetwork({ subnet: '10', router });
    const net20 = createNetwork({ subnet: '20', router });
    router.join(net10, net20);

    // DL-1 fail-loud: 20.9 throws from the far network's own resolve —
    // the named counter-example — and routed stays at 0.
    expect(() => net10.send({ from: '10.2', to: '20.9', request: 'GET /' })).toThrow(
      /no server at 20\.9/,
    );
    expect(router.snapshot().routed).toBe(0);
    expect(router.snapshot().lastRoute).toBe(null);

    // Without an attached router there is no route at all.
    expect(() =>
      createNetwork({ subnet: '10' }).send({ from: '10.2', to: '20.1', request: 'GET /' }),
    ).toThrow(/no route/);
    // And a subnet-less network (Stages 1-5) keeps today's exact behavior.
    const plain = createNetwork();
    plain.registerServer('10.1', createWebServer({ address: '10.1' }));
    expect(() => plain.send({ from: '10.2', to: '20.1', request: 'GET /' })).toThrow(
      /no server at 20\.1/,
    );
    expect(plain.send({ from: '10.2', to: '10.1', request: 'GET /' }).response).toBe(
      '200 Welcome to the home page',
    );
  });

  it('routes queue deliveries with isYou riding through untouched', () => {
    const router = createRouter();
    const net10 = createNetwork({ subnet: '10', router });
    const net20 = createNetwork({ subnet: '20', router });
    router.join(net10, net20);
    const far = createWebServer({ address: '20.5' });
    net20.registerServer('20.5', far);

    // The frame crosses once and enqueues on the far server; isYou rides.
    net10.deliverToQueue({
      id: 'you:3',
      from: '10.2',
      to: '20.5',
      request: 'GET /about',
      atTick: 3,
      isYou: true,
    });
    expect(router.snapshot().routed).toBe(1);
    expect(far.queueSnapshot()).toEqual([
      { id: 'you:3', from: '10.2', to: '20.5', request: 'GET /about', atTick: 3, isYou: true },
    ]);

    // The gateway itself has no queue behind it — fail loud, no hop.
    expect(() =>
      net10.deliverToQueue({
        id: 'you:4',
        from: '10.2',
        to: '20.1',
        request: 'GET /',
        atTick: 4,
        isYou: true,
      }),
    ).toThrow(/no queue behind the gateway at 20\.1/);
    expect(router.snapshot().routed).toBe(1);
  });
});
