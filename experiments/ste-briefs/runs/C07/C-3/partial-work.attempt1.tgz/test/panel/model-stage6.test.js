import { describe, it, expect } from 'vitest';
import { describeSnapshot } from '../../js/panel/model.js';
import { formatComponentState } from '../../js/panel/inspector-state.js';

// Stage-boundary narrative pins for Stage 6a (guard-file-size split, as
// with model-stage34/5): the trace narrative branches on the URL shape —
// host-less keeps the Stage 5 story byte-identical, hosted adds exactly
// two DNS hops, and an NX name never emits a GET.
const stage5Snap = {
  stage: 5,
  tick: 1,
  users: 5,
  serverAddress: '10.1',
  queueDepth: 0,
  served: 1,
  avgLatencyTicks: 1,
  workerQueue: {
    address: '10.40',
    workerAddress: '10.41',
    jobDurationTicks: 2,
    enqueued: 0,
    completed: 0,
    activeJob: null,
    pendingJobs: [],
    lastJobResult: null,
  },
  trace: {
    hop: 4,
    method: 'GET',
    path: '/about',
    request: 'GET /about',
    targetServer: '10.11',
    asyncJob: false,
    cacheStatus: 'MISS',
    dbOp: 'SELECT',
    dbStale: true,
    response: '200 This is the about page',
    status: 200,
    body: 'This is the about page',
    routeId: 'about',
    finalHop: 8,
  },
};

const stage6Snap = {
  ...stage5Snap,
  stage: 6,
  dns: {
    address: '10.60',
    ttlTicks: 300,
    lookups: 0,
    cachedHits: 0,
    authoritative: 0,
    lastLookup: null,
    cache: [],
  },
  router: { leftAddress: '10.65', rightAddress: '20.1', routed: 0, lastRoute: null },
};

const hopLabels = (snap, hop, over = {}) =>
  describeSnapshot({ ...snap, trace: { ...snap.trace, hop, ...over } }).hopStatus;

describe('Stage 6 trace narrative branches on the URL shape', () => {
  it('keeps GET /about on Stage 6 at the Stage 5 hop story byte-identical', () => {
    // The named counter-example: a host-less path carries no host, so no
    // DNS hop and no cross-subnet hop may appear — every sentence equals
    // Stage 5's verbatim, denominators included.
    for (let hop = 1; hop <= 8; hop++) {
      expect(hopLabels(stage6Snap, hop)).toBe(hopLabels(stage5Snap, hop));
    }
    expect(hopLabels(stage6Snap, 1)).toBe('Hop 1/8: Browser (10.2) emits "GET /about"');
    expect(hopLabels(stage6Snap, 8)).toBe(
      'Hop 8/8: Worker (10.41) idle — no async jobs in this trace',
    );
  });

  it('rides a hosted path exactly two DNS hops ahead of the Stage 5 story', () => {
    const hosted = {
      ...stage6Snap,
      trace: {
        ...stage6Snap.trace,
        path: '/about',
        request: 'GET /about',
        host: 'example.com',
        dnsStatus: 'OK',
        dnsTarget: '10.1',
        dnsSource: 'authoritative',
        finalHop: 10,
      },
    };
    expect(describeSnapshot(hosted).totalHops).toBe(10);
    expect(hopLabels(hosted, 1)).toBe(
      'Hop 1/10: Browser (10.2) asks DNS (10.60) for "example.com"',
    );
    expect(hopLabels(hosted, 2)).toBe(
      'Hop 2/10: DNS (10.60) -> example.com is 10.1 (authoritative)',
    );
    // The Stage 5 story continues at hop 3, renumbered /10, and ends at
    // hop 10/10 — the two DNS hops are the only additions.
    expect(hopLabels(hosted, 3)).toBe('Hop 3/10: Browser (10.2) emits "GET /about"');
    expect(hopLabels(hosted, 6)).toBe(
      'Hop 6/10: Database SELECT @ Replica (10.31) — STALE (lag 3t)',
    );
    expect(hopLabels(hosted, 10)).toBe(
      'Hop 10/10: Worker (10.41) idle — no async jobs in this trace',
    );
    for (let k = 1; k <= 8; k++) {
      expect(hopLabels(hosted, k + 2)).toBe(
        hopLabels(stage5Snap, k).replace(/^Hop \d\/8:/, `Hop ${k + 2}/10:`),
      );
    }
  });

  it('ends the NX path at hop 2/2 — DNS ask plus NX answer, never a GET', () => {
    const nx = {
      ...stage6Snap,
      trace: {
        ...stage6Snap.trace,
        host: 'nope.example',
        dnsStatus: 'NX',
        dnsTarget: null,
        dnsSource: null,
        finalHop: 2,
      },
    };
    expect(hopLabels(nx, 1)).toBe(
      'Hop 1/2: Browser (10.2) asks DNS (10.60) for "nope.example"',
    );
    expect(hopLabels(nx, 2)).toBe(
      'Hop 2/2: DNS (10.60) -> NX no record for nope.example — browser renders no record',
    );
    // The two-hop story never mentions the GET or a server hop: the whole
    // serialized sentence list leaves "emits" out.
    const sentences = JSON.stringify(describeSnapshot(nx));
    expect(sentences).not.toContain('emits');
    expect(sentences).not.toContain('LoadBalancer');
  });

  it('exposes the DNS ledger and the Router as inspector state and network interfaces', () => {
    const snap = {
      ...stage6Snap,
      dns: {
        address: '10.60',
        ttlTicks: 300,
        lookups: 2,
        cachedHits: 1,
        authoritative: 1,
        lastLookup: { name: 'example.com', status: 'HIT', atTick: 5, target: '10.1' },
        cache: [
          {
            name: 'example.com',
            target: '10.1',
            cachedAtTick: 0,
            expiresAtTick: 300,
            ttlRemaining: 295,
          },
        ],
      },
      router: {
        leftAddress: '10.65',
        rightAddress: '20.1',
        routed: 1,
        lastRoute: { from: '10.2', to: '20.1', request: 'GET /' },
      },
    };
    expect(describeSnapshot(snap).dnsStatsLabel).toBe(
      'Lookups: 2 · Cached hits: 1 · Authoritative: 1',
    );
    expect(describeSnapshot(snap).dnsEntries).toEqual(snap.dns.cache);
    expect(describeSnapshot(snap).routerStatsLabel).toBe('Routed: 1');
    expect(describeSnapshot(snap).routerLastRoute).toBe('10.2 -> 20.1 GET /');
    const dnsState = JSON.parse(formatComponentState(snap, 'dns'));
    expect(dnsState).toEqual({ ...snap.dns });
    const routerState = JSON.parse(formatComponentState(snap, 'router'));
    expect(routerState).toEqual({ ...snap.router });
    // The network table names DNS 10.60 and both Router interfaces.
    const networkState = JSON.parse(formatComponentState(snap, 'network'));
    expect(networkState.interfaces['10.60']).toBe('DNS');
    expect(networkState.interfaces['10.65']).toBe('Router (10.x side)');
    expect(networkState.interfaces['20.1']).toBe('Router (20.x gateway)');
  });
});
