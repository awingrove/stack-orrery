import { test, expect } from '@playwright/test';

// Stage 6a — DNS 10.60 (tick-TTL ledger) + cross-subnet Router on its own
// spec (guard-file-size: panel.spec.js sits at its cap). Titles are the
// manifest pins (SIM-6 / PANEL-6): do not reword. The sim runs from a fixed
// seed, so every hop sequence below is identical on every run.
test('should switch to Stage 6, resolve example.com through DNS 10.60, and inspect DNS code + TTL ledger', async ({
  page,
}) => {
  await page.goto('/panel.html');

  await page.getByTestId('stage-pill-6').click();
  await expect(page.getByTestId('stage-pill-6')).toHaveAttribute('aria-current', 'true');
  await expect(page.getByTestId('node-dns')).toBeVisible();
  await expect(page.getByTestId('node-router')).toBeVisible();
  await expect(page.locator('.orrery-ring')).toHaveCount(8);
  await expect(page.locator('.orrery-ring').first()).toHaveAttribute('r', '400');
  await expect(page.locator('.orrery-ring').last()).toHaveAttribute('r', '3200');
  await expect(page.getByTestId('dns-stats')).toHaveText(
    'Lookups: 0 · Cached hits: 0 · Authoritative: 0',
  );
  await expect(page.getByTestId('router-stats')).toHaveText('Routed: 0');

  // First hosted trace: the resolver consults the authoritative table once
  // and warms the ledger (example.com -> 10.1).
  await page.getByTestId('url-input').fill('example.com/about');
  await page.getByTestId('btn-url-go').click();
  await expect(page.getByTestId('dns-stats')).toHaveText(
    'Lookups: 1 · Cached hits: 0 · Authoritative: 1',
  );
  await expect(page.getByTestId('dns-entries-list')).toContainText('example.com -> 10.1');
  await expect(page.getByTestId('browser-rendered-body')).toHaveText('This is the about page');

  // Second hosted trace: the ledger answers inside the TTL — cachedHits +1,
  // no authoritative consult.
  await page.getByTestId('btn-url-go').click();
  await expect(page.getByTestId('dns-stats')).toHaveText(
    'Lookups: 2 · Cached hits: 1 · Authoritative: 1',
  );

  // The resolver's code and live ledger state open in the inspector.
  await page.getByTestId('node-dns').click();
  await expect(page.getByTestId('inspector-code')).toContainText('createDns');
  await expect(page.getByTestId('inspector-state')).toContainText('"ttlTicks": 300');
  await expect(page.getByTestId('inspector-state')).toContainText('"cachedHits": 1');
  await expect(page.getByTestId('inspector-title')).toHaveText('DNS — mini-IP 10.60');
});

test('should trace example.com/about with DNS ask + answer hops', async ({ page }) => {
  await page.goto('/panel.html?stage=6');

  await expect(page.getByTestId('node-dns')).toBeVisible();
  await page.getByTestId('url-input').fill('example.com/about');

  // Hops 1-2/10: the browser asks DNS 10.60 and the resolver answers —
  // before any GET moves (the wire consumes the resolver's actual answer).
  await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toHaveText(
    'Hop 1/10: Browser (10.2) asks DNS (10.60) for "example.com"',
  );
  await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toHaveText(
    'Hop 2/10: DNS (10.60) -> example.com is 10.1 (authoritative)',
  );

  // Hop 3/10: only now the resolved GET is emitted toward 10.1.
  await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toHaveText(
    'Hop 3/10: Browser (10.2) emits "GET /about"',
  );

  // Hops 4-10/10: the Stage 5 journey lands the response.
  for (let hop = 0; hop < 7; hop++) await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toHaveText(
    'Hop 10/10: Worker (10.41) idle — no async jobs in this trace',
  );
  await expect(page.getByTestId('browser-rendered-body')).toHaveText('This is the about page');
  await expect(page.getByTestId('dns-stats')).toHaveText(
    'Lookups: 1 · Cached hits: 0 · Authoritative: 1',
  );
});

test('should keep GET /about on Stage 6 at the Stage 5 hop story', async ({ page }) => {
  // The named counter-example: a host-less path never touches DNS or the
  // router — its 8-hop story is byte-identical to Stage 5's, denominators
  // included, and the resolver's counters stay at zero.
  await page.goto('/panel.html?stage=6');

  await page.getByTestId('url-input').fill('/about');
  await expect(page.getByTestId('dns-stats')).toHaveText(
    'Lookups: 0 · Cached hits: 0 · Authoritative: 0',
  );
  for (let hop = 0; hop < 8; hop++) await page.getByTestId('btn-next-hop').click();

  await expect(page.getByTestId('hop-status')).toHaveText(
    'Hop 1/8: Browser (10.2) emits "GET /about"',
  );
  // Read the whole journey log: every label reads hop N/8 in ascending
  // order — no /10 renumbering and no DNS ask entry anywhere.
  const labels = await page.getByTestId('journey-log').locator('.journey-entry').allTextContents();
  const hopRows = labels
    .map((text) => text.match(/^(hop \d\/\d)/)?.[1])
    .filter(Boolean)
    .slice(0, 8);
  expect(hopRows).toEqual([
    'hop 1/8',
    'hop 2/8',
    'hop 3/8',
    'hop 4/8',
    'hop 5/8',
    'hop 6/8',
    'hop 7/8',
    'hop 8/8',
  ]);
  await expect(page.getByTestId('dns-stats')).toHaveText(
    'Lookups: 0 · Cached hits: 0 · Authoritative: 0',
  );
  await expect(page.getByTestId('browser-rendered-body')).toHaveText('This is the about page');
});

// Negative-case pin: an unknown name never emits a GET — the trace ends at
// the DNS answer and the browser renders the NX card.
test('should render the NX card for nope.example without emitting a GET', async ({ page }) => {
  await page.goto('/panel.html?stage=6');

  await page.getByTestId('url-input').fill('nope.example/about');
  await page.getByTestId('btn-url-go').click();
  await expect(page.getByTestId('hop-status')).toHaveText(
    'Hop 2/2: DNS (10.60) -> NX no record for nope.example — browser renders no record',
  );
  await expect(page.getByTestId('browser-rendered-body')).toHaveText(
    'no record for nope.example',
  );
  await expect(page.getByTestId('browser-status-badge')).toContainText('NX (ask nope.example)');
  await expect(page.getByTestId('dns-stats')).toHaveText(
    'Lookups: 1 · Cached hits: 0 · Authoritative: 1',
  );
  // No GET ever reached the backends: both queues stay empty.
  await expect(page.getByTestId('server-queue-list')).toContainText('queue empty');
});

// The ?stage= live set extends to 6 with stage-pill-6; unknown values still
// fall back to 1 (the fallback itself is pinned in panel.spec.js ?stage=9).
test('should deep-link ?stage=6 to the live stage with DNS and router cards', async ({
  page,
}) => {
  await page.goto('/panel.html?stage=6&users=7');
  await expect(page.getByTestId('stage-pill-6')).toHaveAttribute('aria-current', 'true');
  await expect(page.getByTestId('node-dns')).toBeVisible();
  await expect(page.getByTestId('node-router')).toBeVisible();
  await expect(page.getByTestId('user-dots').locator('> *')).toHaveCount(7);
  // Clicking the router opens its code and routed counter in the inspector.
  await page.getByTestId('node-router').click();
  await expect(page.getByTestId('inspector-code')).toContainText('createRouter');
  await expect(page.getByTestId('inspector-state')).toContainText('"routed": 0');
  await expect(page.getByTestId('inspector-title')).toHaveText('Router — 10.65 ⇄ 20.1');
});
