// DOCUMENTS: the single-request hop-by-hop state machine behind the panel's
// "Step 1 Hop ->" trace — one hop per call, running across the same
// network/LB/queue/cache machinery the crowd uses (it does not fake a
// shortcut). 4 hops in Stage 1 (emit, route, serve, render); 5 in Stage 2
// (the LB's round-robin pick becomes its own hop); 6 in Stage 3 (the
// backend's cache-aside lookup and the HTTP response emission split into
// two hops); 7 in Stage 4 (the database hop); 8 in Stage 5 (the async
// worker-queue story). Stage 6 branches on host syntax: a host-less path
// keeps the Stage 5 8-hop story byte-identical, a hosted path
// (`example.com/about`) inserts exactly two DNS hops (ask + answer) for 10
// hops total, and an unknown name ends the trace at the browser's NX render
// after 4 hops with no GET emitted (see trace-late.js).
//
// The machine owns the trace state and hop transitions; the engine owns
// the clock, the served-exchange record, and browser delivery, handed in
// as the callbacks below. Stage 5 and Stage 6 hop handlers live in
// trace-late.js (split by responsibility, guard-file-size).
//
// CHECKS: an out-of-range stage fails loud at construction instead of
// building a trace that can never advance.
import { createLateHops } from './trace-late.js';
import { hasHost, hostOf } from './host-path.js';

export function createTraceMachine({
  stage,
  serverAddress,
  servers,
  lb = null,
  network,
  cache = null,
  database = null,
  workerQueue = null,
  dns = null,
  bumpTick,
  getTick,
  onServe,
  onFinish,
}) {
  if (stage !== 1 && stage !== 2 && stage !== 3 && stage !== 4 && stage !== 5 && stage !== 6) {
    throw new Error(`trace: stage must be 1, 2, 3, 4, 5, or 6, got ${stage}`);
  }
  let trace = freshTrace();

  function freshTrace() {
    return {
      hop: 0,
      method: 'GET',
      path: '/about',
      from: '10.2',
      request: 'GET /about',
      wireRequest: 'GET /about',
      routePath: '/about',
      host: null,
      dnsAnswer: null,
      targetServer: null,
      cacheStatus: null,
      dbOp: null,
      dbStale: false,
      asyncJob: false,
      response: null,
      status: null,
      body: null,
      routeId: null,
      finished: false,
      held: null,
    };
  }

  // Serve from the front of the target's queue until the trace's own
  // request (isYou) comes back, or the queue runs dry this tick.
  function drainUntilYou(targetServer) {
    for (;;) {
      const batch = targetServer.step(getTick());
      const you = batch.find((item) => item.isYou);
      if (you || batch.length === 0) return you;
    }
  }

  function backendFor(targetAddress) {
    return servers.find((s) => s.address === targetAddress) ?? servers[0];
  }

  function serve(you) {
    trace.response = you.response;
    trace.status = you.status;
    trace.body = you.body;
    trace.routeId = you.routeId;
    onServe(you);
  }

  // Final hop: the rendered response lands on the browser the trace
  // originated from (the engine routes it into the right browser state).
  // The record carries the wire request — for a Stage 6 hosted run that is
  // the resolved host-less path, never the dotted URL.
  function finish(toAddress) {
    onFinish({
      from: trace.from ?? '10.2',
      to: toAddress,
      request: trace.wireRequest ?? trace.request,
      response: trace.response,
    });
  }

  const late = createLateHops({
    serverAddress,
    lb,
    cache,
    database,
    workerQueue,
    dns,
    bumpTick,
    getTick,
    onFinish,
    drainUntilYou,
    backendFor,
    serve,
    finish,
  });

  return {
    // One hop per call. Returns the hop's lastFrame string, or null when
    // nothing moved (the engine keeps its previous frame then).
    step({ method = 'GET', path = '/about', from = '10.2' } = {}) {
      // The final hop is the run's own shape: a Stage 6 hosted run is 10
      // hops (2 DNS hops inserted), a host-less Stage 6 run is the Stage 5
      // 8-hop story byte-identical.
      const hostedRun = stage === 6 && trace.host !== null;
      const finalHop =
        stage === 6
          ? hostedRun
            ? 10
            : 8
          : stage === 5
            ? 8
            : stage === 4
              ? 7
              : stage === 3
                ? 6
                : stage === 2
                  ? 5
                  : 4;
      let frame = null;
      if (trace.hop === 0 || trace.finished || trace.hop >= finalHop) {
        Object.assign(trace, freshTrace());
        trace.hop = 1;
        trace.method = method;
        trace.path = path;
        trace.from = from;
        trace.request = `${method} ${path}`;
        // Stage 6 records the run's host syntax once: a dotted host before
        // the first `/` makes the trace hosted; plain paths stay host-less.
        trace.host = stage === 6 && hasHost(path) ? hostOf(path) : null;
        // The wire speaks the host-less path: the browser resolves the host
        // through DNS first, then emits `GET /about` with the resolved
        // target — `routePath` (and the wireRequest built from it) is what
        // the queue, the server routes, and the browser record actually see.
        trace.routePath =
          trace.host !== null ? trace.path.slice(trace.host.length) || '/' : trace.path;
        trace.wireRequest = `${method} ${trace.routePath}`;
        trace.targetServer = stage === 1 ? serverAddress : null;
        frame = `${from} -> ${serverAddress} | ${trace.request}`;
        return frame;
      }
      // Stage 6 hosted: the DNS ask/answer hops own hops 2-3, then the
      // Stage 5 chain runs shifted; NX ends the run at the browser render.
      if (hostedRun) return late.hostedStep(trace);
      if (stage === 1 && trace.hop === 1) {
        trace.hop = 2;
        const atTick = bumpTick();
        network.deliverToQueue({
          id: `you:${atTick}`,
          from: trace.from,
          to: serverAddress,
          request: trace.request,
          atTick,
          isYou: true,
        });
        frame = `routed ${trace.from} -> ${serverAddress} (${trace.request}) into queue`;
      } else if (stage === 1 && trace.hop === 2) {
        trace.hop = 3;
        const you = drainUntilYou(servers[0]);
        if (you) {
          serve(you);
          frame = `${serverAddress} -> ${trace.from} | ${you.response}`;
        }
      } else if (stage === 1 && trace.hop === 3) {
        trace.hop = 4;
        finish(serverAddress);
      } else if (trace.hop === 1) {
        trace.hop = 2;
        frame = `routed ${trace.from} -> ${serverAddress} (${trace.request}) to LoadBalancer`;
      } else if (trace.hop === 2) {
        trace.hop = 3;
        const atTick = bumpTick();
        const target = lb.enqueue({
          id: `you:${atTick}`,
          from: trace.from,
          to: serverAddress,
          request: trace.request,
          atTick,
          isYou: true,
        });
        trace.targetServer = target;
        frame = `LB ${serverAddress} -> ${target} (${trace.request}) queued`;
      } else if (stage === 5 || (stage === 6 && trace.host === null)) {
        return late.stage5Step(trace);
      } else if (stage === 2 && trace.hop === 3) {
        trace.hop = 4;
        const backend = backendFor(trace.targetServer);
        const you = drainUntilYou(backend);
        if (you) {
          serve(you);
          frame = `${backend.address} -> ${trace.from} | ${you.response}`;
        }
      } else if (stage === 2 && trace.hop === 4) {
        trace.hop = 5;
        finish(trace.targetServer ?? serverAddress);
      } else if (stage === 3 && trace.hop === 3) {
        // Hop 4/6: the target backend checks Cache and serves the queued
        // request; the response record is held one hop so the learner sees
        // the cache lookup before the response leaves the backend.
        trace.hop = 4;
        const backend = backendFor(trace.targetServer);
        trace.held = drainUntilYou(backend);
        if (trace.held) {
          trace.cacheStatus = trace.held.cacheStatus ?? null;
          frame = `${backend.address} -> ${cache.address} | cache ${trace.cacheStatus} (${trace.path})`;
        }
      } else if (stage === 3 && trace.hop === 4) {
        trace.hop = 5;
        if (trace.held) {
          serve(trace.held);
          frame = `${trace.targetServer} -> ${trace.from} | ${trace.held.response} (${trace.cacheStatus})`;
        }
      } else if (stage === 3 && trace.hop === 5) {
        trace.hop = 6;
        finish(trace.targetServer ?? serverAddress);
      } else if (stage === 4 && trace.hop === 3) {
        // Hop 4/7: the target backend checks Cache and serves the queued
        // request (a POST write-through carries cacheStatus INVALIDATE);
        // the response record is held so the learner watches the cache
        // lookup, then the database hop.
        trace.hop = 4;
        const backend = backendFor(trace.targetServer);
        trace.held = drainUntilYou(backend);
        if (trace.held) {
          trace.cacheStatus = trace.held.cacheStatus ?? null;
          frame = `${backend.address} -> ${cache.address} | cache ${trace.cacheStatus} (${trace.path})`;
        }
      } else if (stage === 4 && trace.hop === 4) {
        // Hop 5/7: the database hop — hop 6's WRITE landed on Primary
        // 10.30 (replication queued toward 10.31), hop 5's SELECT read
        // Replica 10.31 fresh or stale, and a warm cache HIT skips the
        // database entirely.
        trace.hop = 5;
        if (trace.held) {
          trace.dbOp = trace.held.dbOp ?? null;
          trace.dbStale = Boolean(trace.held.dbStale);
          if (trace.dbOp === 'WRITE') {
            frame = `Database WRITE ${trace.path} @ ${database.primaryAddress} (replica ${database.replicaAddress} lags ${database.replicationLagTicks}t)`;
          } else if (trace.dbOp === 'SELECT') {
            frame = `Database SELECT ${trace.path} @ ${database.replicaAddress} (${trace.dbStale ? 'STALE' : 'fresh'})`;
          } else {
            frame = `Database SKIP ${trace.path} (warm cache HIT @ ${cache.address})`;
          }
        }
      } else if (stage === 4 && trace.hop === 5) {
        trace.hop = 6;
        if (trace.held) {
          serve(trace.held);
          frame = `${trace.targetServer} -> ${trace.from} | ${trace.held.response} (cache ${trace.cacheStatus})`;
        }
      } else if (stage === 4 && trace.hop === 6) {
        trace.hop = 7;
        finish(trace.targetServer ?? serverAddress);
      }
      return frame;
    },

    snapshot() {
      // The held queue record is plumbing between hops, not UI state.
      const { held, ...publicTrace } = trace;
      return { ...publicTrace };
    },
  };
}
