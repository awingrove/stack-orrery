// DOCUMENTS: the Stage 6 component — a cross-subnet Router with one
// interface per subnet (leftAddress on the 10.x side, rightAddress on the
// 20.x side). It joins the two Network instances via attach(); any frame
// whose source and destination sit on different subnets takes exactly one
// router hop (routed increments) and is delivered into the exit network.
// `isYou` and the rest of the frame ride through untouched.
//
// CHECKS: the constructor rejects an interface that is not a two-number
// mini-IP and two interfaces on the same subnet; forwarding without both
// networks attached, routing into a third subnet, or a frame that stays on
// the caller's own subnet fail loud.
const MINI_IP = /^\d+\.\d+$/;

export function createRouter({ leftAddress = '10.65', rightAddress = '20.1' } = {}) {
  if (!MINI_IP.test(leftAddress) || !MINI_IP.test(rightAddress)) {
    throw new Error(`router: invalid mini-IP interface ${leftAddress} / ${rightAddress}`);
  }
  const subnetOf = (addr) => String(addr).split('.')[0];
  const leftSubnet = subnetOf(leftAddress);
  const rightSubnet = subnetOf(rightAddress);
  if (leftSubnet === rightSubnet) {
    throw new Error(
      `router: both interfaces sit on subnet ${leftSubnet} — two different subnets required`,
    );
  }
  let leftNetwork = null;
  let rightNetwork = null;
  let routed = 0;
  let lastFrame = null;

  function exitFor(frame) {
    if (!leftNetwork || !rightNetwork) {
      throw new Error('router: no networks attached — call attach(left, right) first');
    }
    const fromSubnet = subnetOf(frame.from);
    const toSubnet = subnetOf(frame.to);
    if (fromSubnet === leftSubnet && toSubnet === rightSubnet) return rightNetwork;
    if (fromSubnet === rightSubnet && toSubnet === leftSubnet) return leftNetwork;
    throw new Error(
      `router: no route from subnet ${fromSubnet}.x to subnet ${toSubnet}.x (interfaces ${leftAddress} ⇄ ${rightAddress})`,
    );
  }

  function markRouted(frame) {
    routed += 1;
    lastFrame = `router ${leftAddress} ⇄ ${rightAddress} forwarded ${frame.from} -> ${frame.to} (${frame.request})`;
  }

  return {
    get leftAddress() {
      return leftAddress;
    },
    get rightAddress() {
      return rightAddress;
    },
    get routed() {
      return routed;
    },

    // Joins the two subnet networks; the networks' own subnets must match
    // the router's interfaces or the topology is miswired — fail loud.
    attach(left, right) {
      if (!left || !right) {
        throw new Error('router: attach needs both subnet networks');
      }
      if (left.subnet !== leftSubnet || right.subnet !== rightSubnet) {
        throw new Error(
          `router: attached networks must be subnets ${leftSubnet} and ${rightSubnet}`,
        );
      }
      leftNetwork = left;
      rightNetwork = right;
    },

    // A synchronous cross-subnet request: one router hop, then the exit
    // network delivers locally. routed counts completed forwards only.
    forward(frame) {
      const exit = exitFor(frame);
      const response = exit.receiveRouted(frame);
      markRouted(frame);
      return response;
    },

    // A queued cross-subnet request: one router hop into the exit network's
    // queue (used by the LB/enqueue path the same way).
    forwardQueue(frame) {
      const exit = exitFor(frame);
      exit.enqueueRouted(frame);
      markRouted(frame);
    },

    snapshot() {
      return { leftAddress, rightAddress, routed, lastFrame };
    },
  };
}
