// DOCUMENTS: the network — the wiring that lets two-number mini-IP
// addressable components exchange messages. Today it carries slim HTTP
// requests to a registered server; later stages attach more components
// without changing the send/enqueue contract.
//
// Stage 6: a network instance belongs to one subnet (createNetwork's
// `subnet`). When a cross-subnet Router is attached and a frame's source
// and destination sit on different subnets, the frame takes exactly one
// router hop into the exit network; same-subnet sends keep today's
// send/deliverToQueue contract untouched.
//
// CHECKS: every address crossing the wire is validated as a two-number
// mini-IP (<net>.<host>), and sends to unregistered hosts fail loud —
// including hosts inside the far subnet (the Router hands the frame to the
// exit network, whose resolve throws the same way).
const MINI_IP = /^\d+\.\d+$/;

export function createNetwork({ subnet = '10' } = {}) {
  if (!/^\d+$/.test(String(subnet))) {
    throw new Error(`network: invalid subnet ${subnet}`);
  }
  const servers = new Map();
  let router = null;

  function validate(addr) {
    if (!MINI_IP.test(addr)) {
      throw new Error(`network: invalid mini-IP address ${addr}`);
    }
  }

  function subnetOf(addr) {
    validate(addr);
    return String(addr).split('.')[0];
  }

  function resolve(address) {
    validate(address);
    const server = servers.get(address);
    if (!server) {
      throw new Error(`network: no server at ${address}`);
    }
    return server;
  }

  function deliverLocal({ from, to, request }) {
    const response = resolve(to).handleRequest(request);
    return { from, to, request, response };
  }

  function enqueueLocal(frame) {
    resolve(frame.to).enqueue(frame);
  }

  // The cross-subnet branch fires only when a router is attached and the
  // frame leaves this subnet; anything else is a local delivery.
  function routerFor({ from, to }) {
    if (!router) return null;
    if (subnetOf(from) !== subnet || subnetOf(to) === subnet) return null;
    return router;
  }

  return {
    registerServer(address, server) {
      validate(address);
      servers.set(address, server);
    },

    resolve,

    get subnet() {
      return subnet;
    },

    // Attaches the cross-subnet Router; the router must hold an interface
    // on this network's own subnet or the wiring is wrong — fail loud.
    attachRouter(attached) {
      if (subnetOf(attached.leftAddress) !== subnet && subnetOf(attached.rightAddress) !== subnet) {
        throw new Error(`network: router has no interface on subnet ${subnet}`);
      }
      router = attached;
    },

    // Router-side entry: a frame has arrived at this subnet's border from
    // the attached Router — deliver locally without consulting the Router
    // again (the router hop already happened).
    receiveRouted(frame) {
      validate(frame.from);
      return deliverLocal(frame);
    },

    enqueueRouted(frame) {
      validate(frame.from);
      enqueueLocal(frame);
    },

    send({ from, to, request }) {
      validate(from);
      const via = routerFor({ from, to });
      if (via) return via.forward({ from, to, request });
      return deliverLocal({ from, to, request });
    },

    // `isYou` rides through untouched: the engine marks the learner's own
    // interactive-browser request, the server stores it on the queue row.
    deliverToQueue({ id, from, to, request, atTick, isYou = false }) {
      validate(from);
      const via = routerFor({ from, to });
      if (via) {
        via.forwardQueue({ id, from, to, request, atTick, isYou });
        return;
      }
      enqueueLocal({ id, from, to, request, atTick, isYou });
    },
  };
}
