// DOCUMENTS: the shared host/path grammar for Stage 6 — a browser path
// either starts with `/` (host-less: `/about`) or names a dotted host
// before the first `/` (`example.com/about`). Every consumer of the host
// branch (trace.js, model.js sentences, panel hop counts) reads the same
// two functions so the narrative and the engine cannot drift apart.
//
// CHECKS: `hasHost` treats a path as host-less exactly when it starts with
// `/` (named counter-example: `/about` never reaches DNS), and `hostOf`
// splits on the first `/` — a host with no slash resolves for the root
// path `/`.
export function hasHost(path = '') {
  return String(path).startsWith('/') ? false : String(path).includes('.');
}

export function hostOf(path = '') {
  const raw = String(path);
  const slashAt = raw.indexOf('/');
  return slashAt === -1 ? raw : raw.slice(0, slashAt);
}
