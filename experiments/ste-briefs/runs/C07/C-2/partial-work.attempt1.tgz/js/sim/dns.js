// DOCUMENTS: the Stage 6 component — an authoritative name table
// (example.com -> 10.1) fronted by a resolver cache with tick-based TTL,
// mirroring the Cache 10.20 ledger pattern. It is a real Map lookup on the
// request path, not a hit probability: entries carry
// cachedAtTick/expiresAtTick, an expired entry is dropped before it can
// answer, and lookups/cachedHits/misses/nx counters record what actually
// happened. Deterministic by construction: time arrives as the
// `currentTick` argument, never a clock.
//
// CHECKS: the constructor rejects an address that is not a two-number
// mini-IP and a ttlTicks that is not a positive integer (fail-loud over
// silent mis-configuration).
const MINI_IP = /^\d+\.\d+$/;

export function createDns({ address = '10.60', ttlTicks = 300 } = {}) {
  if (!MINI_IP.test(address)) {
    throw new Error(`dns: invalid mini-IP address ${address}`);
  }
  if (!Number.isInteger(ttlTicks) || ttlTicks < 1) {
    throw new Error(`dns: ttlTicks must be a positive integer, got ${ttlTicks}`);
  }
  // Stage 6a authoritative table: the LoadBalancer VIP answers for
  // example.com; Stage 6b adds the CDN edge name on subnet 20.
  const authoritative = new Map([['example.com', '10.1']]);
  const cache = new Map(); // name -> { name, target, cachedAtTick, expiresAtTick }
  let lookups = 0;
  let cachedHits = 0;
  let misses = 0;
  let nx = 0;
  let evictions = 0;
  let lastLookup = null;

  // An entry dies the moment the current tick reaches its expiry: cached at
  // tick T with ttlTicks = 300 means alive through tick T + 299.
  function evictExpired(currentTick = 0) {
    for (const entry of cache.values()) {
      if (currentTick >= entry.expiresAtTick) {
        cache.delete(entry.name);
        evictions += 1;
      }
    }
  }

  // CHECKS: a ledger HIT inside ttlTicks answers from the cache alone —
  // cachedHits increments and the authoritative table is not consulted.
  // A miss OR an expired entry consults the authoritative table; an expired
  // entry is dropped first, so it cannot answer from the ledger.
  function lookup(name, currentTick = 0) {
    lookups += 1;
    evictExpired(currentTick);
    const entry = cache.get(name);
    if (entry) {
      cachedHits += 1;
      lastLookup = { name, status: 'HIT', target: entry.target, atTick: currentTick };
      return { name, status: 'HIT', target: entry.target, source: address };
    }
    const target = authoritative.get(name) ?? null;
    if (target === null) {
      // Unknown names never throw at the DNS layer: the browser renders the
      // NX answer; the fail-loud throw rule belongs to unregistered hosts.
      nx += 1;
      lastLookup = { name, status: 'NX', target: null, atTick: currentTick };
      return { name, status: 'NX', target: null, source: address };
    }
    misses += 1;
    cache.set(name, {
      name,
      target,
      cachedAtTick: currentTick,
      expiresAtTick: currentTick + ttlTicks,
    });
    lastLookup = { name, status: 'MISS', target, atTick: currentTick };
    return { name, status: 'MISS', target, source: address };
  }

  function snapshot(currentTick = 0) {
    evictExpired(currentTick);
    return {
      address,
      ttlTicks,
      lookups,
      cachedHits,
      misses,
      nx,
      evictions,
      lastLookup,
      authoritative: Object.fromEntries(authoritative),
      cache: [...cache.values()].map((e) => ({
        name: e.name,
        target: e.target,
        cachedAtTick: e.cachedAtTick,
        expiresAtTick: e.expiresAtTick,
        ttlRemaining: e.expiresAtTick - currentTick,
      })),
    };
  }

  return {
    get address() {
      return address;
    },
    evictExpired,
    lookup,
    snapshot,
  };
}
