// DOCUMENTS: the late-stage hop handlers for the trace machine — Stage 5's
// 8-hop async queue story and Stage 6's hosted DNS story, split from
// trace.js by responsibility (guard-file-size). The handlers consume the
// sim components' actual messages: the drained queue record (cache status,
// dbOp, asyncJob), the LoadBalancer's round-robin pick, and the DNS
// component's lookup answer — never a hardcoded story.
//
// Branch conditions (DL-3/DL-4):
// - Stage 6 hosted trace: the browser path carries a host
//   (`example.com/about`), so hops 2-3 are the DNS ask and answer; the NX
//   branch ends the trace at the browser's NX render with no GET emitted.
// - Stage 6 host-less trace: trace.js runs the Stage 5 handlers below
//   unchanged, keeping the Stage 5 hop story byte-identical (no DNS hop).
export function createLateHops({
  serverAddress,
  lb,
  cache,
  database,
  workerQueue,
  dns,
  bumpTick,
  getTick,
  onFinish,
  drainUntilYou,
  backendFor,
  serve,
  finish,
}) {
  // Stage 5's hop 3..7 branches, one per call, ending at hop 8. A queued
  // POST /jobs narrates its own async story; everything else narrates the
  // cache/database hop it actually took.
  function stage5Step(trace) {
    let frame = null;
    if (trace.hop === 3) {
      // Hop 4/8: an async POST /jobs enqueues to WorkerQueue 10.40; other
      // requests narrate the cache/database hop they actually took (the
      // Stage 4 story) — no phantom async jobs on GET traces (DL-4).
      trace.hop = 4;
      const backend = backendFor(trace.targetServer);
      trace.held = drainUntilYou(backend);
      if (trace.held) {
        trace.cacheStatus = trace.held.cacheStatus ?? null;
        trace.dbOp = trace.held.dbOp ?? null;
        trace.dbStale = Boolean(trace.held.dbStale);
        trace.asyncJob = Boolean(trace.held.asyncJob);
        if (trace.asyncJob) {
          frame = `${backend.address} -> ${workerQueue ? workerQueue.address : '10.40'} | enqueued async job (${trace.routePath ?? trace.path})`;
        } else if (trace.dbOp === 'WRITE') {
          frame = `Database WRITE ${trace.routePath ?? trace.path} @ ${database.primaryAddress} (replica ${database.replicaAddress} lags ${database.replicationLagTicks}t)`;
        } else if (trace.dbOp === 'SELECT') {
          frame = `Database SELECT ${trace.routePath ?? trace.path} @ ${database.replicaAddress} (${trace.dbStale ? 'STALE' : 'fresh'})`;
        } else {
          frame = `Database SKIP ${trace.routePath ?? trace.path} (warm cache HIT @ ${cache.address})`;
        }
      }
    } else if (trace.hop === 4) {
      // Hop 5/8: the webserver answers — an immediate 202 for async jobs,
      // the actually-served response for everything else.
      trace.hop = 5;
      if (trace.held) {
        serve(trace.held);
        frame = trace.asyncJob
          ? `${trace.targetServer} -> ${trace.from} | ${trace.held.response}`
          : `${trace.targetServer} -> ${trace.from} | ${trace.held.response} (cache ${trace.cacheStatus})`;
      }
    } else if (trace.hop === 5) {
      // Hop 6/8: WebServer returns its response via Network
      trace.hop = 6;
      frame = `Network delivered ${trace.status} response to ${trace.from}`;
    } else if (trace.hop === 6) {
      // Hop 7/8: Browser receives and displays the response
      trace.hop = 7;
      finish(trace.targetServer ?? serverAddress);
      frame = `Browser ${trace.from} received and displayed ${trace.status}`;
    } else if (trace.hop === 7) {
      // Hop 8/8: async job tails with the worker's commit; a request that
      // was served synchronously finds the worker idle.
      trace.hop = 8;
      const dbTarget = database ? database.primaryAddress : '10.30';
      const workerAddr = workerQueue ? workerQueue.workerAddress : '10.41';
      frame = trace.asyncJob
        ? `Worker ${workerAddr} finished job and committed to Database ${dbTarget}`
        : `Worker ${workerAddr} idle — no async jobs in this trace`;
    }
    return frame;
  }

  // Stage 6 hosted story: hops 2-3 are the DNS ask and the answer; the
  // Stage 5 chain then runs shifted by exactly two hops. An NX answer ends
  // the trace at hop 4 with the browser rendering the NX card — no GET is
  // ever emitted for an unknown name.
  function hostedStep(trace) {
    if (trace.hop === 1) {
      trace.hop = 2;
      trace.dnsAnswer = dns.lookup(trace.host, getTick());
      return `${trace.from} -> ${dns.address} | DNS ask ${trace.host}`;
    }
    if (trace.hop === 2) {
      trace.hop = 3;
      const a = trace.dnsAnswer;
      return a.status === 'NX'
        ? `${dns.address} -> ${trace.from} | NX no record for ${trace.host}`
        : `${dns.address} -> ${trace.from} | ${trace.host} -> ${a.target} (${a.status})`;
    }
    if (trace.hop === 3) {
      trace.hop = 4;
      if (trace.dnsAnswer.status === 'NX') {
        trace.finished = true;
        trace.status = 'NX';
        trace.body = `no record for ${trace.host}`;
        // The browser renders the NX answer; the request never left as a GET.
        onFinish({
          from: dns.address,
          to: trace.from,
          request: `DNS ask ${trace.host}`,
          response: `NX no record for ${trace.host}`,
          status: 'NX',
        });
        return `Browser ${trace.from} renders NX — no GET emitted`;
      }
      return `routed ${trace.from} -> ${serverAddress} (${trace.request}) to LoadBalancer`;
    }
    if (trace.hop === 4) {
      trace.hop = 5;
      const atTick = bumpTick();
      const target = lb.enqueue({
        id: `you:${atTick}`,
        from: trace.from,
        to: serverAddress,
        request: trace.wireRequest ?? trace.request,
        atTick,
        isYou: true,
      });
      trace.targetServer = target;
      return `LB ${serverAddress} -> ${target} (${trace.wireRequest ?? trace.request}) queued`;
    }
    // Hops 6..10 ride the Stage 5 handlers two hops later: shift the hop
    // counter down for the call, then back up so the real trace stays in
    // hosted numbering.
    trace.hop -= 2;
    const frame = stage5Step(trace);
    trace.hop += 2;
    return frame;
  }

  return { stage5Step, hostedStep };
}
