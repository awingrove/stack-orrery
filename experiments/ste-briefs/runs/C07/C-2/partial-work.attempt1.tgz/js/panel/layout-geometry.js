// DOCUMENTS: pure orbital geometry for layout.js (split by responsibility,
// guard-file-size): polar→world coordinates, the compact-browser satellite
// arcs on the outer client ring, and the wire builder for radial spokes.
// Zero stage knowledge — layout.js owns the per-stage registry.
export function polarToWorld(radius, angleDeg) {
  const rad = (angleDeg * Math.PI) / 180;
  return { x: Math.round(radius * Math.cos(rad)), y: Math.round(radius * Math.sin(rad)) };
}

export function computeSatellites(users, outerRadius) {
  const count = Math.max(0, Math.round(users));
  const leftCount = Math.ceil(count / 2);
  const rightCount = count - leftCount;
  const satellites = [];
  const place = (arcCount, startAngle) => {
    for (let j = 0; j < arcCount; j += 1) {
      const angleDeg = startAngle + ((j + 1) / (arcCount + 1)) * 37;
      const { x, y } = polarToWorld(outerRadius, angleDeg);
      satellites.push({ index: satellites.length, x, y, angleDeg });
    }
  };
  place(leftCount, 135);
  place(rightCount, 188);
  return satellites;
}

export function makeWire(id, fromId, toId, from, to) {
  return {
    id,
    fromId,
    toId,
    x1: from.x,
    y1: from.y,
    x2: to.x,
    y2: to.y,
    midX: Math.round((from.x + to.x) / 2),
    midY: Math.round((from.y + to.y) / 2),
  };
}

// Addressable browsers on the outer client ring: slot 0 (mini-IP 10.2)
// sits at 180° — the expanded #node-browser spot — and slots 1..users - 1
// (10.3 .. 10.(users + 1)) take the satellite arc positions. Compact nodes
// render at every slot not currently expanded.
export function computeBrowserSlots(users, outerRadius, activeBrowser = '10.2') {
  const browserCount = Math.max(0, Math.round(users));
  const walkArcs = computeSatellites(Math.max(0, browserCount - 1), outerRadius);
  const browserSlots = Array.from({ length: browserCount }, (_, i) => {
    if (i === 0)
      return { index: 0, address: '10.2', angleDeg: 180, ...polarToWorld(outerRadius, 180) };
    return { index: i, address: `10.${i + 2}`, ...walkArcs[i - 1] };
  });
  const activeSlot = browserSlots.find((slot) => slot.address === String(activeBrowser)) ?? {
    index: 0,
    address: '10.2',
    angleDeg: 180,
    ...polarToWorld(outerRadius, 180),
  };
  return { browserSlots, activeSlot };
}
