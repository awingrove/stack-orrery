// DOCUMENTS: the Stage 6 inspector code mirrors — DNS (resolver ledger)
// and Router (cross-subnet forward), split from inspector-source.js by
// responsibility (guard-file-size). js/sim/* is the executable truth; these
// entries render the same logic for learners.
export const COMPONENT_SOURCE_6 = {
  dns: {
    file: 'js/sim/dns.js',
    title: 'DNS — authoritative names + tick-TTL ledger',
    code: `createDns({ address = '10.60', ttlTicks = 300 } = {}) {
  // address must be "<net>.<host>" — a two-number mini-IP
  const authoritative = new Map([['example.com', '10.1']]);
  const cache = new Map(); // name -> { name, target, cachedAtTick, expiresAtTick }
  let lookups = 0, cachedHits = 0, misses = 0, nx = 0, evictions = 0;
  function evictExpired(currentTick = 0) {
    for (const entry of cache.values()) {
      if (currentTick >= entry.expiresAtTick) {  // TTL elapsed
        cache.delete(entry.name); evictions += 1;
      }
    }
  }
  function lookup(name, currentTick = 0) {
    lookups += 1; evictExpired(currentTick);
    const entry = cache.get(name);
    if (entry) {  // ledger HIT inside ttlTicks — no authoritative consult
      cachedHits += 1;
      return { name, status: 'HIT', target: entry.target, source: address };
    }
    const target = authoritative.get(name) ?? null;
    if (target === null) {  // unknown name: NX, never a throw here
      nx += 1;
      return { name, status: 'NX', target: null, source: address };
    }
    misses += 1;
    cache.set(name, { name, target, cachedAtTick: currentTick,
      expiresAtTick: currentTick + ttlTicks });
    return { name, status: 'MISS', target, source: address };
  }
  return { address, evictExpired, lookup, snapshot };
}`,
  },
  router: {
    file: 'js/sim/router.js',
    title: 'Router — cross-subnet forward',
    code: `createRouter({ leftAddress = '10.65', rightAddress = '20.1' } = {}) {
  // one interface per subnet; both must be two-number mini-IPs
  let leftNetwork = null, rightNetwork = null, routed = 0;
  function exitFor(frame) {  // from/to subnets pick the exit network
    const fromSubnet = subnetOf(frame.from), toSubnet = subnetOf(frame.to);
    if (fromSubnet === leftSubnet && toSubnet === rightSubnet) return rightNetwork;
    if (fromSubnet === rightSubnet && toSubnet === leftSubnet) return leftNetwork;
    throw new Error(\`router: no route to \${toSubnet}.x\`);
  }
  return {
    attach(left, right) {  // join the 10.x and 20.x Network instances
      leftNetwork = left; rightNetwork = right;
    },
    forward(frame) {  // synchronous: exactly one router hop
      const response = exitFor(frame).receiveRouted(frame);
      routed += 1;
      return response;
    },
    forwardQueue(frame) {  // queued: one hop into the exit queue
      exitFor(frame).enqueueRouted(frame);
      routed += 1;
    },
  };
}`,
  },
};
