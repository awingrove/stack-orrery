// DOCUMENTS: Stage 6 node cards and the DNS wire column, built in js
// rather than panel.html because that page sits at its 550-line cap
// (same pattern as teaching-drawer.js). Zero behavior lives here: cards
// are created once, hidden by default, and render-stage.js toggles their
// visibility on stage switches; viewport.js positions them from the
// layout registry by id.
function el(tag, className, textContent, testId) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (textContent !== undefined) node.textContent = textContent;
  if (testId) node.dataset.testid = testId;
  return node;
}

function nodeHeader(roleName, subtitle, ipChip) {
  const head = el('header', 'node-head');
  const name = el('div', 'node-name');
  name.append(el('span', 'role-name', roleName), el('span', 'node-subtitle', subtitle));
  head.append(name, el('span', 'ip-chip', ipChip), el('span', 'code-chip', '</> Code'));
  return head;
}

// CHECKS: the builder is idempotent — a page that already carries the
// Stage 6 registry keeps it instead of stacking duplicate cards.
export function ensureStage6Cards() {
  if (document.getElementById('node-dns')) return;
  const world = document.getElementById('orrery-world');

  const dnsWire = el('div', 'wire-column');
  dnsWire.id = 'wire-dns-ask';
  dnsWire.setAttribute('aria-hidden', 'true');
  dnsWire.hidden = true;
  const dnsReq = el('div', 'wire-lane', 'dns ask =>');
  dnsReq.id = 'packet-req-dns';
  const dnsRes = el('div', 'wire-lane reverse', '<- answer');
  dnsRes.id = 'packet-res-dns';
  dnsWire.append(dnsReq, dnsRes);
  world.append(dnsWire);

  const dns = el('article', 'node-card');
  dns.id = 'node-dns';
  dns.dataset.testid = 'node-dns';
  dns.dataset.component = 'dns';
  dns.hidden = true;
  dns.append(nodeHeader('DNS', 'names + tick-TTL ledger', '10.60'));
  const dnsStats = el(
    'p',
    'mono last-frame',
    'Lookups: 0 · Cached hits: 0 · Misses: 0 · TTL: 300t',
  );
  dnsStats.id = 'dns-stats';
  dnsStats.dataset.testid = 'dns-stats';
  const dnsEntries = el('ul', 'route-list');
  dnsEntries.id = 'dns-entries-list';
  dnsEntries.dataset.testid = 'dns-entries-list';
  dnsEntries.setAttribute('aria-label', 'Resolver cache entries');
  dns.append(dnsStats, dnsEntries);
  world.append(dns);

  const router = el('article', 'node-card');
  router.id = 'node-router';
  router.dataset.testid = 'node-router';
  router.dataset.component = 'router';
  router.hidden = true;
  router.append(nodeHeader('Router', 'cross-subnet forward', '10.65 ⇄ 20.1'));
  const routerStats = el('p', 'mono last-frame', 'Routed: 0');
  routerStats.id = 'router-stats';
  routerStats.dataset.testid = 'router-stats';
  router.append(routerStats);
  world.append(router);
}
