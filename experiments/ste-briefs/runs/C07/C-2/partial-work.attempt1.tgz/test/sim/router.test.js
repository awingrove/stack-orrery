import { describe, it, expect } from 'vitest';
import { createRouter } from '../../js/sim/router.js';
import { createNetwork } from '../../js/sim/network.js';
import { createBrowser } from '../../js/sim/browser.js';
import { createWebServer } from '../../js/sim/webserver.js';

function joinedStacks() {
  const net10 = createNetwork({ subnet: '10' });
  const net20 = createNetwork({ subnet: '20' });
  const router = createRouter({ leftAddress: '10.65', rightAddress: '20.1' });
  router.attach(net10, net20);
  net10.attachRouter(router);
  net20.attachRouter(router);
  return { net10, net20, router };
}

describe('createRouter', () => {
  it("same-subnet sends keep today's contract; cross-subnet frames take exactly one router hop", () => {
    const { net10, net20, router } = joinedStacks();
    net10.registerServer('10.1', createWebServer({ address: '10.1' }));
    // Stage 6a leaves subnet 20 empty in the engine; a real 20.1 edge here
    // only observes the routed frame on the far side of the hop.
    net20.registerServer('20.1', createWebServer({ address: '20.1' }));
    const browser = createBrowser({ name: 'Browser-1', address: '10.2', network: net10 });

    // Same-subnet: the send/deliverToQueue contract is unchanged, and the
    // router counted no hop.
    const ok = browser.get('10.1', '/about');
    expect(ok.response).toBe('200 This is the about page');
    expect(router.routed).toBe(0);

    // Cross-subnet: exactly one router hop carries the frame into subnet
    // 20 and the response record rides back untouched.
    const cross = browser.get('20.1', '/about');
    expect(cross).toEqual({
      from: '10.2',
      to: '20.1',
      request: 'GET /about',
      response: '200 This is the about page',
      status: 200,
      body: 'This is the about page',
    });
    expect(router.routed).toBe(1);
    expect(router.snapshot().lastFrame).toBe(
      'router 10.65 ⇄ 20.1 forwarded 10.2 -> 20.1 (GET /about)',
    );
  });

  it('a queued cross-subnet request takes the same single router hop', () => {
    const { net10, net20, router } = joinedStacks();
    net20.registerServer('20.1', createWebServer({ address: '20.1' }));
    net10.deliverToQueue({
      id: '1:1',
      from: '10.2',
      to: '20.1',
      request: 'GET /about',
      atTick: 1,
      isYou: true,
    });
    expect(router.routed).toBe(1);
    const queue = net20.resolve('20.1').queueSnapshot();
    expect(queue).toEqual([
      { id: '1:1', from: '10.2', to: '20.1', request: 'GET /about', atTick: 1, isYou: true },
    ]);
  });

  it('a send into subnet 20 to an unregistered host 20.9 fails loud', () => {
    const { net10, router } = joinedStacks();
    // Subnet 20 carries nothing but the router's own presence in 6a, so a
    // send to 20.9 reaches the far network and fails loud there — the same
    // "no server at <address>" throw network.js has always raised.
    const browser = createBrowser({ address: '10.2', network: net10 });
    expect(() => browser.get('20.9', '/')).toThrow(/no server at 20\.9/);
    // A failed forward completes no hop: routed stays put.
    expect(router.routed).toBe(0);
  });

  it('refuses same-subnet frames and third subnets instead of inventing a route', () => {
    const { router } = joinedStacks();
    expect(() => router.forward({ from: '10.2', to: '10.1', request: 'GET /' })).toThrow(
      /no route from subnet 10\.x to subnet 10\.x/,
    );
    expect(() => router.forward({ from: '10.2', to: '11.1', request: 'GET /' })).toThrow(
      /no route from subnet 10\.x to subnet 11\.x/,
    );
  });

  it('rejects an invalid mini-IP interface, same-subnet interfaces, and missing networks', () => {
    expect(() => createRouter({ leftAddress: '1065' })).toThrow(/invalid mini-IP/);
    expect(() => createRouter({ rightAddress: '20.1.1' })).toThrow(/invalid mini-IP/);
    expect(() => createRouter({ leftAddress: '10.65', rightAddress: '10.9' })).toThrow(
      /two different subnets/,
    );
    const detached = createRouter({});
    expect(() => detached.forward({ from: '10.2', to: '20.1', request: 'GET /' })).toThrow(
      /no networks attached/,
    );
    // attach validates the networks' own subnets against the interfaces.
    const router = createRouter({});
    expect(() => router.attach(createNetwork({ subnet: '20' }), createNetwork())).toThrow(
      /must be subnets 10 and 20/,
    );
  });
});
