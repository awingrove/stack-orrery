import { describe, it, expect } from 'vitest';
import { createDns } from '../../js/sim/dns.js';
import { createEngine } from '../../js/sim/engine.js';

describe('createDns', () => {
  it('resolves example.com through the tick-TTL ledger and re-consults after expiry', () => {
    const dns = createDns({ address: '10.60', ttlTicks: 300 });

    // Cold lookup: a real authoritative consult on the request path.
    expect(dns.lookup('example.com', 5)).toEqual({
      name: 'example.com',
      status: 'MISS',
      target: '10.1',
      source: '10.60',
    });
    expect(dns.snapshot(5)).toMatchObject({ lookups: 1, cachedHits: 0, misses: 1, nx: 0 });
    expect(dns.snapshot(5).cache).toEqual([
      {
        name: 'example.com',
        target: '10.1',
        cachedAtTick: 5,
        expiresAtTick: 305,
        ttlRemaining: 300,
      },
    ]);

    // CHECKS: a lookup inside ttlTicks is a ledger HIT — cachedHits
    // increments and the authoritative table is not consulted again
    // (misses stays put; a hit answers from the cache alone).
    const hit = dns.lookup('example.com', 200);
    expect(hit).toEqual({ name: 'example.com', status: 'HIT', target: '10.1', source: '10.60' });
    expect(dns.snapshot(200)).toMatchObject({ lookups: 2, cachedHits: 1, misses: 1 });
    expect(dns.snapshot(200).lastLookup).toEqual({
      name: 'example.com',
      status: 'HIT',
      target: '10.1',
      atTick: 200,
    });

    // CHECKS: an expired entry cannot answer from the ledger — cached at
    // tick 5 with ttlTicks 300 it dies at tick 305, the lookup evicts it
    // (evictions +1) and consults the authoritative table again (MISS).
    const expired = dns.lookup('example.com', 305);
    expect(expired.status).toBe('MISS');
    expect(expired.target).toBe('10.1');
    expect(dns.snapshot(305)).toMatchObject({
      cachedHits: 1,
      misses: 2,
      evictions: 1,
    });
    expect(dns.snapshot(305).lastLookup).toEqual({
      name: 'example.com',
      status: 'MISS',
      target: '10.1',
      atTick: 305,
    });

    // CHECKS: the constructor rejects a non-mini-IP address and a
    // non-positive or non-integer ttlTicks (fail-loud over misconfig).
    expect(() => createDns({ address: '1060' })).toThrow(/invalid mini-IP/);
    expect(() => createDns({ ttlTicks: 0 })).toThrow(/ttlTicks/);
    expect(() => createDns({ ttlTicks: 2.5 })).toThrow(/ttlTicks/);
  });

  it('answers NX for unknown names without throwing at the DNS layer', () => {
    const dns = createDns({});
    expect(dns.lookup('nope.example', 3)).toEqual({
      name: 'nope.example',
      status: 'NX',
      target: null,
      source: '10.60',
    });
    const snap = dns.snapshot(3);
    expect(snap).toMatchObject({ lookups: 1, nx: 1, misses: 0, cachedHits: 0 });
    expect(snap.cache).toEqual([]);
    // The NX branch never caches and never throws — the browser renders it.
    expect(() => dns.lookup('also.missing.example', 4)).not.toThrow();
    expect(dns.snapshot(4).nx).toBe(2);
  });
});

describe('stage 6 engine wiring', () => {
  it('stage 6 exposes DNS 10.60 and Router 10.65 ⇄ 20.1 in the snapshot', () => {
    const engine = createEngine({ stage: 6 });
    const snap = engine.snapshot();
    expect(snap.dns.address).toBe('10.60');
    expect(snap.dns.ttlTicks).toBe(300);
    expect(snap.dns.authoritative).toEqual({ 'example.com': '10.1' });
    expect(snap.dns.lookups).toBe(0);
    expect(snap.router).toEqual({
      leftAddress: '10.65',
      rightAddress: '20.1',
      routed: 0,
      lastFrame: null,
    });
    // The Stage 5 story carries forward: worker queue, database, cache.
    expect(snap.workerQueue).not.toBe(null);
    expect(snap.database).not.toBe(null);
    expect(snap.cache).not.toBe(null);
  });

  it('stage 6 engine rejects stage 7 with the updated stage range message', () => {
    expect(() => createEngine({ stage: 7 })).toThrow(/stage must be 1, 2, 3, 4, 5, or 6, got 7/);
  });

  it('stage 6 hosted trace pays exactly 2 DNS hops; a host-less trace pays none', () => {
    const engine = createEngine({ stage: 6 });
    // Hosted run: 10 hops, one authoritative MISS warming the ledger.
    for (let i = 0; i < 10; i++) engine.traceHop({ method: 'GET', path: 'example.com/about' });
    let snap = engine.snapshot();
    expect(snap.trace.hop).toBe(10);
    expect(snap.trace.host).toBe('example.com');
    expect(snap.trace.targetServer).toBe('10.11');
    expect(snap.browserDisplay.body).toBe('This is the about page');
    expect(snap.dns).toMatchObject({ lookups: 1, misses: 1, cachedHits: 0 });
    expect(snap.dns.cache.map((e) => e.name)).toEqual(['example.com']);

    // Second hosted run: the ledger answers inside the TTL — cachedHits
    // bumps, the authoritative table is not consulted (misses stays 1).
    for (let i = 0; i < 10; i++) engine.traceHop({ method: 'GET', path: 'example.com/about' });
    snap = engine.snapshot();
    expect(snap.trace.hop).toBe(10);
    expect(snap.dns).toMatchObject({ lookups: 2, cachedHits: 1, misses: 1 });

    // Host-less run: the stage-5 8-hop story, and the DNS ledger is left
    // exactly as the hosted runs left it — no DNS hop on plain paths.
    for (let i = 0; i < 8; i++) engine.traceHop({ method: 'GET', path: '/about' });
    snap = engine.snapshot();
    expect(snap.trace.hop).toBe(8);
    expect(snap.trace.host).toBe(null);
    expect(snap.browserDisplay.body).toBe('This is the about page');
    expect(snap.dns).toMatchObject({ lookups: 2, cachedHits: 1, misses: 1, nx: 0 });
  });

  it('stage 6 NX trace never emits a GET: DNS ask + NX answer only', () => {
    const engine = createEngine({ stage: 6 });
    for (let i = 0; i < 4; i++) engine.traceHop({ method: 'GET', path: 'nope.example/about' });
    const snap = engine.snapshot();
    expect(snap.trace.hop).toBe(4);
    expect(snap.trace.finished).toBe(true);
    expect(snap.trace.status).toBe('NX');
    expect(snap.dns).toMatchObject({ lookups: 1, nx: 1, misses: 0, cachedHits: 0 });
    // The browser rendered the NX card — from '10.60', not a served 200.
    expect(snap.browserDisplay).toMatchObject({
      from: '10.60',
      to: '10.2',
      request: 'DNS ask nope.example',
      response: 'NX no record for nope.example',
      status: 'NX',
      body: 'no record for nope.example',
    });
    // No GET reached any server queue: served stays 0 across the pool.
    expect(snap.served).toBe(0);
    // Hopping again restarts cleanly from the emit hop.
    engine.traceHop({ method: 'GET', path: '/about' });
    expect(engine.snapshot().trace.hop).toBe(1);
  });
});
