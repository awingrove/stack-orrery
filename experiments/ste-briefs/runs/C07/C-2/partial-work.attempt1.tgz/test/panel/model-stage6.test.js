import { describe, it, expect } from 'vitest';
import { describeSnapshot, totalHopsForSnapshot } from '../../js/panel/model.js';
import { componentTitle, formatComponentState } from '../../js/panel/inspector-state.js';

// Stage-boundary extraction (guard-file-size): the Stage 6 narrative
// branch pins live here so model.test.js stays inside the 450-line test
// cap. The five negative-case contracts from the brief are pinned as named
// counter-examples; the DNS/Router table copy is part of the fixture.
const HOSTED_SNAP = {
  stage: 6,
  tick: 1,
  users: 5,
  serverAddress: '10.1',
  queueDepth: 0,
  served: 1,
  avgLatencyTicks: 1,
  workerQueue: { address: '10.40', workerAddress: '10.41', enqueued: 0, completed: 0 },
  cache: { address: '10.20', hits: 0, misses: 1, ttlTicks: 10, entries: [] },
  database: {
    primaryAddress: '10.30',
    replicaAddress: '10.31',
    replicationLagTicks: 3,
    reads: 1,
    writes: 0,
    rows: [],
  },
  dns: {
    address: '10.60',
    ttlTicks: 300,
    lookups: 1,
    cachedHits: 0,
    misses: 1,
    nx: 0,
    evictions: 0,
    lastLookup: null,
    authoritative: { 'example.com': '10.1' },
    cache: [
      {
        name: 'example.com',
        target: '10.1',
        cachedAtTick: 0,
        expiresAtTick: 300,
        ttlRemaining: 299,
      },
    ],
  },
  router: { leftAddress: '10.65', rightAddress: '20.1', routed: 0, lastFrame: null },
  trace: {
    hop: 3,
    method: 'GET',
    path: 'example.com/about',
    request: 'GET example.com/about',
    wireRequest: 'GET /about',
    routePath: '/about',
    host: 'example.com',
    dnsAnswer: { name: 'example.com', status: 'MISS', target: '10.1', source: '10.60' },
    targetServer: '10.11',
    asyncJob: false,
    cacheStatus: 'MISS',
    dbOp: 'SELECT',
    dbStale: false,
    response: '200 This is the about page',
    status: 200,
    body: 'This is the about page',
    routeId: 'about',
    finished: false,
  },
};

const hopLabel = (snap, hop, over = {}) =>
  describeSnapshot({ ...snap, trace: { ...snap.trace, hop, ...over } }).hopStatus;

describe('stage 6 hosted narrative', () => {
  it('describes Stage 6 10-hop hosted trace labels and dns/router inspector state', () => {
    const labels = describeSnapshot(HOSTED_SNAP);
    expect(labels.stage).toBe(6);
    expect(labels.totalHops).toBe(10);
    expect(labels.hopStatus).toBe('Hop 3/10: DNS (10.60) answers example.com -> 10.1 (MISS)');
    const over = (fields) => ({ trace: { ...HOSTED_SNAP.trace, ...fields } });
    expect(describeSnapshot({ ...HOSTED_SNAP, ...over({ hop: 1 }) }).hopStatus).toBe(
      'Hop 1/10: Browser (10.2) emits "GET example.com/about"',
    );
    expect(describeSnapshot({ ...HOSTED_SNAP, ...over({ hop: 2 }) }).hopStatus).toBe(
      'Hop 2/10: Browser (10.2) asks DNS (10.60) for example.com',
    );
    expect(
      describeSnapshot({
        ...HOSTED_SNAP,
        dns: { ...HOSTED_SNAP.dns, cachedHits: 1, misses: 1 },
        ...over({ hop: 3, dnsAnswer: { name: 'example.com', status: 'HIT', target: '10.1' } }),
      }).hopStatus,
    ).toBe('Hop 3/10: DNS (10.60) answers example.com -> 10.1 (HIT)');
    expect(describeSnapshot({ ...HOSTED_SNAP, ...over({ hop: 4 }) }).hopStatus).toBe(
      'Hop 4/10: Network (10.x) routes to LoadBalancer (10.1)',
    );
    expect(describeSnapshot({ ...HOSTED_SNAP, ...over({ hop: 5 }) }).hopStatus).toBe(
      'Hop 5/10: LoadBalancer (10.1) -> 10.11 queue',
    );
    expect(describeSnapshot({ ...HOSTED_SNAP, ...over({ hop: 6 }) }).hopStatus).toBe(
      'Hop 6/10: Database SELECT @ Replica (10.31) — fresh',
    );
    expect(describeSnapshot({ ...HOSTED_SNAP, ...over({ hop: 7 }) }).hopStatus).toBe(
      'Hop 7/10: WebServer (10.11) -> "200 This is the about page" (cache MISS)',
    );
    expect(describeSnapshot({ ...HOSTED_SNAP, ...over({ hop: 8 }) }).hopStatus).toBe(
      'Hop 8/10: Network delivers 200 response to 10.2',
    );
    expect(describeSnapshot({ ...HOSTED_SNAP, ...over({ hop: 9 }) }).hopStatus).toBe(
      'Hop 9/10: Browser (10.2) received and displayed 200',
    );
    expect(describeSnapshot({ ...HOSTED_SNAP, ...over({ hop: 10 }) }).hopStatus).toBe(
      'Hop 10/10: Worker (10.41) idle — no async jobs in this trace',
    );

    // The dns/router inspector state mirrors the ledger and the counter.
    const dnsState = JSON.parse(formatComponentState(HOSTED_SNAP, 'dns'));
    expect(dnsState).toMatchObject({
      address: '10.60',
      ttlTicks: 300,
      lookups: 1,
      cachedHits: 0,
      misses: 1,
      authoritative: { 'example.com': '10.1' },
    });
    const routerState = JSON.parse(formatComponentState(HOSTED_SNAP, 'router'));
    expect(routerState).toEqual({
      leftAddress: '10.65',
      rightAddress: '20.1',
      routed: 0,
      lastFrame: null,
    });
    expect(componentTitle(HOSTED_SNAP, 'dns')).toBe('DNS — mini-IP 10.60');
    expect(componentTitle(HOSTED_SNAP, 'router')).toBe('Router — 10.65 ⇄ 20.1');
  });

  it('adds exactly 2 DNS hops to the stage-5 story, renumbering every later hop by +2', () => {
    // The hosted chain is the stage-5 story shifted: hop 6 (cache/db), hop
    // 7 (response emit), hop 9 (browser display) read their stage-5
    // narrative at 4/8, 5/8, 7/8 respectively.
    expect(hopLabel(HOSTED_SNAP, 6)).toBe('Hop 6/10: Database SELECT @ Replica (10.31) — fresh');
    expect(hopLabel(HOSTED_SNAP, 7)).toBe(
      'Hop 7/10: WebServer (10.11) -> "200 This is the about page" (cache MISS)',
    );
    expect(hopLabel(HOSTED_SNAP, 9)).toBe('Hop 9/10: Browser (10.2) received and displayed 200');
  });
});

describe('stage 6 host-less counter-example', () => {
  it('keeps GET /about on Stage 6 at the Stage 5 hop story byte-identical — no DNS hop', () => {
    const hostless = {
      ...HOSTED_SNAP,
      dns: { ...HOSTED_SNAP.dns, lookups: 0, cachedHits: 0, misses: 0, cache: [] },
      trace: {
        ...HOSTED_SNAP.trace,
        path: '/about',
        request: 'GET /about',
        wireRequest: 'GET /about',
        routePath: '/about',
        host: null,
        dnsAnswer: null,
      },
    };
    expect(totalHopsForSnapshot(hostless)).toBe(8);
    expect(hopLabel(hostless, 1)).toBe('Hop 1/8: Browser (10.2) emits "GET /about"');
    expect(hopLabel(hostless, 2)).toBe('Hop 2/8: Network (10.x) routes to LoadBalancer (10.1)');
    expect(hopLabel(hostless, 3)).toBe('Hop 3/8: LoadBalancer (10.1) -> 10.11 queue');
    expect(hopLabel(hostless, 4)).toBe('Hop 4/8: Database SELECT @ Replica (10.31) — fresh');
    expect(hopLabel(hostless, 5)).toBe(
      'Hop 5/8: WebServer (10.11) -> "200 This is the about page" (cache MISS)',
    );
    expect(hopLabel(hostless, 6)).toBe('Hop 6/8: Network delivers 200 response to 10.2');
    expect(hopLabel(hostless, 7)).toBe('Hop 7/8: Browser (10.2) received and displayed 200');
    expect(hopLabel(hostless, 8)).toBe(
      'Hop 8/8: Worker (10.41) idle — no async jobs in this trace',
    );
    expect(hopLabel(hostless, 9)).toBe('Idle — type a path and click Go or Step 1 Hop ->');
  });
});

describe('stage 6 NX counter-example', () => {
  it('renders the NX story for an unknown name — no GET emitted', () => {
    const nx = {
      ...HOSTED_SNAP,
      dns: { ...HOSTED_SNAP.dns, lookups: 1, nx: 1, misses: 0, cache: [] },
      trace: {
        ...HOSTED_SNAP.trace,
        path: 'nope.example/about',
        request: 'GET nope.example/about',
        host: 'nope.example',
        dnsAnswer: { name: 'nope.example', status: 'NX', target: null, source: '10.60' },
        status: 'NX',
        body: 'no record for nope.example',
        targetServer: null,
        finished: true,
      },
    };
    expect(totalHopsForSnapshot(nx)).toBe(4);
    expect(hopLabel(nx, 1)).toBe('Hop 1/4: Browser (10.2) emits "GET nope.example/about"');
    expect(hopLabel(nx, 2)).toBe('Hop 2/4: Browser (10.2) asks DNS (10.60) for nope.example');
    expect(hopLabel(nx, 3)).toBe('Hop 3/4: DNS (10.60) answers NX — no record for nope.example');
    expect(hopLabel(nx, 4)).toBe('Hop 4/4: Browser (10.2) renders NX — no GET emitted');
    // The NX decision also drives the pre-lookup hops: the authoritative
    // table in the snapshot decides the denominator before dnsAnswer exists.
    expect(totalHopsForSnapshot({ ...nx, trace: { ...nx.trace, hop: 1, dnsAnswer: null } })).toBe(
      4,
    );
    expect(totalHopsForSnapshot(HOSTED_SNAP)).toBe(10);
  });
});

describe('stage 6 total-hops helper', () => {
  it('reads the host syntax off the trace for every stage-6 shape', () => {
    expect(totalHopsForSnapshot({ stage: 6, trace: { path: '/about' } })).toBe(8);
    expect(totalHopsForSnapshot(HOSTED_SNAP)).toBe(10);
    // Unknown host: the authoritative table lacks the name -> NX shape.
    expect(
      totalHopsForSnapshot({
        stage: 6,
        dns: { authoritative: {} },
        trace: { path: 'nope.example/about' },
      }),
    ).toBe(4);
    // Stages 1-5 keep the fixed per-stage counts.
    expect(totalHopsForSnapshot({ stage: 5 })).toBe(8);
    expect(totalHopsForSnapshot({ stage: 1 })).toBe(4);
    expect(totalHopsForSnapshot(null)).toBe(4);
  });
});
