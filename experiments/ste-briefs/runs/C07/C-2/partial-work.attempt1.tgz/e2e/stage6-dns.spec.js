import { test, expect } from '@playwright/test';

// Stage 6a (DNS + cross-subnet router) assertions, split into their own
// spec because e2e/panel.spec.js sits at its 450-line cap (guard-file-size
// splits e2e by responsibility, as with teaching.spec.js). Titles are the
// manifest pins in slices.yaml / storymap.yaml — do not reword.

// Stage 6 redraws to 8 rings: DNS 10.60 on Ring 7, the Router side-card
// beside the network hub on Ring 6. A hosted URL resolves through the
// tick-TTL ledger — the first trace misses authoritatively and warms the
// ledger, the second is a cached hit — and the DNS code + ledger open in
// the bottom inspector.
test('should switch to Stage 6, resolve example.com through DNS 10.60, and inspect DNS code + TTL ledger', async ({
  page,
}) => {
  await page.goto('/panel.html');

  await page.getByTestId('stage-pill-6').click();
  await expect(page.getByTestId('node-dns')).toBeVisible();
  await expect(page.getByTestId('node-router')).toBeVisible();
  await expect(page.locator('.orrery-ring')).toHaveCount(8);
  await expect(page.locator('.orrery-ring').first()).toHaveAttribute('r', '400');
  await expect(page.locator('.orrery-ring').last()).toHaveAttribute('r', '3200');
  await expect(page.getByTestId('dns-stats')).toHaveText(
    'Lookups: 0 · Cached hits: 0 · Misses: 0 · TTL: 300t',
  );
  await expect(page.getByTestId('router-stats')).toHaveText('Routed: 0');

  // First hosted trace: the ask + answer hops pay off, the authoritative
  // MISS warms the ledger, and the page renders through the stage-5 chain.
  await page.getByTestId('url-input').fill('example.com/about');
  for (let hop = 0; hop < 10; hop++) await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toContainText('Hop 10/10');
  await expect(page.getByTestId('dns-stats')).toHaveText(
    'Lookups: 1 · Cached hits: 0 · Misses: 1 · TTL: 300t',
  );
  await expect(page.getByTestId('dns-entries-list')).toContainText('example.com -> 10.1');
  await expect(page.getByTestId('browser-rendered-body')).toHaveText('This is the about page');

  // Second hosted trace: the ledger answers inside ttlTicks — cachedHits
  // climbs while Misses stays put (no authoritative consult).
  for (let hop = 0; hop < 10; hop++) await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('dns-stats')).toHaveText(
    'Lookups: 2 · Cached hits: 1 · Misses: 1 · TTL: 300t',
  );

  await page.getByTestId('node-dns').click();
  await expect(page.getByTestId('inspector-code')).toContainText('createDns');
  await expect(page.getByTestId('inspector-state')).toContainText('"cachedHits": 1');
  await expect(page.getByTestId('inspector-title')).toHaveText('DNS — mini-IP 10.60');

  await page.getByTestId('node-router').click();
  await expect(page.getByTestId('inspector-code')).toContainText('createRouter');
  await expect(page.getByTestId('inspector-state')).toContainText('"routed": 0');
  await expect(page.getByTestId('inspector-title')).toHaveText('Router — 10.65 ⇄ 20.1');
});

// A hosted URL walks the two DNS hops first: the ask (browser -> 10.60),
// the answer (10.60 -> browser with the resolved mini-IP), then the
// stage-5 chain shifted by two (10 hops total).
test('should trace example.com/about with DNS ask + answer hops', async ({ page }) => {
  await page.goto('/panel.html');

  await page.getByTestId('stage-pill-6').click();
  await page.getByTestId('url-input').fill('example.com/about');
  await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toHaveText(
    'Hop 1/10: Browser (10.2) emits "GET example.com/about"',
  );
  await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toHaveText(
    'Hop 2/10: Browser (10.2) asks DNS (10.60) for example.com',
  );
  await expect(page.getByTestId('node-dns')).toHaveClass(/active-hop/);
  await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toHaveText(
    'Hop 3/10: DNS (10.60) answers example.com -> 10.1 (MISS)',
  );
  for (let hop = 0; hop < 7; hop++) await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toContainText(
    'Hop 10/10: Worker (10.41) idle — no async jobs in this trace',
  );
  await expect(page.getByTestId('browser-status-badge')).toContainText('200');
  await expect(page.getByTestId('browser-rendered-body')).toHaveText('This is the about page');
});

// Named counter-example (DL-3): a host-less path on Stage 6 keeps the
// stage-5 hop story byte-identical — 8 hops, no DNS hop, and the DNS
// ledger is left completely untouched (Lookups: 0).
test('should keep GET /about on Stage 6 at the Stage 5 hop story', async ({ page }) => {
  await page.goto('/panel.html');

  await page.getByTestId('stage-pill-6').click();
  await page.getByTestId('url-input').fill('/about');
  const sentences = [];
  for (let hop = 0; hop < 8; hop++) {
    await page.getByTestId('btn-next-hop').click();
    sentences.push(await page.getByTestId('hop-status').textContent());
  }
  expect(sentences).toEqual([
    'Hop 1/8: Browser (10.2) emits "GET /about"',
    'Hop 2/8: Network (10.x) routes to LoadBalancer (10.1)',
    'Hop 3/8: LoadBalancer (10.1) -> 10.11 queue',
    'Hop 4/8: Database SELECT @ Replica (10.31) — fresh',
    'Hop 5/8: WebServer (10.11) -> "200 This is the about page" (cache MISS)',
    'Hop 6/8: Network delivers 200 response to 10.2',
    'Hop 7/8: Browser (10.2) received and displayed 200',
    'Hop 8/8: Worker (10.41) idle — no async jobs in this trace',
  ]);
  await expect(page.getByTestId('browser-rendered-body')).toHaveText('This is the about page');
  // No DNS hop on the host-less path: the ledger was never consulted.
  await expect(page.getByTestId('dns-stats')).toHaveText(
    'Lookups: 0 · Cached hits: 0 · Misses: 0 · TTL: 300t',
  );
});
