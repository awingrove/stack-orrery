// DOCUMENTS: the Stage 6 component — an authoritative resolver at mini-IP
// 10.60 that mirrors the Cache's tick-TTL ledger pattern: the authoritative
// table is consulted only on a miss (or an expired entry), and a hit inside
// ttlTicks is answered from the cache ledger with its own counter. Unknown
// names answer NX — the browser renders the NX card, and no GET is ever
// emitted for an unresolved name. Deterministic by construction: no clock,
// no RNG — time arrives as the `currentTick` argument, the same way the
// Cache keeps time.
//
// CHECKS: the constructor rejects an address that is not a two-number
// mini-IP and a ttlTicks that is not a positive integer (fail-loud over
// silent mis-configuration, like cache.js).
const MINI_IP = /^\d+\.\d+$/;

export function createDns({ address = '10.60', ttlTicks = 300 } = {}) {
  if (!MINI_IP.test(address)) {
    throw new Error(`dns: invalid mini-IP address ${address}`);
  }
  if (!Number.isInteger(ttlTicks) || ttlTicks < 1) {
    throw new Error(`dns: ttlTicks must be a positive integer, got ${ttlTicks}`);
  }
  // The authoritative table lives in-component; Stage 6b adds a CDN name.
  const authoritative = new Map([['example.com', '10.1']]);
  const cache = new Map(); // name -> { name, target, cachedAtTick, expiresAtTick }
  let lookups = 0;
  let cachedHits = 0;
  let authoritativeConsults = 0;
  let nxAnswers = 0;
  let lastLookup = null;

  // An entry is stale the moment the current tick reaches its expiry, the
  // same rule the Cache ledger uses.
  function evictExpired(currentTick = 0) {
    for (const entry of cache.values()) {
      if (currentTick >= entry.expiresAtTick) {
        cache.delete(entry.name);
      }
    }
  }

  function lookup(name, currentTick = 0) {
    lookups += 1;
    evictExpired(currentTick);
    const entry = cache.get(name);
    if (entry) {
      // Cache-branch answer: the ledger replies and the authoritative
      // table is not consulted — cachedHits is the only counter that moves.
      cachedHits += 1;
      lastLookup = { name, status: 'HIT', target: entry.target, atTick: currentTick };
      return { status: 'OK', name, target: entry.target, source: 'cache' };
    }
    // Miss (or expired entry already evicted above): consult the table.
    authoritativeConsults += 1;
    const target = authoritative.get(name) ?? null;
    if (target === null) {
      nxAnswers += 1;
      lastLookup = { name, status: 'NX', atTick: currentTick };
      return { status: 'NX', name };
    }
    cache.set(name, {
      name,
      target,
      cachedAtTick: currentTick,
      expiresAtTick: currentTick + ttlTicks,
    });
    lastLookup = { name, status: 'AUTH', target, atTick: currentTick };
    return { status: 'OK', name, target, source: 'authoritative' };
  }

  function snapshot(currentTick = 0) {
    evictExpired(currentTick);
    return {
      address,
      ttlTicks,
      lookups,
      cachedHits,
      authoritativeConsults,
      nxAnswers,
      lastLookup,
      authoritative: Object.fromEntries(authoritative),
      cache: [...cache.values()].map((entry) => ({
        name: entry.name,
        target: entry.target,
        cachedAtTick: entry.cachedAtTick,
        expiresAtTick: entry.expiresAtTick,
        ttlRemaining: entry.expiresAtTick - currentTick,
      })),
    };
  }

  return {
    get address() {
      return address;
    },
    evictExpired,
    lookup,
    snapshot,
  };
}
