// DOCUMENTS: the single-request hop-by-hop state machine behind the panel's
// "Step 1 Hop ->" trace — one hop per call, running across the same
// network/LB/queue/cache machinery the crowd uses (it does not fake a
// shortcut). The machine shell (fresh emission, Stage 1's four hops, and
// the Stage 6 DNS prefix) lives here; the Stage 2-5 chain hops live in
// trace-chain.js, and a hosted Stage 6 trace rides that chain shifted +2
// after its DNS ask + answer (trace-stage6.js). 4 hops in Stage 1 (emit,
// route, serve, render); 5 in Stage 2; 6 in Stage 3; 7 in Stage 4; 8 in
// Stage 5; hosted Stage 6 = 10, host-less Stage 6 = 8, NX Stage 6 = 2.
//
// CHECKS: an out-of-range stage fails loud at construction instead of
// building a trace that can never advance, and a Stage 6 machine without a
// dns resolver is rejected for the same reason.
import { chainHop } from './trace-chain.js';
import { createDnsPrefix, splitHostPath } from './trace-stage6.js';

export function createTraceMachine({
  stage,
  serverAddress,
  servers,
  lb = null,
  network,
  cache = null,
  database = null,
  workerQueue = null,
  dns = null,
  bumpTick,
  getTick,
  onServe,
  onFinish,
  onUnresolved = null,
}) {
  if (!Number.isInteger(stage) || stage < 1 || stage > 6) {
    throw new Error(`trace: stage must be 1, 2, 3, 4, 5, or 6, got ${stage}`);
  }
  if (stage === 6 && !dns) {
    throw new Error('trace: stage 6 needs a dns resolver for hosted paths');
  }
  const dnsPrefix = createDnsPrefix({ dns, getTick, onFinish: onUnresolved ?? onFinish });
  const state = { trace: freshTrace(), served: null };

  function freshTrace({
    method = 'GET',
    path = '/about',
    from = '10.2',
    targetServer = null,
  } = {}) {
    const split = splitHostPath(path);
    return {
      hop: 0,
      method,
      path,
      from,
      request: `${method} ${path}`,
      targetServer,
      hosted: split.hosted,
      host: split.host,
      resolvedPath: split.path,
      dnsTarget: null,
      dnsSource: null,
      nx: false,
      response: null,
      status: null,
      body: null,
      routeId: null,
    };
  }

  function serve(you) {
    state.trace.response = you.response;
    state.trace.status = you.status;
    state.trace.body = you.body;
    state.trace.routeId = you.routeId;
    onServe(you);
  }

  // Final hop: the rendered response lands on the browser the trace
  // originated from (the engine routes it into the right browser state).
  function finish(toAddress) {
    onFinish({
      from: state.trace.from ?? '10.2',
      to: toAddress,
      request: state.trace.request,
      response: state.trace.response,
    });
  }

  return {
    // One hop per call. Returns the hop's lastFrame string, or null when
    // nothing moved (the engine keeps its previous frame then).
    step({ method = 'GET', path = '/about', from = '10.2' } = {}) {
      const split = splitHostPath(path);
      const hosted = stage === 6 && split.hosted;
      // The final hop depends on the path shape: hosted = the Stage 5 chain
      // plus 2 DNS hops; NX ends at the answer hop; host-less = 8, the
      // Stage 5 story unchanged.
      const finalHop = () =>
        stage !== 6
          ? stage === 5
            ? 8
            : stage === 4
              ? 7
              : stage === 3
                ? 6
                : stage === 2
                  ? 5
                  : 4
          : state.trace.nx
            ? 2
            : state.trace.hosted
              ? 10
              : 8;
      // The Stage 2-5 chain runs in chain-space hops: a hosted Stage 6
      // trace rides it with its hop shifted +2 (the DNS prefix came first).
      const inChain = stage === 6 && state.trace.hosted && state.trace.hop >= 3;
      const eStage = stage === 6 ? 5 : stage;
      const hop = inChain ? state.trace.hop - 2 : state.trace.hop;
      const setHop = (chainHop) => {
        state.trace.hop = inChain ? chainHop + 2 : chainHop;
      };
      const { trace } = state;
      let frame = null;
      if (trace.hop === 0 || trace.hop >= finalHop()) {
        state.trace = freshTrace({
          method,
          path,
          from,
          targetServer: stage === 1 ? serverAddress : null,
        });
        state.trace.hop = 1; // the fresh emission is hop 1
        state.served = null;
        if (hosted) {
          // Hop 1/10: the browser asks DNS 10.60 to resolve the host; the
          // resolver lookup runs now and its record is held for the answer.
          frame = dnsPrefix.ask({ from, host: state.trace.host });
        } else {
          frame = `${from} -> ${serverAddress} | ${state.trace.request}`;
        }
      } else if (stage === 1 && hop === 1) {
        setHop(2);
        const atTick = bumpTick();
        network.deliverToQueue({
          id: `you:${atTick}`,
          from: trace.from,
          to: serverAddress,
          request: trace.request,
          atTick,
          isYou: true,
        });
        frame = `routed ${trace.from} -> ${serverAddress} (${trace.request}) into queue`;
      } else if (stage === 1 && hop === 2) {
        setHop(3);
        for (;;) {
          const batch = servers[0].step(getTick());
          const you = batch.find((item) => item.isYou);
          if (you) {
            serve(you);
            frame = `${serverAddress} -> ${trace.from} | ${you.response}`;
          }
          if (you || batch.length === 0) break;
        }
      } else if (stage === 1 && hop === 3) {
        setHop(4);
        finish(serverAddress);
      } else if (stage === 6 && trace.hosted && trace.hop === 1) {
        // Hop 2/10: the resolver answer. NX ends the trace here — the
        // browser renders the NX card and no GET is emitted.
        trace.hop = 2;
        const answer = dnsPrefix.answer({ from: trace.from });
        if (answer.nx) {
          trace.nx = true;
        } else {
          trace.dnsTarget = answer.target;
          trace.dnsSource = answer.source;
        }
        frame = answer.frame;
      } else if (stage === 6 && trace.hosted && trace.hop === 2) {
        // Hop 3/10: with the host resolved the browser emits the GET with
        // the resolved target; the Stage 5 chain takes over from here.
        trace.hop = 3;
        trace.request = `${trace.method} ${trace.resolvedPath}`;
        frame = `${trace.from} -> ${serverAddress} | ${trace.request}`;
      } else {
        frame = chainHop({
          hop,
          eStage,
          state,
          lb,
          cache,
          database,
          workerQueue,
          servers,
          serverAddress,
          bumpTick,
          getTick,
          serve,
          finish,
          setHop,
        });
      }
      return frame;
    },

    snapshot() {
      return { ...state.trace };
    },
  };
}
