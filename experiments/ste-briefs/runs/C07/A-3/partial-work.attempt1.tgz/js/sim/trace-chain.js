// DOCUMENTS: the Stage 2-5 request chain — the hops after the browser's
// emission: the LB's round-robin pick (Stage 2), the cache-aside lookup and
// response emission split (Stage 3), the database hop (Stage 4), and the
// async worker-queue story with its 202 and idle tail (Stage 5). A hosted
// Stage 6 trace rides this same chain with its hop shifted +2 (the DNS
// prefix came first), which is what keeps a host-less Stage 6 story
// byte-identical to Stage 5.
//
// This module owns no state: the trace record and the held served record
// travel in `state`, mutated by reference.
export function chainHop({
  hop,
  eStage,
  state,
  lb,
  cache,
  database,
  workerQueue,
  servers,
  serverAddress,
  bumpTick,
  getTick,
  serve,
  finish,
  setHop,
}) {
  const trace = state.trace;
  if (hop === 1) {
    setHop(2);
    return `routed ${trace.from} -> ${serverAddress} (${trace.request}) to LoadBalancer`;
  }
  if (hop === 2) {
    setHop(3);
    const atTick = bumpTick();
    const target = lb.enqueue({
      id: `you:${atTick}`,
      from: trace.from,
      to: serverAddress,
      request: trace.request,
      atTick,
      isYou: true,
    });
    trace.targetServer = target;
    return `LB ${serverAddress} -> ${target} (${trace.request}) queued`;
  }
  if (eStage === 2 && hop === 3) {
    setHop(4);
    const backend = servers.find((s) => s.address === trace.targetServer) ?? servers[0];
    const you = drainUntilYou(backend, getTick);
    if (you) {
      serve(you);
      return `${backend.address} -> ${trace.from} | ${you.response}`;
    }
    return null;
  }
  if (eStage === 2 && hop === 4) {
    setHop(5);
    finish(trace.targetServer ?? serverAddress);
    return null;
  }
  if (eStage === 3 && hop === 3) {
    // Hop 4/6: the target backend checks Cache and serves the queued
    // request; the response record is held one hop so the learner sees
    // the cache lookup before the response leaves the backend.
    setHop(4);
    const backend = servers.find((s) => s.address === trace.targetServer) ?? servers[0];
    state.served = drainUntilYou(backend, getTick);
    if (state.served) {
      trace.cacheStatus = state.served.cacheStatus ?? null;
      return `${backend.address} -> ${cache.address} | cache ${trace.cacheStatus} (${trace.resolvedPath})`;
    }
    return null;
  }
  if (eStage === 3 && hop === 4) {
    setHop(5);
    if (state.served) {
      serve(state.served);
      return `${trace.targetServer} -> ${trace.from} | ${state.served.response} (${trace.cacheStatus})`;
    }
    return null;
  }
  if (eStage === 3 && hop === 5) {
    setHop(6);
    finish(trace.targetServer ?? serverAddress);
    return null;
  }
  if (eStage === 4 && hop === 3) {
    // Hop 4/7: the target backend checks Cache and serves the queued
    // request (a POST write-through carries cacheStatus INVALIDATE); the
    // response record is held so the learner watches the cache lookup,
    // then the database hop.
    setHop(4);
    const backend = servers.find((s) => s.address === trace.targetServer) ?? servers[0];
    state.served = drainUntilYou(backend, getTick);
    if (state.served) {
      trace.cacheStatus = state.served.cacheStatus ?? null;
      return `${backend.address} -> ${cache.address} | cache ${trace.cacheStatus} (${trace.resolvedPath})`;
    }
    return null;
  }
  if (eStage === 4 && hop === 4) {
    // Hop 5/7: the database hop — hop 6's WRITE landed on Primary 10.30
    // (replication queued toward 10.31), hop 5's SELECT read Replica 10.31
    // fresh or stale, and a warm cache HIT skips the database entirely.
    setHop(5);
    if (state.served) {
      trace.dbOp = state.served.dbOp ?? null;
      trace.dbStale = Boolean(state.served.dbStale);
      if (trace.dbOp === 'WRITE') {
        return `Database WRITE ${trace.resolvedPath} @ ${database.primaryAddress} (replica ${database.replicaAddress} lags ${database.replicationLagTicks}t)`;
      }
      if (trace.dbOp === 'SELECT') {
        return `Database SELECT ${trace.resolvedPath} @ ${database.replicaAddress} (${trace.dbStale ? 'STALE' : 'fresh'})`;
      }
      return `Database SKIP ${trace.resolvedPath} (warm cache HIT @ ${cache.address})`;
    }
    return null;
  }
  if (eStage === 4 && hop === 5) {
    setHop(6);
    if (state.served) {
      serve(state.served);
      return `${trace.targetServer} -> ${trace.from} | ${state.served.response} (cache ${trace.cacheStatus})`;
    }
    return null;
  }
  if (eStage === 4 && hop === 6) {
    setHop(7);
    finish(trace.targetServer ?? serverAddress);
    return null;
  }
  if (eStage === 5 && hop === 3) {
    // Hop 4/8: an async POST /jobs enqueues to WorkerQueue 10.40; other
    // requests narrate the cache/database hop they actually took (the
    // Stage 4 story) — no phantom async jobs on GET traces (DL-4).
    setHop(4);
    const backend = servers.find((s) => s.address === trace.targetServer) ?? servers[0];
    state.served = drainUntilYou(backend, getTick);
    if (state.served) {
      trace.cacheStatus = state.served.cacheStatus ?? null;
      trace.dbOp = state.served.dbOp ?? null;
      trace.dbStale = Boolean(state.served.dbStale);
      trace.asyncJob = Boolean(state.served.asyncJob);
      if (state.served.asyncJob) {
        return `${backend.address} -> ${workerQueue ? workerQueue.address : '10.40'} | enqueued async job (${trace.resolvedPath})`;
      }
      if (trace.dbOp === 'WRITE') {
        return `Database WRITE ${trace.resolvedPath} @ ${database.primaryAddress} (replica ${database.replicaAddress} lags ${database.replicationLagTicks}t)`;
      }
      if (trace.dbOp === 'SELECT') {
        return `Database SELECT ${trace.resolvedPath} @ ${database.replicaAddress} (${trace.dbStale ? 'STALE' : 'fresh'})`;
      }
      return `Database SKIP ${trace.resolvedPath} (warm cache HIT @ ${cache.address})`;
    }
    return null;
  }
  if (eStage === 5 && hop === 4) {
    // Hop 5/8: the webserver answers — an immediate 202 for async jobs,
    // the actually-served response for everything else.
    setHop(5);
    if (state.served) {
      serve(state.served);
      return state.served.asyncJob
        ? `${trace.targetServer} -> ${trace.from} | ${state.served.response}`
        : `${trace.targetServer} -> ${trace.from} | ${state.served.response} (cache ${trace.cacheStatus})`;
    }
    return null;
  }
  if (eStage === 5 && hop === 5) {
    // Hop 6/8: WebServer returns its response via Network
    setHop(6);
    return `Network delivered ${trace.status} response to ${trace.from}`;
  }
  if (eStage === 5 && hop === 6) {
    // Hop 7/8: Browser receives and displays the response
    setHop(7);
    finish(trace.targetServer ?? serverAddress);
    return `Browser ${trace.from} received and displayed ${trace.status}`;
  }
  if (eStage === 5 && hop === 7) {
    // Hop 8/8: async job tails with the worker's commit; a request that
    // was served synchronously finds the worker idle.
    setHop(8);
    const dbTarget = database ? database.primaryAddress : '10.30';
    const workerAddr = workerQueue ? workerQueue.workerAddress : '10.41';
    return trace.asyncJob
      ? `Worker ${workerAddr} finished job and committed to Database ${dbTarget}`
      : `Worker ${workerAddr} idle — no async jobs in this trace`;
  }
  return null;
}

// Serve from the front of the target's queue until the trace's own request
// (isYou) comes back, or the queue runs dry this tick.
function drainUntilYou(targetServer, getTick) {
  for (;;) {
    const batch = targetServer.step(getTick());
    const you = batch.find((item) => item.isYou);
    if (you || batch.length === 0) return you;
  }
}
