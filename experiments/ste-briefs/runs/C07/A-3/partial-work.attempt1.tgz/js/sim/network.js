// DOCUMENTS: the network — the wiring that lets two-number mini-IP
// addressable components exchange messages. Today it carries slim HTTP
// requests to a registered server; later stages attach more components
// without changing the send/enqueue contract, and Stage 6 adds an optional
// router for cross-subnet frames.
//
// CHECKS: every address crossing the wire is validated as a two-number
// mini-IP (<net>.<host>), and sends to unregistered hosts fail loud.
const MINI_IP = /^\d+\.\d+$/;

// `subnet` names this network's own subnet ("10" by default, today's
// behavior); a `router` attached via attachRouter carries cross-subnet
// frames — exactly one router hop — into the destination network. With no
// router attached a cross-subnet destination resolves the old way and fails
// loud when unregistered, so today's send contract is unchanged.
export function createNetwork({ subnet = '10' } = {}) {
  const servers = new Map();
  let router = null;

  function validate(addr) {
    if (!MINI_IP.test(addr)) {
      throw new Error(`network: invalid mini-IP address ${addr}`);
    }
  }

  function resolve(address) {
    validate(address);
    const server = servers.get(address);
    if (!server) {
      throw new Error(`network: no server at ${address}`);
    }
    return server;
  }

  return {
    registerServer(address, server) {
      validate(address);
      servers.set(address, server);
    },

    // Called by the router's join(): only a router attachment turns on
    // cross-subnet sends; nothing about same-subnet traffic changes.
    attachRouter(attached) {
      router = attached;
    },

    resolve,

    send({ from, to, request }) {
      validate(from);
      if (router && MINI_IP.test(to) && to.split('.')[0] !== subnet) {
        return router.route({ from, to, request });
      }
      const server = resolve(to);
      const response = server.handleRequest(request);
      return { from, to, request, response };
    },

    // `isYou` rides through untouched: the engine marks the learner's own
    // interactive-browser request, the server stores it on the queue row.
    deliverToQueue({ id, from, to, request, atTick, isYou = false }) {
      validate(from);
      const server = resolve(to);
      server.enqueue({ id, from, to, request, atTick, isYou });
    },
  };
}
