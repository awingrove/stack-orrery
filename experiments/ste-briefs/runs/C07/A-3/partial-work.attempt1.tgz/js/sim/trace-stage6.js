// DOCUMENTS: the Stage 6 DNS prefix — the two hosted-path hops the browser
// spends resolving a host before the Stage 5 request chain takes over. The
// ask hop performs the real resolver lookup (the tick-TTL cache ledger in
// dns.js) and holds the record; the answer hop narrates the record, or ends
// the trace on NX: no GET is emitted for an unresolved name.
//
// CHECKS: splitHostPath branches on host syntax only — a path whose first
// `/`-segment carries a dot is a hosted URL (`example.com/about`); a plain
// path (`/about`) is host-less and its resolved shape is the path itself.

// Splits a browser URL into its hosted shape. Returns
// `{ hosted, host, path }`: hosted paths name a host before the first `/`,
// host-less paths keep the path untouched (host null).
export function splitHostPath(path = '/') {
  const raw = String(path ?? '/');
  const slashAt = raw.indexOf('/');
  const head = slashAt === -1 ? raw : raw.slice(0, slashAt);
  const rest = slashAt === -1 ? '/' : raw.slice(slashAt);
  if (head && head.includes('.')) {
    return { hosted: true, host: head, path: rest || '/' };
  }
  return { hosted: false, host: null, path: raw };
}

export function createDnsPrefix({ dns, getTick, onFinish }) {
  let record = null;

  return {
    // Hop 1 (the ask): the resolver lookup runs now, the wire frame names
    // the host, and the record is held for the answer hop.
    ask({ from, host }) {
      record = dns ? dns.lookup(host, getTick()) : { status: 'NX', name: host };
      return `${from} -> ${dns.address} | ask ${host}`;
    },

    // Hop 2 (the answer): an OK record names the resolved target and the
    // trace continues into the Stage 5 chain; NX ends the trace here — the
    // browser renders the NX card and no GET is emitted.
    answer({ from }) {
      if (record.status === 'NX') {
        onFinish({
          from: dns.address,
          to: from,
          request: `GET ${record.name}`,
          response: 'NX no record',
        });
        return { frame: `${dns.address} -> ${from} | NX no record`, nx: true };
      }
      return {
        frame: `${dns.address} -> ${from} | OK ${record.name} is ${record.target}`,
        nx: false,
        target: record.target,
        source: record.source,
      };
    },
  };
}
