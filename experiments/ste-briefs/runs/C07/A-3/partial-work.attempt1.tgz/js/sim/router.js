// DOCUMENTS: the Stage 6 component — a router that joins two network
// instances on different subnets (10.x and 20.x). A cross-subnet frame
// takes exactly one router hop: the sending network sees the destination
// subnet differs from its own, hands the frame to `route()`, and the router
// delivers it into the destination network — one `routed` counter step, no
// extra hops. Same-subnet sends never touch the router and are unchanged.
// Nothing lives in subnet 20 in Stage 6a besides the router's own presence,
// so a send to an unregistered 20.x host fails loud from the destination
// network's resolve (DL-1, mirroring network.js).
//
// CHECKS: the constructor rejects an address that is not a two-number
// mini-IP on either side, and both sides sitting on the same subnet.
const MINI_IP = /^\d+\.\d+$/;

export function createRouter({ leftAddress = '10.65', rightAddress = '20.1' } = {}) {
  if (!MINI_IP.test(leftAddress)) {
    throw new Error(`router: invalid mini-IP address ${leftAddress}`);
  }
  if (!MINI_IP.test(rightAddress)) {
    throw new Error(`router: invalid mini-IP address ${rightAddress}`);
  }
  if (leftAddress.split('.')[0] === rightAddress.split('.')[0]) {
    throw new Error(
      `router: left and right sides must sit on different subnets (${leftAddress}, ${rightAddress})`,
    );
  }
  let routed = 0;
  let lastFrame = null;
  let rightNetwork = null;

  // One router hop: the frame exits the left side and enters the right
  // subnet's network instance, where normal resolve rules apply — so
  // unregistered hosts (20.9) fail loud right here, before the hop counts.
  function route({ from, to, request }) {
    if (!rightNetwork) {
      throw new Error('router: no right-side network attached');
    }
    const record = rightNetwork.send({ from, to, request });
    routed += 1;
    lastFrame = `${from} -> ${leftAddress} -> ${to} | ${request} (1 router hop)`;
    return { ...record, viaRouter: leftAddress };
  }

  return {
    get leftAddress() {
      return leftAddress;
    },
    get rightAddress() {
      return rightAddress;
    },

    // Wires both networks: the sending network learns its cross-subnet
    // router; the router's own right side answers in subnet 20 (the only
    // reachable 20.x target in 6a — Stage 6b occupies it with the CDN edge).
    join(leftNetwork, networkOnRight) {
      rightNetwork = networkOnRight;
      leftNetwork.attachRouter(this);
      networkOnRight.registerServer(rightAddress, {
        handleRequest: () => `200 pong from ${rightAddress}`,
      });
    },

    route,

    snapshot() {
      return { leftAddress, rightAddress, routed, lastFrame };
    },
  };
}
