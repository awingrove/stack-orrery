// DOCUMENTS: the Stage 6 inspector code mirrors — DNS (js/sim/dns.js, the
// tick-TTL resolver ledger) and the cross-subnet Router (js/sim/router.js).
// Split from inspector-source.js by responsibility (guard-file-size);
// inspector-source.js merges these into COMPONENT_SOURCE, so the tab
// registry and selectComponent see one map.
export const STAGE6_SOURCE = {
  dns: {
    file: 'js/sim/dns.js',
    title: 'DNS — resolver with tick-TTL ledger',
    code: `createDns({ address = '10.60', ttlTicks = 300 } = {}) {
  // address must be "<net>.<host>" — a two-number mini-IP
  const authoritative = new Map([['example.com', '10.1']]);  // 6b adds a CDN name
  const cache = new Map();  // name -> { name, target, cachedAtTick, expiresAtTick }
  let lookups = 0, cachedHits = 0, authoritativeConsults = 0, nxAnswers = 0;
  function evictExpired(currentTick = 0) {
    for (const entry of cache.values()) {
      if (currentTick >= entry.expiresAtTick) cache.delete(entry.name);
    }
  }
  function lookup(name, currentTick = 0) {
    lookups += 1;
    evictExpired(currentTick);
    const entry = cache.get(name);
    if (entry) {  // cache-branch answer: no authoritative consult
      cachedHits += 1;
      return { status: 'OK', name, target: entry.target, source: 'cache' };
    }
    const target = authoritative.get(name) ?? null;
    if (target === null) {  // NX — the browser renders it, no GET is emitted
      nxAnswers += 1;
      return { status: 'NX', name };
    }
    cache.set(name, { name, target, cachedAtTick: currentTick,
      expiresAtTick: currentTick + ttlTicks });
    return { status: 'OK', name, target, source: 'authoritative' };
  }
  function snapshot(currentTick = 0) {
    evictExpired(currentTick);
    return { address, ttlTicks, lookups, cachedHits, authoritativeConsults,
      nxAnswers, authoritative: Object.fromEntries(authoritative),
      cache: [...cache.values()].map((e) => ({ ...e,
        ttlRemaining: e.expiresAtTick - currentTick })) };
  }
  return { address, evictExpired, lookup, snapshot };
}`,
  },
  router: {
    file: 'js/sim/router.js',
    title: 'Router — cross-subnet gateway',
    code: `createRouter({ leftAddress = '10.65', rightAddress = '20.1' } = {}) {
  // both sides must be "<net>.<host>" mini-IPs on different subnets
  let routed = 0, lastFrame = null, rightNetwork = null;
  function route({ from, to, request }) {
    routed += 1;  // exactly one router hop per cross-subnet frame
    lastFrame = \`\${from} -> \${leftAddress} -> \${to} | \${request} (1 router hop)\`;
    return { ...rightNetwork.send({ from, to, request }), viaRouter: leftAddress };
  }
  return {
    leftAddress, rightAddress,
    join(leftNetwork, networkOnRight) {
      rightNetwork = networkOnRight;
      leftNetwork.attachRouter(this);
      networkOnRight.registerServer(rightAddress, {
        handleRequest: () => \`200 pong from \${rightAddress}\` });
    },
    route,
    snapshot() { return { leftAddress, rightAddress, routed, lastFrame }; },
  };
}`,
  },
};
