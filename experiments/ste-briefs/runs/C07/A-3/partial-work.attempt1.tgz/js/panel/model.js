// DOCUMENTS: pure presentation model — engine snapshot in, labels and bar
// geometry out. No DOM here: this is what the unit suite pins; panel.js and
// render.js own all DOM writes.
export const TICK_MS = 100;
const QUEUE_BAR_SATURATION = 20; // bar reads full at 20 queued requests
// Total hops per stage's trace shape (trace.js and engine.traceHop agree);
// Stage 6 is path-dependent: hosted = 8 + 2 DNS hops, host-less = 8, NX = 2.
const TOTAL_HOPS = { 1: 4, 2: 5, 3: 6, 4: 7, 5: 8 };

// CHECKS: the Stage 6 total branches on the trace's own shape — the named
// counter-example is a host-less GET /about trace, which must keep the
// Stage 5 count (8) and never gain the DNS hops.
export function totalHopsFor(stage, trace = null) {
  if (stage === 6) {
    if (trace?.nx) return 2;
    return trace?.hosted ? 10 : 8;
  }
  return TOTAL_HOPS[stage] ?? 4;
}

const HOP_START_SENTENCE = 'Idle — type a path and click Go or Step 1 Hop ->';

function fillPercent(depth) {
  return `${Math.min(100, Math.round((depth / QUEUE_BAR_SATURATION) * 100))}%`;
}

// One hop-status sentence per hop, in hop order, for each stage's trace
// shape: 4 hops in Stage 1 (emit, route, serve, render), 5 in Stage 2 (LB
// round-robin pick), 6 in Stage 3 (cache check, then response emit), 7 in
// Stage 4 (the database hop after the cache check).
function hopSentences(stage, snapshot, from, serverAddress) {
  const t = snapshot.trace ?? {};
  const target = t.targetServer ?? '10.11';
  // Stage 6 branches on host syntax: an NX trace ends at the DNS answer
  // (no GET is emitted), a hosted trace pays the 2 DNS hops then rides the
  // Stage 5 sentences renumbered +2, and a host-less trace keeps the
  // Stage 5 sentences byte-identical (named counter-example, pinned in
  // test/panel/model-stage6.test.js).
  if (stage === 6) {
    if (t.nx) {
      const dnsAddr = snapshot.dns?.address ?? '10.60';
      return [
        `Hop 1/2: Browser (${from}) asks DNS (${dnsAddr}) to resolve "${t.host}"`,
        `Hop 2/2: DNS (${dnsAddr}) answers NX no record — no GET is emitted`,
      ];
    }
    if (t.hosted) {
      const dnsAddr = snapshot.dns?.address ?? '10.60';
      const source = t.dnsSource === 'cache' ? 'cache' : 'authoritative';
      const chain = hopSentences(5, snapshot, from, serverAddress).map((sentence, i) =>
        sentence.replace(/^Hop \d+\/8:/, `Hop ${i + 3}/10:`),
      );
      return [
        `Hop 1/10: Browser (${from}) asks DNS (${dnsAddr}) to resolve "${t.host}"`,
        `Hop 2/10: DNS (${dnsAddr}) answers "${t.host} is ${t.dnsTarget}" (from ${source})`,
        ...chain,
      ];
    }
    stage = 5;
  }
  if (stage === 5) {
    const worker = snapshot.workerQueue?.workerAddress ?? '10.41';
    if (t.asyncJob) {
      return [
        `Hop 1/8: Browser (${from}) emits "${t.request}"`,
        `Hop 2/8: Network (10.x) routes to LoadBalancer (${serverAddress})`,
        `Hop 3/8: LoadBalancer (${serverAddress}) -> ${target} queue`,
        `Hop 4/8: WebServer (${target}) enqueues job to WorkerQueue (10.40)`,
        `Hop 5/8: WebServer (${target}) -> "202 Accepted"`,
        `Hop 6/8: Network delivers 202 response to ${from}`,
        `Hop 7/8: Browser (${from}) received and displayed 202 Accepted`,
        `Hop 8/8: Worker (${worker}) processed job and committed to Database (10.30)`,
      ];
    }
    // Requests served synchronously keep the Stage 4 cache/database story;
    // the worker does not see them, so the tail hop reads idle.
    const db = snapshot.database ?? {};
    const primary = db.primaryAddress ?? '10.30';
    const replica = db.replicaAddress ?? '10.31';
    const lag = db.replicationLagTicks ?? 3;
    const dbOp =
      t.dbOp === 'WRITE'
        ? `Database WRITE @ Primary (${primary}) — replica lags ${lag}t`
        : t.dbOp === 'SELECT' && t.dbStale
          ? `Database SELECT @ Replica (${replica}) — STALE (lag ${lag}t)`
          : t.dbOp === 'SELECT'
            ? `Database SELECT @ Replica (${replica}) — fresh`
            : `Database SKIP — warm cache HIT (${snapshot.cache?.address ?? '10.20'})`;
    return [
      `Hop 1/8: Browser (${from}) emits "${t.request}"`,
      `Hop 2/8: Network (10.x) routes to LoadBalancer (${serverAddress})`,
      `Hop 3/8: LoadBalancer (${serverAddress}) -> ${target} queue`,
      `Hop 4/8: ${dbOp}`,
      `Hop 5/8: WebServer (${target}) -> "${t.response}" (cache ${t.cacheStatus})`,
      `Hop 6/8: Network delivers ${t.status} response to ${from}`,
      `Hop 7/8: Browser (${from}) received and displayed ${t.status}`,
      `Hop 8/8: Worker (${worker}) idle — no async jobs in this trace`,
    ];
  }
  if (stage === 4) {
    const db = snapshot.database ?? null;
    const primary = db?.primaryAddress ?? '10.30';
    const replica = db?.replicaAddress ?? '10.31';
    const lag = db?.replicationLagTicks ?? 3;
    const dbSentence =
      t.dbOp === 'WRITE'
        ? `Hop 5/7: Database WRITE @ Primary (${primary}) — replica lags ${lag}t`
        : t.dbOp === 'SELECT' && t.dbStale
          ? `Hop 5/7: Database SELECT @ Replica (${replica}) — STALE (lag ${lag}t)`
          : t.dbOp === 'SELECT'
            ? `Hop 5/7: Database SELECT @ Replica (${replica}) — fresh`
            : `Hop 5/7: Database SKIP — warm cache HIT (10.20)`;
    return [
      `Hop 1/7: Browser (${from}) emits "${t.request}"`,
      `Hop 2/7: Network (10.x) routes to LoadBalancer (${serverAddress})`,
      `Hop 3/7: LoadBalancer (${serverAddress}) -> ${target} queue`,
      `Hop 4/7: WebServer (${target}) checks Cache (10.20) — ${t.cacheStatus}`,
      dbSentence,
      `Hop 6/7: WebServer (${target}) -> "${t.response}" (cache ${t.cacheStatus})`,
      `Hop 7/7: Browser (${from}) rendered ${t.status}`,
    ];
  }
  if (stage === 3) {
    return [
      `Hop 1/6: Browser (${from}) emits "${t.request}"`,
      `Hop 2/6: Network (10.x) routes to LoadBalancer (${serverAddress})`,
      `Hop 3/6: LoadBalancer (${serverAddress}) -> ${target} queue`,
      `Hop 4/6: WebServer (${target}) checks Cache (10.20) — ${t.cacheStatus}`,
      `Hop 5/6: WebServer (${target}) -> "${t.response}" (cache ${t.cacheStatus})`,
      `Hop 6/6: Browser (${from}) rendered ${t.status}`,
    ];
  }
  if (stage === 2) {
    return [
      `Hop 1/5: Browser (${from}) emits "${t.request}"`,
      `Hop 2/5: Network (10.x) routes to LoadBalancer (${serverAddress})`,
      `Hop 3/5: LoadBalancer (${serverAddress}) -> ${target} queue`,
      `Hop 4/5: WebServer (${target}) -> "${t.response}"`,
      `Hop 5/5: Browser (${from}) rendered ${t.status}`,
    ];
  }
  return [
    `Hop 1/4: Browser (${from}) emits "${t.request}"`,
    `Hop 2/4: Network (10.x) routes to ${serverAddress} queue`,
    `Hop 3/4: WebServer (${serverAddress}) -> "${t.response}"`,
    `Hop 4/4: Browser (${from}) rendered ${t.status}`,
  ];
}

function formatHopStatus(snapshot, serverAddress) {
  const hop = snapshot.trace?.hop ?? 0;
  const from = snapshot.trace?.from ?? '10.2';
  if (hop >= 1) {
    const sentences = hopSentences(snapshot.stage ?? 1, snapshot, from, serverAddress);
    if (hop <= sentences.length) return sentences[hop - 1];
  }
  return HOP_START_SENTENCE;
}

// PINS: journey-log chronology, as consumed by render.js's #journey-log.
// Entries carry the run key (run, hop): top-down, a run completed later
// floats wholly above a run completed earlier, and inside a run the entries
// sort hop-ascending whatever emission order the trace engine produces —
// a 4-hop trace must never read "hop 2/4" above "hop 1/4" (named
// counter-example, pinned in test/panel/render.test.js).
export function journeyEntryIsBefore(entry, existing) {
  return entry.run > existing.run || (entry.run === existing.run && entry.hop < existing.hop);
}

// Pure insertion into a sorted journey list (no DOM here): returns the
// ordered array with the new entry placed so the run key order holds.
export function orderJourneyEntries(entries, entry) {
  const ordered = [...entries];
  const index = ordered.findIndex((existing) => journeyEntryIsBefore(entry, existing));
  if (index === -1) ordered.push(entry);
  else ordered.splice(index, 0, entry);
  return ordered;
}

export function describeSnapshot(snapshot) {
  const stage = snapshot.stage ?? 1;
  const latencyMs = Math.round(snapshot.avgLatencyTicks * TICK_MS);
  const last = snapshot.lastExchange ?? null;
  const hop = snapshot.trace?.hop ?? 0;
  const serverAddress = snapshot.serverAddress ?? '10.1';
  const s1Depth = snapshot.servers?.[0]?.queueDepth ?? snapshot.queueDepth;
  const s2Depth = snapshot.servers?.[1]?.queueDepth ?? 0;
  const perBackend = snapshot.loadBalancer?.perBackend ?? {}; // CHECKS: per-tick throughput is served/tick while the clock runs and
  // exactly 0 at tick 0 — the SERVED card renders "0.00/t", never NaN or
  // Infinity (named counter-example: a fresh Stage-1 panel at tick 0).
  const servedPerTick = snapshot.tick > 0 ? (snapshot.served ?? 0) / snapshot.tick : 0;
  return {
    stage,
    totalHops: totalHopsFor(stage, snapshot.trace),
    tick: String(snapshot.tick),
    users: String(snapshot.users),
    queueDepth: String(snapshot.queueDepth),
    served: String(snapshot.served),
    servedRate: `${servedPerTick.toFixed(2)}/t`,
    latency: `${latencyMs} ms`,
    queueFill: fillPercent(snapshot.queueDepth),
    queueFill1: fillPercent(s1Depth),
    queueFill2: fillPercent(s2Depth),
    serverAddress,
    server1Address: snapshot.servers?.[0]?.address ?? serverAddress,
    server2Address: snapshot.servers?.[1]?.address ?? '10.12',
    lbNextBackend: snapshot.loadBalancer
      ? `Next -> ${snapshot.loadBalancer.nextBackend}`
      : 'Next -> 10.11',
    lbBackend1Label: `10.11 WebServer-1 (${perBackend['10.11'] ?? 0})`,
    lbBackend2Label: `10.12 WebServer-2 (${perBackend['10.12'] ?? 0})`,
    cacheStatsLabel: `Hits: ${snapshot.cache?.hits ?? 0} · Misses: ${snapshot.cache?.misses ?? 0} · TTL: ${snapshot.cache?.ttlTicks ?? 10}t`,
    cacheEntries: snapshot.cache?.entries ?? [],
    dbStatsLabel: `Reads: ${snapshot.database?.reads ?? 0} · Writes: ${snapshot.database?.writes ?? 0} · Lag: ${snapshot.database?.replicationLagTicks ?? 3}t`,
    dbRows: snapshot.database?.rows ?? [],
    queueStatsLabel: snapshot.workerQueue
      ? `Enqueued: ${snapshot.workerQueue.enqueued} · Completed: ${snapshot.workerQueue.completed} · Active: ${
          snapshot.workerQueue.activeJob
            ? `#${snapshot.workerQueue.activeJob.jobId} ${snapshot.workerQueue.activeJob.path}`
            : 'none'
        }`
      : 'Enqueued: 0 · Completed: 0 · Active: none',
    workerStatsLabel: snapshot.workerQueue
      ? snapshot.workerQueue.activeJob
        ? `Worker ${snapshot.workerQueue.workerAddress} processing #${snapshot.workerQueue.activeJob.jobId} (${snapshot.workerQueue.activeJob.path})`
        : `Worker ${snapshot.workerQueue.workerAddress} Idle`
      : 'Worker 10.41 Idle',
    queueJobs: snapshot.workerQueue?.pendingJobs ?? [],
    // Stage 6: the DNS ledger trio and the resolver-cache rows, plus the
    // Router's one-hop cross-subnet counter (DESIGN.md #node-dns/#node-router).
    dnsStatsLabel: snapshot.dns
      ? `Lookups: ${snapshot.dns.lookups} · Cached hits: ${snapshot.dns.cachedHits} · TTL: ${snapshot.dns.ttlTicks}t`
      : 'Lookups: 0 · Cached hits: 0 · TTL: 300t',
    dnsEntries: snapshot.dns?.cache ?? [],
    routerStatsLabel: snapshot.router
      ? `Routed: ${snapshot.router.routed} · ${snapshot.router.leftAddress} ⇄ ${snapshot.router.rightAddress}`
      : 'Routed: 0 · 10.65 ⇄ 20.1',
    exchangeSummary: last
      ? `${last.from} -> ${last.to} ${last.request} => ${last.response}`
      : 'No requests served yet',
    hop,
    hopStatus: formatHopStatus(snapshot, serverAddress),
    browserStatus: snapshot.browserDisplay
      ? `${snapshot.browserDisplay.status} (${snapshot.browserDisplay.request})`
      : 'No response yet',
    browserBody: snapshot.browserDisplay
      ? snapshot.browserDisplay.body
      : 'Send a request or step a hop to render a response.',
    networkLastFrame: snapshot.lastFrame ?? 'No frames routed yet',
    matchedRouteId: snapshot.lastMatchedRoute ?? null,
  };
}
