// DOCUMENTS: the Stage 6 node cards — #node-dns (resolver 10.60 with its
// lookup/hit counters and live resolver-cache rows) and #node-router (the
// cross-subnet gateway card with the `10.65 ⇄ 20.1` ip-chip and routed
// counter). Built in js rather than panel.html because that page sits at
// its 550-line cap (the teaching drawer set the precedent); behavior stays
// addEventListener-only and all content comes from textContent/attributes —
// no inline styles, no innerHTML (AGENTS.md CSP rule). panel.js runs this
// at boot, before the .node-card / .comp-tab bindings, so the standard
// selection and inspector wiring picks the cards up unchanged.
import { COMPONENT_SOURCE } from './inspector-source.js';

const IP_CHIP = { dns: '10.60', router: '10.65 ⇄ 20.1' };
const SUBTITLES = {
  dns: ['DNS', 'resolver · tick-TTL ledger'],
  router: ['Router', 'cross-subnet gateway'],
};

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function buildCard(component) {
  const card = el('article', 'node-card');
  card.id = `node-${component}`;
  card.dataset.testid = `node-${component}`;
  card.dataset.component = component;
  card.hidden = true; // revealed by render-stage on Stage 6
  const head = el('header', 'node-head');
  const name = el('div', 'node-name');
  name.append(
    el('span', 'role-name', SUBTITLES[component][0]),
    el('span', 'node-subtitle', SUBTITLES[component][1]),
  );
  head.append(name, el('span', 'ip-chip', IP_CHIP[component]), el('span', 'code-chip', '</> Code'));
  card.append(head);
  if (component === 'dns') {
    const stats = el('p', 'mono last-frame', 'Lookups: 0 · Cached hits: 0 · TTL: 300t');
    stats.id = 'dns-stats';
    stats.dataset.testid = 'dns-stats';
    const entries = el('ul', 'route-list');
    entries.id = 'dns-entries-list';
    entries.dataset.testid = 'dns-entries-list';
    entries.setAttribute('aria-label', 'Resolver cache');
    card.append(stats, entries);
  } else {
    const stats = el('p', 'mono last-frame', 'Routed: 0 · 10.65 ⇄ 20.1');
    stats.id = 'router-stats';
    stats.dataset.testid = 'router-stats';
    card.append(stats);
  }
  return card;
}

// CHECKS: the card ids, data-testid anchors, and the stats/entries element
// ids are the registry names — dns and router have no static panel.html
// card (that page sits at its 550-line cap), so this module mints exactly
// those two; a mismatch is caught by the Stage 6 e2e pins.
const NEW_CARDS = ['dns', 'router'];

export function initStage6Nodes() {
  const world = document.getElementById('orrery-world');
  for (const component of NEW_CARDS) {
    if (!document.getElementById(`node-${component}`)) {
      world.append(buildCard(component));
    }
  }
  // The inspector tabs derive from the same registry, replacing panel
  // html's static button list (the page sits at its 550-line cap).
  const tabHost = document.querySelector('.comp-tabs');
  if (tabHost && tabHost.children.length === 0) {
    for (const key of Object.keys(COMPONENT_SOURCE)) {
      const tab = el('button', 'comp-tab', key);
      tab.type = 'button';
      tab.dataset.select = key;
      tabHost.append(tab);
    }
  }
}
