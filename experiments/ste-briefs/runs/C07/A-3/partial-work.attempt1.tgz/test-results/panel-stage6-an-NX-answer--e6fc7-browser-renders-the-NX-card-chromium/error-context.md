# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: panel-stage6.spec.js >> an NX answer never emits a GET — the browser renders the NX card
- Location: e2e/panel-stage6.spec.js:115:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByTestId('hop-status')
Expected substring: "Hop 1/2: Browser (10.2) asks DNS (10.60) to resolve \"nope.example\""
Received string:    "Hop 1/10: Browser (10.2) asks DNS (10.60) to resolve \"nope.example\""
Timeout: 5000ms

Call log:
  - Expect "toContainText" getByTestId('hop-status') with timeout 5000ms
  - waiting for getByTestId('hop-status')
    14 × locator resolved to <span id="hop-status" class="hop-status" data-testid="hop-status">Hop 1/10: Browser (10.2) asks DNS (10.60) to reso…</span>
       - unexpected value "Hop 1/10: Browser (10.2) asks DNS (10.60) to resolve "nope.example""

```

```yaml
- text: "Hop 1/10: Browser (10.2) asks DNS (10.60) to resolve \"nope.example\""
```

# Test source

```ts
  19  |   await expect(page.locator('.orrery-ring')).toHaveCount(8);
  20  |   await expect(page.locator('.orrery-ring').first()).toHaveAttribute('r', '400');
  21  |   await expect(page.locator('.orrery-ring').last()).toHaveAttribute('r', '3200');
  22  |   await expect(page.getByTestId('dns-stats')).toHaveText(
  23  |     'Lookups: 0 · Cached hits: 0 · TTL: 300t',
  24  |   );
  25  |   await expect(page.getByTestId('router-stats')).toHaveText('Routed: 0 · 10.65 ⇄ 20.1');
  26  | 
  27  |   // First hosted trace: the cold lookup consults the authoritative table
  28  |   // and warms the ledger (Lookups 1, Cached hits 0).
  29  |   await page.getByTestId('url-input').fill('example.com/about');
  30  |   for (let hop = 0; hop < 10; hop++) await page.getByTestId('btn-next-hop').click();
  31  |   await expect(page.getByTestId('hop-status')).toContainText('Hop 10/10');
  32  |   await expect(page.getByTestId('browser-rendered-body')).toHaveText('This is the about page');
  33  |   await expect(page.getByTestId('dns-stats')).toHaveText(
  34  |     'Lookups: 1 · Cached hits: 0 · TTL: 300t',
  35  |   );
  36  |   await expect(page.getByTestId('dns-entries-list')).toContainText('example.com -> 10.1');
  37  | 
  38  |   // Second hosted trace: the ledger answers — Cached hits climbs without a
  39  |   // second authoritative consult (the TTL-branch counter-example, narrated
  40  |   // hop 2/10 in the DNS-ask spec below).
  41  |   for (let hop = 0; hop < 10; hop++) await page.getByTestId('btn-next-hop').click();
  42  |   await expect(page.getByTestId('dns-stats')).toHaveText(
  43  |     'Lookups: 2 · Cached hits: 1 · TTL: 300t',
  44  |   );
  45  | 
  46  |   await page.getByTestId('node-dns').click();
  47  |   await expect(page.getByTestId('inspector-code')).toContainText('createDns');
  48  |   await expect(page.getByTestId('inspector-state')).toContainText('"cachedHits": 1');
  49  |   await expect(page.getByTestId('inspector-state')).toContainText('"authoritativeConsults": 1');
  50  | 
  51  |   await page.getByTestId('node-router').click();
  52  |   await expect(page.getByTestId('inspector-code')).toContainText('createRouter');
  53  |   await expect(page.getByTestId('inspector-state')).toContainText('"routed": 0');
  54  | });
  55  | 
  56  | test('should trace example.com/about with DNS ask + answer hops', async ({ page }) => {
  57  |   await page.goto('/panel.html?stage=6');
  58  |   await page.getByTestId('url-input').fill('example.com/about');
  59  | 
  60  |   // Hop 1: the browser asks DNS 10.60 to resolve the host; the ledger warms.
  61  |   await page.getByTestId('btn-next-hop').click();
  62  |   await expect(page.getByTestId('hop-status')).toContainText(
  63  |     'Hop 1/10: Browser (10.2) asks DNS (10.60) to resolve "example.com"',
  64  |   );
  65  |   // Hop 2: the resolver answer names the target and rides into the journey log.
  66  |   await page.getByTestId('btn-next-hop').click();
  67  |   await expect(page.getByTestId('hop-status')).toHaveText(
  68  |     'Hop 2/10: DNS (10.60) answers "example.com is 10.1" (from authoritative)',
  69  |   );
  70  |   await expect(page.getByTestId('journey-log')).toContainText('10.60 -> 10.2 | OK example.com is 10.1');
  71  |   // Hop 3: the resolved GET leaves the browser toward 10.1.
  72  |   await page.getByTestId('btn-next-hop').click();
  73  |   await expect(page.getByTestId('hop-status')).toContainText(
  74  |     'Hop 3/10: Browser (10.2) emits "GET /about"',
  75  |   );
  76  | 
  77  |   for (let hop = 0; hop < 7; hop++) await page.getByTestId('btn-next-hop').click();
  78  |   await expect(page.getByTestId('browser-status-badge')).toContainText('200 (GET /about)');
  79  |   const labels = await page.getByTestId('journey-log').locator('.journey-entry').allTextContents();
  80  |   const hopRows = labels.map((text) => text.match(/^(hop \d+\/10)/)?.[1]);
  81  |   expect(hopRows.slice(0, 3)).toEqual(['hop 1/10', 'hop 2/10', 'hop 3/10']);
  82  | });
  83  | 
  84  | test('should keep GET /about on Stage 6 at the Stage 5 hop story', async ({ page }) => {
  85  |   // Named counter-example pinned for the trace-branch contract (stage6a
  86  |   // brief): a plain path on Stage 6 walks the Stage 5 8-hop story — no DNS
  87  |   // hop, no cross-subnet hop, no ledger activity.
  88  |   await page.goto('/panel.html?stage=6');
  89  |   await page.getByTestId('url-input').fill('/about');
  90  |   for (let hop = 0; hop < 8; hop++) await page.getByTestId('btn-next-hop').click();
  91  | 
  92  |   await expect(page.getByTestId('hop-status')).toContainText('Hop 8/8');
  93  |   await expect(page.getByTestId('hop-status')).toContainText(
  94  |     'Hop 8/8: Worker (10.41) idle — no async jobs in this trace',
  95  |   );
  96  |   await expect(page.getByTestId('browser-rendered-body')).toHaveText('This is the about page');
  97  |   await expect(page.getByTestId('dns-stats')).toHaveText(
  98  |     'Lookups: 0 · Cached hits: 0 · TTL: 300t',
  99  |   );
  100 |   const labels = await page.getByTestId('journey-log').locator('.journey-entry').allTextContents();
  101 |   expect(labels.map((text) => text.match(/^(hop \d+\/8)/)?.[1]).slice(0, 8)).toEqual([
  102 |     'hop 1/8',
  103 |     'hop 2/8',
  104 |     'hop 3/8',
  105 |     'hop 4/8',
  106 |     'hop 5/8',
  107 |     'hop 6/8',
  108 |     'hop 7/8',
  109 |     'hop 8/8',
  110 |   ]);
  111 |   await expect(page.getByTestId('journey-log')).not.toContainText('10.60');
  112 |   await expect(page.getByTestId('journey-log')).not.toContainText('ask ');
  113 | });
  114 | 
  115 | test('an NX answer never emits a GET — the browser renders the NX card', async ({ page }) => {
  116 |   await page.goto('/panel.html?stage=6');
  117 |   await page.getByTestId('url-input').fill('nope.example/about');
  118 |   await page.getByTestId('btn-next-hop').click();
> 119 |   await expect(page.getByTestId('hop-status')).toContainText(
      |                                                ^ Error: expect(locator).toContainText(expected) failed
  120 |     'Hop 1/2: Browser (10.2) asks DNS (10.60) to resolve "nope.example"',
  121 |   );
  122 |   await page.getByTestId('btn-next-hop').click();
  123 |   await expect(page.getByTestId('hop-status')).toHaveText(
  124 |     'Hop 2/2: DNS (10.60) answers NX no record — no GET is emitted',
  125 |   );
  126 |   await expect(page.getByTestId('browser-status-badge')).toHaveText('NX (GET nope.example)');
  127 |   await expect(page.getByTestId('browser-rendered-body')).toHaveText('no record');
  128 |   await expect(page.getByTestId('dns-stats')).toHaveText(
  129 |     'Lookups: 1 · Cached hits: 0 · TTL: 300t',
  130 |   );
  131 |   const labels = await page.getByTestId('journey-log').locator('.journey-entry').allTextContents();
  132 |   expect(labels.some((text) => /GET nope/.test(text))).toBe(false);
  133 | });
  134 | 
  135 | test('should deep-link ?stage=6 to the live stage 6 and fall back on unknown values', async ({
  136 |   page,
  137 | }) => {
  138 |   const errors = [];
  139 |   page.on('pageerror', (error) => errors.push(error));
  140 |   page.on('console', (msg) => {
  141 |     if (msg.type() === 'error') errors.push(msg.text());
  142 |   });
  143 |   await page.goto('/panel.html?stage=6');
  144 |   await expect(page.getByTestId('stage-pill-6')).toHaveAttribute('aria-current', 'true');
  145 |   await expect(page.getByTestId('node-dns')).toBeVisible();
  146 |   await expect(page).toHaveURL(/stage=6/);
  147 |   // Unknown values still fall back to Stage 1 without a console error.
  148 |   await page.goto('/panel.html?stage=9');
  149 |   await expect(page.getByTestId('stage-pill-1')).toHaveAttribute('aria-current', 'true');
  150 |   await expect(page.getByTestId('server-address')).toHaveText('10.1');
  151 |   expect(errors).toEqual([]);
  152 | });
  153 | 
```