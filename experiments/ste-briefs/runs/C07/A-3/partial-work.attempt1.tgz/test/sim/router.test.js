import { describe, it, expect } from 'vitest';
import { createNetwork } from '../../js/sim/network.js';
import { createRouter } from '../../js/sim/router.js';
import { createWebServer } from '../../js/sim/webserver.js';

describe('createRouter', () => {
  it('same-subnet sends are unchanged by the attached router', () => {
    const net10 = createNetwork();
    const router = createRouter({ leftAddress: '10.65', rightAddress: '20.1' });
    router.join(net10, createNetwork({ subnet: '20' }));
    net10.registerServer('10.1', createWebServer({ address: '10.1' }));
    expect(net10.send({ from: '10.2', to: '10.1', request: 'GET /about' })).toEqual({
      from: '10.2',
      to: '10.1',
      request: 'GET /about',
      response: '200 This is the about page',
    });
    // The router never saw the frame: same-subnet traffic bypasses it.
    expect(router.snapshot().routed).toBe(0);
  });

  it('a cross-subnet frame takes exactly one router hop through 10.65 ⇄ 20.1', () => {
    const net10 = createNetwork();
    const net20 = createNetwork({ subnet: '20' });
    const router = createRouter();
    router.join(net10, net20);
    const record = net10.send({ from: '10.2', to: '20.1', request: 'GET /' });
    // The router's own 20-side answers — the only reachable 20.x target in
    // 6a (Stage 6b occupies 20.1 with the CDN edge).
    expect(record).toEqual({
      from: '10.2',
      to: '20.1',
      request: 'GET /',
      response: '200 pong from 20.1',
      viaRouter: '10.65',
    });
    expect(router.snapshot().routed).toBe(1);
    expect(router.snapshot().lastFrame).toBe('10.2 -> 10.65 -> 20.1 | GET / (1 router hop)');
    // A second frame counts its own hop.
    net10.send({ from: '10.2', to: '20.1', request: 'GET /about' });
    expect(router.snapshot().routed).toBe(2);
  });

  it('a send into subnet 20 to an unregistered host fails loud', () => {
    // Named counter-example pinned for the cross-subnet branch (stage6a
    // brief): 20.9 is unregistered in 6a, so the frame throws from the
    // destination network's resolve — the DL-1 fail-loud rule, mirroring
    // the 10.x behavior.
    const net10 = createNetwork();
    const router = createRouter();
    router.join(net10, createNetwork({ subnet: '20' }));
    expect(() => net10.send({ from: '10.2', to: '20.9', request: 'GET /' })).toThrow(
      /no server at 20\.9/,
    );
    expect(router.snapshot().routed).toBe(0); // the throw precedes the hop
  });

  it('a cross-subnet send without a router keeps the no-server failure', () => {
    const net10 = createNetwork();
    expect(() => net10.send({ from: '10.2', to: '20.1', request: 'GET /' })).toThrow(
      /no server at 20\.1/,
    );
  });

  it('constructor validates both sides as mini-IPs on different subnets', () => {
    expect(() => createRouter({ leftAddress: '10' })).toThrow(/mini-IP address 10\b/);
    expect(() => createRouter({ rightAddress: '201' })).toThrow(/mini-IP/);
    expect(() =>
      createRouter({ leftAddress: '10.65', rightAddress: '10.9' }),
    ).toThrow(/different subnets/);
  });
});
