import { describe, it, expect } from 'vitest';
import { createEngine } from '../../js/sim/engine.js';

describe('createEngine — Stage 6 (DNS + cross-subnet Router)', () => {
  it('stage 6 traces example.com/about through the DNS ask and answer hops', () => {
    const engine = createEngine({ seed: 1, stage: 6 });
    const frames = [];
    for (let i = 0; i < 12; i += 1) {
      const snap = engine.traceHop({ method: 'GET', path: 'example.com/about' });
      frames.push(snap.lastFrame);
      if (snap.trace.hop >= 10) break;
    }
    // Hop 1 is the DNS ask; hop 2 the resolver answer naming the target;
    // hops 3-10 are the Stage 5 chain with the resolved GET.
    expect(frames.slice(0, 3)).toEqual([
      '10.2 -> 10.60 | ask example.com',
      '10.60 -> 10.2 | OK example.com is 10.1',
      '10.2 -> 10.1 | GET /about',
    ]);
    expect(frames[4]).toBe('LB 10.1 -> 10.11 (GET /about) queued');
    expect(frames[9]).toBe('Worker 10.41 idle — no async jobs in this trace');
    const snap = engine.snapshot();
    expect(snap.trace.hop).toBe(10);
    expect(snap.trace.hosted).toBe(true);
    expect(snap.trace.dnsTarget).toBe('10.1');
    // The hosted trace consulted the authoritative table once and warmed
    // the ledger; the browser rendered the resolved GET.
    expect(snap.dns.lookups).toBe(1);
    expect(snap.dns.cachedHits).toBe(0);
    expect(snap.dns.cache[0]).toMatchObject({ name: 'example.com', target: '10.1' });
    expect(snap.browserDisplay).toMatchObject({ request: 'GET /about', status: 200 });
    expect(snap.router).toEqual({
      leftAddress: '10.65',
      rightAddress: '20.1',
      routed: 0,
      lastFrame: null,
    });
  });

  it('a second hosted lookup answers from the cache ledger, not the table', () => {
    const engine = createEngine({ seed: 1, stage: 6 });
    for (let i = 0; i < 10; i += 1) engine.traceHop({ path: 'example.com/about' });
    for (let i = 0; i < 10; i += 1) {
      const snap = engine.traceHop({ path: 'example.com/about' });
      if (snap.trace.hop === 2) {
        expect(snap.lastFrame).toBe('10.60 -> 10.2 | OK example.com is 10.1');
        expect(snap.trace.dnsSource).toBe('cache');
      }
      if (snap.trace.hop >= 10) break;
    }
    const snap = engine.snapshot();
    expect(snap.dns.lookups).toBe(2);
    expect(snap.dns.cachedHits).toBe(1);
    expect(snap.dns.authoritativeConsults).toBe(1);
  });

  it('stage 6 keeps a host-less GET /about at the byte-identical Stage 5 hop story', () => {
    // Named counter-example pinned for the trace-branch contract (stage6a
    // brief): a plain path on Stage 6 must produce exactly the Stage 5
    // frames, hop count, and DNS silence — no DNS hop, no cross-subnet hop.
    const runFrames = (stage) => {
      const engine = createEngine({ seed: 1, stage });
      const frames = [];
      for (let i = 0; i < 12; i += 1) {
        const snap = engine.traceHop({ method: 'GET', path: '/about' });
        frames.push(snap.lastFrame);
        if (snap.trace.hop >= 8) break;
      }
      return { frames, snap: engine.snapshot() };
    };
    const stage5 = runFrames(5);
    const stage6 = runFrames(6);
    expect(stage6.frames).toEqual(stage5.frames);
    expect(stage6.snap.trace.hop).toBe(stage5.snap.trace.hop);
    expect(stage6.snap.dns.lookups).toBe(0);
    expect(stage6.snap.dns.cache).toEqual([]);
    expect(stage6.snap.router.routed).toBe(0);
  });

  it('nope.example/about never emits a GET — DNS ask + NX no record only', () => {
    // Named counter-example pinned for the unknown-name branch (stage6a
    // brief): the trace ends at the NX answer, no frame carries a GET, and
    // the browser renders the NX card instead of a response body.
    const engine = createEngine({ seed: 1, stage: 6 });
    const frames = [];
    for (let i = 0; i < 12; i += 1) {
      const snap = engine.traceHop({ method: 'GET', path: 'nope.example/about' });
      frames.push(snap.lastFrame);
      if (snap.trace.hop >= 2) break;
    }
    expect(frames).toEqual(['10.2 -> 10.60 | ask nope.example', '10.60 -> 10.2 | NX no record']);
    const snap = engine.snapshot();
    expect(snap.trace.hop).toBe(2);
    expect(snap.trace.nx).toBe(true);
    expect(snap.dns.nxAnswers).toBe(1);
    // No request was enqueued or served anywhere: no GET was emitted.
    expect(snap.served).toBe(0);
    expect(snap.queueDepth).toBe(0);
    expect(snap.browserDisplay).toEqual({
      from: '10.60',
      to: '10.2',
      request: 'GET nope.example',
      response: 'NX no record',
      status: 'NX',
      body: 'no record',
    });
  });

  it('exposes the DNS and Router snapshots, validates stages 1-6, and fails loud on bad wiring', () => {
    for (const stage of [1, 2, 3, 4, 5]) {
      const snap = createEngine({ seed: 1, stage, arrivalProb: 0 }).snapshot();
      expect(snap.dns).toBe(null);
      expect(snap.router).toBe(null);
    }
    const snap = createEngine({ seed: 1, stage: 6, arrivalProb: 0 }).snapshot();
    expect(snap.dns.address).toBe('10.60');
    expect(snap.router.leftAddress).toBe('10.65');
    expect(() => createEngine({ stage: 7 })).toThrow(/stage must be 1, 2, 3, 4, 5, or 6/);
    expect(() => createEngine({ stage: 0 })).toThrow(/stage must be 1, 2, 3, 4, 5, or 6/);
  });
});
