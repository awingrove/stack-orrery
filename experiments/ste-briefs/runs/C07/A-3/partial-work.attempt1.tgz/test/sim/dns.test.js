import { describe, it, expect } from 'vitest';
import { createDns } from '../../js/sim/dns.js';

describe('createDns', () => {
  it('resolves example.com from the authoritative table and caches it for ttlTicks', () => {
    const dns = createDns({ ttlTicks: 300 });
    // Cold lookup: the authoritative table answers and the ledger warms.
    const first = dns.lookup('example.com', 0);
    expect(first).toEqual({
      status: 'OK',
      name: 'example.com',
      target: '10.1',
      source: 'authoritative',
    });
    const warm = dns.snapshot(0);
    expect(warm.lookups).toBe(1);
    expect(warm.authoritativeConsults).toBe(1);
    expect(warm.cache[0]).toMatchObject({
      name: 'example.com',
      target: '10.1',
      expiresAtTick: 300,
      ttlRemaining: 300,
    });
  });

  it('a hit inside ttlTicks increments cachedHits with no authoritative consult', () => {
    // Named counter-example pinned for the TTL branch (stage6a brief): the
    // ledger answers the warm lookup and the authoritative table is never
    // re-consulted while the entry is alive.
    const dns = createDns({ ttlTicks: 300 });
    dns.lookup('example.com', 0);
    const second = dns.lookup('example.com', 299); // the last tick inside TTL
    expect(second).toEqual({
      status: 'OK',
      name: 'example.com',
      target: '10.1',
      source: 'cache',
    });
    const snap = dns.snapshot(299);
    expect(snap.cachedHits).toBe(1);
    expect(snap.authoritativeConsults).toBe(1); // unchanged: no consult on hit
    expect(snap.lookups).toBe(2);
  });

  it('an expired entry is never answered from the ledger', () => {
    // Named counter-example pinned for the TTL branch (stage6a brief): the
    // entry dies at expiresAtTick and the authoritative table answers again.
    const dns = createDns({ ttlTicks: 5 });
    dns.lookup('example.com', 0);
    const expired = dns.lookup('example.com', 5); // tick 5 >= expiresAtTick 5
    expect(expired.source).toBe('authoritative');
    const snap = dns.snapshot(5);
    expect(snap.cachedHits).toBe(0);
    expect(snap.authoritativeConsults).toBe(2);
    // The fresh entry carries the new expiry, not the stale one.
    expect(snap.cache[0]).toMatchObject({ expiresAtTick: 10, cachedAtTick: 5 });
  });

  it('unknown names answer NX — never a throw at the DNS layer', () => {
    const dns = createDns();
    expect(dns.lookup('nope.example', 0)).toEqual({ status: 'NX', name: 'nope.example' });
    const snap = dns.snapshot(0);
    expect(snap.nxAnswers).toBe(1);
    expect(snap.cache).toEqual([]);
    expect(snap.authoritative).toEqual({ 'example.com': '10.1' });
  });

  it('rejects a non mini-IP address and a ttlTicks that is not a positive integer', () => {
    expect(() => createDns({ address: '10' })).toThrow(/mini-IP address 10\b/);
    expect(() => createDns({ address: '1060' })).toThrow(/mini-IP/);
    expect(() => createDns({ ttlTicks: 0 })).toThrow(/ttlTicks/);
    expect(() => createDns({ ttlTicks: 2.5 })).toThrow(/ttlTicks/);
    expect(() => createDns({ ttlTicks: -3 })).toThrow(/ttlTicks/);
  });
});
