import { describe, it, expect } from 'vitest';
import { computeStageLayout, buildOrreryRings, DEFAULT_RING_GAP } from '../../js/panel/layout.js';

// Stage-boundary extraction from camera.test.js (guard-file-size): the
// Stage 6 eight-ring orrery registry is pinned here so camera.test.js stays
// inside the 450-line test cap.
describe('orrery layout — Stage 6', () => {
  it('lays out the eight-ring Stage 6 orrery with DNS on Ring 7 and the Router beside the 10.x hub', () => {
    expect(DEFAULT_RING_GAP).toBe(400);
    const stage6 = computeStageLayout(6, 5);
    // 8 layers -> 8 rings; DNS takes Ring 7, browsers move out to Ring 8.
    expect(stage6.rings.map((r) => r.radius)).toEqual([
      400, 800, 1200, 1600, 2000, 2400, 2800, 3200,
    ]);
    expect(stage6.rings.map((r) => r.id)).toEqual([
      'ring-db',
      'ring-workers',
      'ring-cache',
      'ring-compute',
      'ring-lb',
      'ring-network',
      'ring-dns',
      'ring-clients',
    ]);
    expect(buildOrreryRings(400, 6).at(-2)).toMatchObject({ id: 'ring-dns', radius: 2800 });
    expect(stage6.nodes['node-dns']).toMatchObject({
      radius: 2800,
      ring: 'ring-dns',
      x: -2800,
      y: 0,
    });
    // The Router side-card rides the network ring beside the 10.x hub
    // (hub at 180°, router at 210°).
    expect(stage6.nodes['node-router']).toMatchObject({ radius: 2400, ring: 'ring-network' });
    expect(stage6.nodes['node-router'].angleDeg).toBe(210);
    for (const node of Object.values(stage6.nodes)) {
      expect(node.radius).toBeGreaterThan(0);
      expect(node.x !== 0 || node.y !== 0).toBe(true);
    }
    // The Stage 5 wires all survive, plus the DNS and Router spokes.
    expect(stage6.wires.map((w) => w.id)).toEqual([
      'wire-browser-network',
      'wire-network-lb',
      'wire-lb-webserver',
      'wire-lb-webserver-2',
      'wire-webserver-cache',
      'wire-webserver-2-cache',
      'wire-cache-db',
      'wire-cache-queue',
      'wire-queue-worker',
      'wire-worker-db',
      'wire-network-dns',
      'wire-network-router',
    ]);
    expect(stage6.wires.at(-2)).toMatchObject({ x2: -2800, y2: 0 });
    // The bounds clear the outer 3200 ring; the fit routine stays inside
    // the camera's clamped world frame.
    expect(stage6.bounds).toEqual({ minX: -3380, maxX: 120, minY: -540, maxY: 540 });
    // A tuned ring gap rescales the eight rings as r_k = k * ringGap.
    const tuned = computeStageLayout(6, 5, { ringGap: 300 });
    expect(tuned.rings.map((r) => r.radius)).toEqual([300, 600, 900, 1200, 1500, 1800, 2100, 2400]);
    expect(tuned.nodes['node-dns']).toMatchObject({ x: -2100, y: 0, radius: 2100 });
    // CHECKS: 6 is the last shipped stage — 7 still fails loud.
    expect(() => computeStageLayout(7)).toThrow(/stage/);
    expect(() => buildOrreryRings(400, 7)).toThrow(/stage/);
  });
});
