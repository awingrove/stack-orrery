import { describe, it, expect } from 'vitest';
import { describeSnapshot, totalHopsFor } from '../../js/panel/model.js';
import { componentTitle, formatComponentState } from '../../js/panel/inspector-state.js';

// Stage-boundary extraction from model.test.js (guard-file-size): the
// Stage 6 DNS/router narrative branches and inspector state are pinned here
// so model.test.js and model-stage5.test.js stay inside the 450-line test
// cap. The trace-side counter-examples these sentences narrate are pinned
// in test/sim/engine-stage6.test.js.
const baseServers = [
  { address: '10.11', queueDepth: 0, served: 1, queue: [] },
  { address: '10.12', queueDepth: 0, served: 1, queue: [] },
];
const baseWorkerQueue = {
  address: '10.40',
  workerAddress: '10.41',
  jobDurationTicks: 2,
  enqueued: 0,
  completed: 0,
  activeJob: null,
  pendingJobs: [],
  lastJobResult: null,
};
const baseDatabase = {
  primaryAddress: '10.30',
  replicaAddress: '10.31',
  replicationLagTicks: 3,
  reads: 1,
  writes: 0,
  staleReads: 0,
  replicated: 1,
  lastOp: null,
  pendingReplication: 0,
  rows: [],
};
const baseDns = {
  address: '10.60',
  ttlTicks: 300,
  lookups: 1,
  cachedHits: 0,
  authoritativeConsults: 1,
  nxAnswers: 0,
  lastLookup: { name: 'example.com', status: 'AUTH', target: '10.1', atTick: 0 },
  authoritative: { 'example.com': '10.1' },
  cache: [
    {
      name: 'example.com',
      target: '10.1',
      cachedAtTick: 0,
      expiresAtTick: 300,
      ttlRemaining: 299,
    },
  ],
};

function snap(trace, over = {}) {
  return {
    stage: 6,
    tick: 1,
    users: 5,
    serverAddress: '10.1',
    queueDepth: 0,
    served: 1,
    avgLatencyTicks: 1,
    workerQueue: baseWorkerQueue,
    database: baseDatabase,
    dns: baseDns,
    router: { leftAddress: '10.65', rightAddress: '20.1', routed: 0, lastFrame: null },
    servers: baseServers,
    trace,
    ...over,
  };
}

describe('describeSnapshot — Stage 6 traces', () => {
  it('describes Stage 6 hosted 10-hop DNS trace labels and dns/router inspector state', () => {
    const traceShape = {
      hop: 2,
      method: 'GET',
      path: 'example.com/about',
      request: 'GET /about',
      hosted: true,
      host: 'example.com',
      resolvedPath: '/about',
      dnsTarget: '10.1',
      dnsSource: 'authoritative',
      targetServer: '10.11',
      cacheStatus: 'MISS',
      dbOp: 'SELECT',
      dbStale: false,
      response: '200 This is the about page',
      status: 200,
      body: 'This is the about page',
      routeId: 'route-about',
    };
    const labels = describeSnapshot(snap(traceShape));
    expect(labels.stage).toBe(6);
    expect(labels.totalHops).toBe(10);
    expect(labels.hop).toBe(2);
    expect(labels.hopStatus).toBe(
      'Hop 2/10: DNS (10.60) answers "example.com is 10.1" (from authoritative)',
    );
    // The Stage 5 chain sentences ride along renumbered +2, byte-identical
    // otherwise (the emission names the resolved GET).
    const hopLabels = (hop, over = {}) =>
      describeSnapshot(snap({ ...traceShape, hop, ...over })).hopStatus;
    expect(hopLabels(1)).toBe('Hop 1/10: Browser (10.2) asks DNS (10.60) to resolve "example.com"');
    expect(hopLabels(2, { dnsSource: 'cache' })).toBe(
      'Hop 2/10: DNS (10.60) answers "example.com is 10.1" (from cache)',
    );
    expect(hopLabels(3)).toBe('Hop 3/10: Browser (10.2) emits "GET /about"');
    expect(hopLabels(4)).toBe('Hop 4/10: Network (10.x) routes to LoadBalancer (10.1)');
    expect(hopLabels(5)).toBe('Hop 5/10: LoadBalancer (10.1) -> 10.11 queue');
    expect(hopLabels(6)).toBe('Hop 6/10: Database SELECT @ Replica (10.31) — fresh');
    expect(hopLabels(7)).toBe(
      'Hop 7/10: WebServer (10.11) -> "200 This is the about page" (cache MISS)',
    );
    expect(hopLabels(8)).toBe('Hop 8/10: Network delivers 200 response to 10.2');
    expect(hopLabels(9)).toBe('Hop 9/10: Browser (10.2) received and displayed 200');
    expect(hopLabels(10)).toBe('Hop 10/10: Worker (10.41) idle — no async jobs in this trace');

    // The DNS inspector carries the ledger trio and the live cache rows;
    // the Router inspector carries its one-hop counter and mini-IP pair.
    const dnsState = JSON.parse(formatComponentState(snap(traceShape), 'dns'));
    expect(dnsState).toEqual(baseDns);
    const routerState = JSON.parse(formatComponentState(snap(traceShape), 'router'));
    expect(routerState).toEqual({
      leftAddress: '10.65',
      rightAddress: '20.1',
      routed: 0,
      lastFrame: null,
    });
    const networkState = JSON.parse(formatComponentState(snap(traceShape), 'network'));
    expect(networkState.subnet).toBe('10.x ⇄ 20.x (via Router 10.65)');
    expect(networkState.interfaces['10.60']).toBe('DNS');
    expect(networkState.interfaces['10.65']).toBe('Router (10.x side)');
    expect(networkState.interfaces['20.1']).toBe('Router (20.x side — CDN edge lands in Stage 6b)');
    expect(componentTitle(snap(traceShape), 'dns')).toBe('DNS — mini-IP 10.60');
    expect(componentTitle(snap(traceShape), 'router')).toBe('Router — 10.65 ⇄ 20.1');
  });

  it('keeps a Stage 6 host-less GET /about at the byte-identical Stage 5 hop story', () => {
    // Named counter-example pinned for the narrative-branch contract
    // (stage6a brief): a host-less Stage 6 trace keeps the Stage 5 count
    // and every sentence verbatim — no DNS hop appears anywhere.
    const trace = {
      hop: 4,
      method: 'GET',
      path: '/about',
      request: 'GET /about',
      hosted: false,
      host: null,
      resolvedPath: '/about',
      targetServer: '10.11',
      cacheStatus: 'MISS',
      dbOp: 'SELECT',
      dbStale: true,
      response: '200 This is the about page',
      status: 200,
      body: 'This is the about page',
      routeId: 'route-about',
    };
    const stage6 = describeSnapshot(snap(trace));
    expect(stage6.totalHops).toBe(8);
    expect(stage6.hopStatus).toBe('Hop 4/8: Database SELECT @ Replica (10.31) — STALE (lag 3t)');
    const hostless = (hop) => describeSnapshot(snap({ ...trace, hop })).hopStatus;
    expect(hostless(1)).toBe('Hop 1/8: Browser (10.2) emits "GET /about"');
    expect(hostless(2)).toBe('Hop 2/8: Network (10.x) routes to LoadBalancer (10.1)');
    expect(hostless(3)).toBe('Hop 3/8: LoadBalancer (10.1) -> 10.11 queue');
    expect(hostless(5)).toBe(
      'Hop 5/8: WebServer (10.11) -> "200 This is the about page" (cache MISS)',
    );
    expect(hostless(6)).toBe('Hop 6/8: Network delivers 200 response to 10.2');
    expect(hostless(7)).toBe('Hop 7/8: Browser (10.2) received and displayed 200');
    expect(hostless(8)).toBe('Hop 8/8: Worker (10.41) idle — no async jobs in this trace');
    expect(hostless(9)).toBe('Idle — type a path and click Go or Step 1 Hop ->');
    // The totals agree with the trace machine's shape contract.
    expect(totalHopsFor(6, trace)).toBe(8);
    expect(totalHopsFor(6, { ...trace, hosted: true })).toBe(10);
    expect(totalHopsFor(6, { ...trace, hosted: true, nx: true })).toBe(2);
    expect(totalHopsFor(5, trace)).toBe(8);
  });

  it('an unresolved name never emits a GET — the NX trace ends at the DNS answer', () => {
    const labels = describeSnapshot(
      snap(
        {
          hop: 2,
          method: 'GET',
          path: 'nope.example/about',
          request: 'GET nope.example/about',
          hosted: true,
          host: 'nope.example',
          resolvedPath: '/about',
          nx: true,
        },
        { dns: { ...baseDns, lookups: 1, nxAnswers: 1, cache: [] } },
      ),
    );
    expect(labels.totalHops).toBe(2);
    expect(labels.hopStatus).toBe('Hop 2/2: DNS (10.60) answers NX no record — no GET is emitted');
    const hopLabels = (hop) =>
      describeSnapshot(
        snap({
          hop,
          method: 'GET',
          path: 'nope.example/about',
          request: 'GET nope.example/about',
          hosted: true,
          host: 'nope.example',
          resolvedPath: '/about',
          nx: true,
        }),
      ).hopStatus;
    expect(hopLabels(1)).toBe('Hop 1/2: Browser (10.2) asks DNS (10.60) to resolve "nope.example"');
    // The browser viewport reads the NX answer, not a numeric status.
    const nxSnap = snap(
      { hop: 2, hosted: true, host: 'nope.example', nx: true },
      {
        dns: { ...baseDns, nxAnswers: 1, cache: [] },
        browserDisplay: {
          from: '10.60',
          to: '10.2',
          request: 'GET nope.example',
          response: 'NX no record',
          status: 'NX',
          body: 'no record',
        },
      },
    );
    expect(describeSnapshot(nxSnap).browserStatus).toBe('NX (GET nope.example)');
    expect(describeSnapshot(nxSnap).browserBody).toBe('no record');
  });
});
