import { test, expect } from '@playwright/test';

// Stage 6a (DNS + cross-subnet Router): the orrery redraws to 8 rings with
// DNS 10.60 on Ring 7 and the Router beside the 10.x hub, hosted paths pay
// a DNS ask + answer before the Stage 5 chain, and the counter-examples are
// pinned: a host-less GET /about keeps the Stage 5 hop story and an NX
// answer never emits a GET. The sim runs from a fixed seed, so the tick
// sequence — and therefore these counts — are identical on every run.

test('should switch to Stage 6, resolve example.com through DNS 10.60, and inspect DNS code + TTL ledger', async ({
  page,
}) => {
  await page.goto('/panel.html');
  await page.getByTestId('stage-pill-6').click();

  await expect(page.getByTestId('node-dns')).toBeVisible();
  await expect(page.getByTestId('node-router')).toBeVisible();
  await expect(page.getByTestId('node-queue')).toBeVisible();
  await expect(page.locator('.orrery-ring')).toHaveCount(8);
  await expect(page.locator('.orrery-ring').first()).toHaveAttribute('r', '400');
  await expect(page.locator('.orrery-ring').last()).toHaveAttribute('r', '3200');
  await expect(page.getByTestId('dns-stats')).toHaveText(
    'Lookups: 0 · Cached hits: 0 · TTL: 300t',
  );
  await expect(page.getByTestId('router-stats')).toHaveText('Routed: 0 · 10.65 ⇄ 20.1');

  // First hosted trace: the cold lookup consults the authoritative table
  // and warms the ledger (Lookups 1, Cached hits 0).
  await page.getByTestId('url-input').fill('example.com/about');
  for (let hop = 0; hop < 10; hop++) await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toContainText('Hop 10/10');
  await expect(page.getByTestId('browser-rendered-body')).toHaveText('This is the about page');
  await expect(page.getByTestId('dns-stats')).toHaveText(
    'Lookups: 1 · Cached hits: 0 · TTL: 300t',
  );
  await expect(page.getByTestId('dns-entries-list')).toContainText('example.com -> 10.1');

  // Second hosted trace: the ledger answers — Cached hits climbs without a
  // second authoritative consult (the TTL-branch counter-example, narrated
  // hop 2/10 in the DNS-ask spec below).
  for (let hop = 0; hop < 10; hop++) await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('dns-stats')).toHaveText(
    'Lookups: 2 · Cached hits: 1 · TTL: 300t',
  );

  await page.getByTestId('node-dns').click();
  await expect(page.getByTestId('inspector-code')).toContainText('createDns');
  await expect(page.getByTestId('inspector-state')).toContainText('"cachedHits": 1');
  await expect(page.getByTestId('inspector-state')).toContainText('"authoritativeConsults": 1');

  await page.getByTestId('node-router').click();
  await expect(page.getByTestId('inspector-code')).toContainText('createRouter');
  await expect(page.getByTestId('inspector-state')).toContainText('"routed": 0');
});

test('should trace example.com/about with DNS ask + answer hops', async ({ page }) => {
  await page.goto('/panel.html?stage=6');
  await page.getByTestId('url-input').fill('example.com/about');

  // Hop 1: the browser asks DNS 10.60 to resolve the host; the ledger warms.
  await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toContainText(
    'Hop 1/10: Browser (10.2) asks DNS (10.60) to resolve "example.com"',
  );
  // Hop 2: the resolver answer names the target and rides into the journey log.
  await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toHaveText(
    'Hop 2/10: DNS (10.60) answers "example.com is 10.1" (from authoritative)',
  );
  await expect(page.getByTestId('journey-log')).toContainText('10.60 -> 10.2 | OK example.com is 10.1');
  // Hop 3: the resolved GET leaves the browser toward 10.1.
  await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toContainText(
    'Hop 3/10: Browser (10.2) emits "GET /about"',
  );

  for (let hop = 0; hop < 7; hop++) await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('browser-status-badge')).toContainText('200 (GET /about)');
  const labels = await page.getByTestId('journey-log').locator('.journey-entry').allTextContents();
  const hopRows = labels.map((text) => text.match(/^(hop \d+\/10)/)?.[1]);
  expect(hopRows.slice(0, 3)).toEqual(['hop 1/10', 'hop 2/10', 'hop 3/10']);
});

test('should keep GET /about on Stage 6 at the Stage 5 hop story', async ({ page }) => {
  // Named counter-example pinned for the trace-branch contract (stage6a
  // brief): a plain path on Stage 6 walks the Stage 5 8-hop story — no DNS
  // hop, no cross-subnet hop, no ledger activity.
  await page.goto('/panel.html?stage=6');
  await page.getByTestId('url-input').fill('/about');
  for (let hop = 0; hop < 8; hop++) await page.getByTestId('btn-next-hop').click();

  await expect(page.getByTestId('hop-status')).toContainText('Hop 8/8');
  await expect(page.getByTestId('hop-status')).toContainText(
    'Hop 8/8: Worker (10.41) idle — no async jobs in this trace',
  );
  await expect(page.getByTestId('browser-rendered-body')).toHaveText('This is the about page');
  await expect(page.getByTestId('dns-stats')).toHaveText(
    'Lookups: 0 · Cached hits: 0 · TTL: 300t',
  );
  const labels = await page.getByTestId('journey-log').locator('.journey-entry').allTextContents();
  expect(labels.map((text) => text.match(/^(hop \d+\/8)/)?.[1]).slice(0, 8)).toEqual([
    'hop 1/8',
    'hop 2/8',
    'hop 3/8',
    'hop 4/8',
    'hop 5/8',
    'hop 6/8',
    'hop 7/8',
    'hop 8/8',
  ]);
  await expect(page.getByTestId('journey-log')).not.toContainText('10.60');
  await expect(page.getByTestId('journey-log')).not.toContainText('ask ');
});

test('an NX answer never emits a GET — the browser renders the NX card', async ({ page }) => {
  await page.goto('/panel.html?stage=6');
  await page.getByTestId('url-input').fill('nope.example/about');
  await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toContainText(
    'Hop 1/2: Browser (10.2) asks DNS (10.60) to resolve "nope.example"',
  );
  await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toHaveText(
    'Hop 2/2: DNS (10.60) answers NX no record — no GET is emitted',
  );
  await expect(page.getByTestId('browser-status-badge')).toHaveText('NX (GET nope.example)');
  await expect(page.getByTestId('browser-rendered-body')).toHaveText('no record');
  await expect(page.getByTestId('dns-stats')).toHaveText(
    'Lookups: 1 · Cached hits: 0 · TTL: 300t',
  );
  const labels = await page.getByTestId('journey-log').locator('.journey-entry').allTextContents();
  expect(labels.some((text) => /GET nope/.test(text))).toBe(false);
});

test('should deep-link ?stage=6 to the live stage 6 and fall back on unknown values', async ({
  page,
}) => {
  const errors = [];
  page.on('pageerror', (error) => errors.push(error));
  page.on('console', (msg) => {
    if (msg.type() === 'error') errors.push(msg.text());
  });
  await page.goto('/panel.html?stage=6');
  await expect(page.getByTestId('stage-pill-6')).toHaveAttribute('aria-current', 'true');
  await expect(page.getByTestId('node-dns')).toBeVisible();
  await expect(page).toHaveURL(/stage=6/);
  // Unknown values still fall back to Stage 1 without a console error.
  await page.goto('/panel.html?stage=9');
  await expect(page.getByTestId('stage-pill-1')).toHaveAttribute('aria-current', 'true');
  await expect(page.getByTestId('server-address')).toHaveText('10.1');
  expect(errors).toEqual([]);
});
