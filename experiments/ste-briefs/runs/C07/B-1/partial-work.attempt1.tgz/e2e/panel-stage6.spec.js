import { test, expect } from '@playwright/test';

// Stage 6a — DNS with tick-TTL ledger + cross-subnet Router. Assertions on
// the real page served by the real static server (TEST-RULES); the sim runs
// from a fixed seed so hop counts and DNS counters are identical every run.
// Lives in its own spec because panel.spec.js sits at its 450-line cap
// (guard-file-size split by responsibility). Titles are manifest pins
// (PANEL-6): do not reword.

test('should switch to Stage 6, resolve example.com through DNS 10.60, and inspect DNS code + TTL ledger', async ({
  page,
}) => {
  // ?stage=6 pins the extended live set: the deep link lands on the live
  // Stage 6 pill (unknown values still fall back to 1 — panel.spec.js).
  await page.goto('/panel.html?stage=6');

  await expect(page.getByTestId('stage-pill-6')).toHaveAttribute('aria-current', 'true');
  await expect(page.getByTestId('node-dns')).toBeVisible();
  await expect(page.getByTestId('node-router')).toBeVisible();
  await expect(page.locator('.orrery-ring')).toHaveCount(8);
  await expect(page.locator('.orrery-ring').last()).toHaveAttribute('r', '3200');
  await expect(page.getByTestId('dns-stats')).toHaveText('Lookups: 0 · Hits: 0 · TTL: 300t');
  await expect(page.getByTestId('router-stats')).toHaveText('Routed: 0 · 10.65 ⇄ 20.1');

  // Hosted trace hops 1-2: the DNS ask and the "example.com = 10.1" answer.
  await page.getByTestId('url-input').fill('example.com/about');
  await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toContainText(
    'Hop 1/10: Browser (10.2) asks DNS (10.60): "example.com?"',
  );
  await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toContainText(
    'Hop 2/10: DNS (10.60) -> Browser (10.2): "example.com = 10.1"',
  );
  await expect(page.getByTestId('dns-stats')).toHaveText('Lookups: 1 · Hits: 0 · TTL: 300t');
  await expect(page.getByTestId('dns-entries-list')).toContainText('example.com · 10.1 · ttl 300t');

  // Hops 3-10 ride the Stage 5 story; the response lands in the viewport.
  for (let hop = 0; hop < 8; hop++) await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toContainText('Hop 10/10');
  await expect(page.getByTestId('browser-rendered-body')).toHaveText('This is the about page');
  await expect(page.getByTestId('browser-status-badge')).toContainText('200');

  // Second hosted trace inside the TTL: a cached hit, authority untouched.
  for (let hop = 0; hop < 10; hop++) await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('dns-stats')).toHaveText('Lookups: 2 · Hits: 1 · TTL: 300t');

  await page.getByTestId('node-dns').click();
  await expect(page.getByTestId('inspector-code')).toContainText('createDns');
  await expect(page.getByTestId('inspector-state')).toContainText('"cachedHits": 1');
  await expect(page.getByTestId('inspector-state')).toContainText('"authoritative": 1');
  await page.getByTestId('node-router').click();
  await expect(page.getByTestId('inspector-code')).toContainText('createRouter');
  await expect(page.getByTestId('inspector-state')).toContainText('"leftAddress": "10.65"');
});

test('should trace example.com/about with DNS ask + answer hops', async ({ page }) => {
  await page.goto('/panel.html?stage=6');

  await page.getByTestId('url-input').fill('example.com/about');
  for (let hop = 0; hop < 10; hop++) await page.getByTestId('btn-next-hop').click();

  // One run's entries read top-down in hop ascending order: the two DNS
  // hops lead, the Stage 5 story follows renumbered 3..10 of 10.
  const labels = await page.getByTestId('journey-log').locator('.journey-entry').allTextContents();
  const hopRows = labels.map((text) => text.match(/^(hop \d+\/\d+)/)?.[1]);
  expect(hopRows.slice(0, 10)).toEqual([
    'hop 1/10',
    'hop 2/10',
    'hop 3/10',
    'hop 4/10',
    'hop 5/10',
    'hop 6/10',
    'hop 7/10',
    'hop 8/10',
    'hop 9/10',
    'hop 10/10',
  ]);
  await expect(page.getByTestId('hop-status')).toContainText(
    'Hop 10/10: Worker (10.41) idle — no async jobs in this trace',
  );

  // An NX name renders the NX card and emits no GET: 3 hops, no 200 badge,
  // and the resolver ledger gains an NX ask without an authority consult.
  await page.getByTestId('url-input').fill('nope.example/about');
  await page.getByTestId('btn-next-hop').click();
  await page.getByTestId('btn-next-hop').click();
  await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toContainText(
    'Hop 3/3: Browser (10.2) rendered nope.example NX — no GET emitted',
  );
  await expect(page.getByTestId('browser-status-badge')).toContainText('NX');
  await expect(page.getByTestId('browser-rendered-body')).toHaveText('no record');
});

// Named counter-example pin (DL-3/DL-4): a host-less GET on Stage 6 keeps
// the Stage 5 hop story — 8 hops, no DNS hop, no cross-subnet hop, and the
// resolver ledger never moves.
test('should keep GET /about on Stage 6 at the Stage 5 hop story', async ({ page }) => {
  await page.goto('/panel.html?stage=6');

  await expect(page.getByTestId('dns-stats')).toHaveText('Lookups: 0 · Hits: 0 · TTL: 300t');
  await page.getByTestId('url-input').fill('/about');
  for (let hop = 0; hop < 4; hop++) await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toContainText('Hop 4/8');
  await expect(page.getByTestId('hop-status')).toContainText('Database SELECT');
  for (let hop = 0; hop < 4; hop++) await page.getByTestId('btn-next-hop').click();
  await expect(page.getByTestId('hop-status')).toContainText(
    'Hop 8/8: Worker (10.41) idle — no async jobs in this trace',
  );
  await expect(page.getByTestId('browser-rendered-body')).toHaveText('This is the about page');
  await expect(page.getByTestId('dns-stats')).toHaveText('Lookups: 0 · Hits: 0 · TTL: 300t');
  await expect(page.getByTestId('dns-entries-list')).toBeEmpty();
  await expect(page.getByTestId('router-stats')).toHaveText('Routed: 0 · 10.65 ⇄ 20.1');
});
