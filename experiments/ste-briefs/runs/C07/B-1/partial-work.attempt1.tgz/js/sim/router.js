// DOCUMENTS: the Stage 6 component — a cross-subnet Router joining the 10.x
// and 20.x network instances at its two interfaces (default 10.65 and
// 20.1). Any frame whose destination subnet differs from its origin subnet
// takes exactly one router hop: the origin network hands the frame to
// `route` (or `enqueue` for queue deliveries), the router counts it in
// `routed`, and delivers into the destination network unchanged — the
// origin mini-IP stays on the frame and `isYou` rides through for the
// you-pill highlight. The router's own interfaces answer slim
// "200 Router <addr>" pings, so 20.1 (its 20-side) is the only reachable
// 20.x target in 6a; Stage 6b occupies that side with the CDN edge.
//
// CHECKS: the constructor rejects an interface that is not a two-number
// mini-IP, and a send into subnet 20 to an unregistered host (20.9) fails
// loud through the destination network's resolve — the same DL-1 throw the
// single-subnet network uses.
const MINI_IP = /^\d+\.\d+$/;

const subnetOf = (addr) => String(addr).split('.')[0];

export function createRouter({ leftAddress = '10.65', rightAddress = '20.1' } = {}) {
  for (const [name, addr] of [
    ['leftAddress', leftAddress],
    ['rightAddress', rightAddress],
  ]) {
    if (!MINI_IP.test(addr)) {
      throw new Error(`router: invalid mini-IP address ${name}=${addr}`);
    }
  }
  let leftNetwork = null;
  let rightNetwork = null;
  let routed = 0;

  function networkFor(destSubnet) {
    if (leftNetwork && subnetOf(leftAddress) === destSubnet) return leftNetwork;
    if (rightNetwork && subnetOf(rightAddress) === destSubnet) return rightNetwork;
    throw new Error(`router: no attached network for subnet ${destSubnet}`);
  }

  return {
    get leftAddress() {
      return leftAddress;
    },
    get rightAddress() {
      return rightAddress;
    },

    // Register the router's two interfaces into their networks so each side
    // is addressable from its own subnet (20.1 is the only reachable 20.x
    // host in 6a).
    attach(left, right) {
      left.registerServer(leftAddress, { handleRequest: () => `200 Router ${leftAddress}` });
      right.registerServer(rightAddress, { handleRequest: () => `200 Router ${rightAddress}` });
      leftNetwork = left;
      rightNetwork = right;
    },

    // One hop: count the frame, resolve the destination in its own network,
    // and hand it the request synchronously (same wire shape as network.send).
    route({ from, to, request }) {
      routed += 1;
      const server = networkFor(subnetOf(to)).resolve(to);
      const response = server.handleRequest(request);
      return { from, to, request, response };
    },

    // Queue deliveries cross the same single hop; `isYou` rides through so
    // the destination queue can highlight the learner's own request.
    enqueue({ id, from, to, request, atTick, isYou = false }) {
      routed += 1;
      // viaRouter marks the frame as already on its router hop so the
      // destination network delivers it instead of handing it back here.
      networkFor(subnetOf(to)).deliverToQueue({
        id,
        from,
        to,
        request,
        atTick,
        isYou,
        viaRouter: true,
      });
    },

    snapshot() {
      return { leftAddress, rightAddress, routed };
    },
  };
}
