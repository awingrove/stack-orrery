// DOCUMENTS: the Stage 6 component — a DNS resolver at 10.60 with an
// authoritative name table and a tick-TTL resolver cache. It is a real Map
// lookup on the browser's request path rather than a probability: a lookup
// consults the authority only on a cache miss or an expired entry, a hit
// inside ttlTicks answers from the ledger, and an unknown name answers
// `{ status: 'NX' }` for the browser to render — the resolver itself does
// not throw on unknown names (the fail-loud throw rule belongs to
// cross-subnet addresses, js/sim/router.js). Deterministic by construction:
// no clock, no RNG — time arrives as the `currentTick` argument, the same
// way the Cache keeps time.
//
// CHECKS: the constructor rejects an address that is not a two-number
// mini-IP and a ttlTicks that is not a positive integer (fail-loud over
// silent mis-configuration), mirroring createCache.
export function createDns({ address = '10.60', ttlTicks = 300 } = {}) {
  if (!/^\d+\.\d+$/.test(address)) {
    throw new Error(`dns: invalid mini-IP address ${address}`);
  }
  if (!Number.isInteger(ttlTicks) || ttlTicks < 1) {
    throw new Error(`dns: ttlTicks must be a positive integer, got ${ttlTicks}`);
  }
  // Authoritative table lives in-component: Stage 6a teaches one name;
  // Stage 6b adds the CDN name here.
  const authority = new Map([['example.com', '10.1']]);
  const cache = new Map(); // name -> { name, target, expiresAtTick }
  let lookups = 0;
  let cachedHits = 0;
  let authoritative = 0;
  let lastLookup = null;

  // An entry is stale the moment the current tick reaches its expiry:
  // answered at tick T with ttlTicks = 300 means alive through tick T + 299.
  function evictExpired(currentTick = 0) {
    for (const entry of cache.values()) {
      if (currentTick >= entry.expiresAtTick) cache.delete(entry.name);
    }
  }

  // The cache branch is the teaching point: a hit inside ttlTicks answers
  // from the ledger and the authority table is left untouched.
  function lookup(name, currentTick = 0) {
    lookups += 1;
    evictExpired(currentTick);
    const entry = cache.get(name);
    if (entry) {
      cachedHits += 1;
      lastLookup = { name, status: 'HIT', atTick: currentTick };
      return { status: 'OK', name, target: entry.target, fromCache: true };
    }
    const target = authority.get(name);
    if (target === undefined) {
      lastLookup = { name, status: 'NX', atTick: currentTick };
      return { status: 'NX', name };
    }
    authoritative += 1;
    cache.set(name, { name, target, expiresAtTick: currentTick + ttlTicks });
    lastLookup = { name, status: 'MISS', atTick: currentTick };
    return { status: 'OK', name, target, fromCache: false };
  }

  function snapshot(currentTick = 0) {
    evictExpired(currentTick);
    return {
      address,
      ttlTicks,
      lookups,
      cachedHits,
      authoritative,
      lastLookup,
      cache: [...cache.values()].map((e) => ({
        name: e.name,
        target: e.target,
        expiresAtTick: e.expiresAtTick,
        ttlRemaining: e.expiresAtTick - currentTick,
      })),
    };
  }

  return {
    get address() {
      return address;
    },
    lookup,
    snapshot,
  };
}
