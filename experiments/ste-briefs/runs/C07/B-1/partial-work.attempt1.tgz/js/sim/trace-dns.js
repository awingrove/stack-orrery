// DOCUMENTS: the Stage 6 DNS preamble of the hop-by-hop trace machine
// (split from trace.js by responsibility, guard-file-size). A hosted path
// ("<host>/<path>") opens the trace with two DNS hops — Browser -> DNS ask,
// DNS -> Browser answer — and then the Stage 5 story continues with the
// resolved target; a host-less path ("/<path>") skips this module entirely
// and keeps the Stage 5 trace byte-identical. An unknown name answers
// "NX no record": the trace ends at the browser card with no GET emitted.
//
// CHECKS: the preamble never emits a GET for an NX answer — the trace
// carries the ask, the NX answer, and the render hop only; the module
// returns null for an ANSWER phase so trace.js's story chain takes over.

// Hosted-path grammar: "example.com/about" splits on the first "/" into
// host + slim path; a path already starting with "/" is host-less and
// keeps the Stage 5 story; a bare "example.com" resolves to the root path.
export function splitHostPath(path) {
  const raw = String(path);
  const at = raw.indexOf('/');
  if (at === 0) return null;
  if (at === -1) return { host: raw, path: '/' };
  return { host: raw.slice(0, at), path: `/${raw.slice(at + 1)}` };
}

// Total hops of a Stage 6 trace: the Stage 5 shape (8) for host-less
// paths, +2 DNS hops for a hosted path, and 3 (ask, NX answer, render)
// once the lookup has answered NX. Stages 1-5 keep their fixed shapes.
export function stage6FinalHop(trace) {
  if (trace.dns?.status === 'NX') return 3;
  if (trace.dns) return 10;
  return 8;
}

export function finalHopFor(stage, trace) {
  if (stage === 6) return stage6FinalHop(trace);
  return { 5: 8, 4: 7, 3: 6, 2: 5, 1: 4 }[stage];
}

// Open a hosted Stage 6 trace at hop 1 (the DNS ask). Returns null for
// host-less paths so trace.js starts the plain Stage 5 shape.
export function beginDnsTrace({ method, path, from, dns }) {
  const hosted = dns ? splitHostPath(path) : null;
  if (!hosted) return null;
  const trace = {
    hop: 1,
    method,
    path,
    from,
    request: `${method} ${path}`,
    targetServer: null,
    cacheStatus: null,
    dbOp: null,
    dbStale: false,
    response: null,
    status: null,
    body: null,
    routeId: null,
    dns: { host: hosted.host, rest: hosted.path, status: 'ASK', target: null },
  };
  return { trace, frame: `${from} -> DNS ${dns.address} | ${hosted.host}?` };
}

// Advance the DNS preamble one hop: hop 1 resolves the ask (OK answers
// rewrite the trace onto the resolved slim path so the Stage 5 story emits
// "GET /about"; NX stops the trace at the browser card). Returns the hop
// frame, or null when the preamble is done (ANSWER phase). `finish` is the
// trace machine's browser-delivery callback, invoked for the NX card so
// the rendered record never touches a webserver queue.
export function stepDnsPhase({ trace, dns, getTick, finish }) {
  const { dns: phase } = trace;
  if (!phase || phase.status === 'ANSWER') return null;
  if (phase.status === 'ASK' && trace.hop === 1) {
    trace.hop = 2;
    const answer = dns.lookup(phase.host, getTick());
    if (answer.status === 'OK') {
      trace.dns = { ...phase, status: 'ANSWER', target: answer.target };
      trace.path = phase.rest;
      trace.request = `${trace.method} ${phase.rest}`;
      return `DNS ${dns.address} -> ${trace.from} | ${phase.host} = ${answer.target}`;
    }
    trace.dns = { ...phase, status: 'NX' };
    trace.response = 'NX no record';
    trace.status = 'NX';
    trace.body = 'no record';
    return `DNS ${dns.address} -> ${trace.from} | NX no record`;
  }
  if (phase.status === 'NX' && trace.hop === 2) {
    trace.hop = 3;
    finish(dns.address);
    return `Browser ${trace.from} rendered ${phase.host} NX — no GET emitted`;
  }
  return null;
}
