// DOCUMENTS: the network — the wiring that lets two-number mini-IP
// addressable components exchange messages. Today it carries slim HTTP
// requests to a registered server; later stages attach more components
// without changing the send/enqueue contract.
//
// Stage 6: with a Router attached (js/sim/router.js), a frame whose
// destination subnet differs from its origin subnet takes exactly one
// router hop — the network hands the frame to the router and the router
// delivers it into the destination subnet's network instance. Same-subnet
// sends keep today's send/deliverToQueue contract byte-for-byte, and a
// router-less network routes nothing cross-subnet (unknown hosts still
// throw the same "no server" error as before).
//
// CHECKS: every address crossing the wire is validated as a two-number
// mini-IP (<net>.<host>), and sends to unregistered hosts fail loud.
const MINI_IP = /^\d+\.\d+$/;

export function createNetwork() {
  const servers = new Map();
  let router = null;

  function validate(addr) {
    if (!MINI_IP.test(addr)) {
      throw new Error(`network: invalid mini-IP address ${addr}`);
    }
  }

  function resolve(address) {
    validate(address);
    const server = servers.get(address);
    if (!server) {
      throw new Error(`network: no server at ${address}`);
    }
    return server;
  }

  // A cross-subnet frame only routes through the attached router, and a
  // frame the router itself is delivering (viaRouter) is already on its
  // final hop — routing it again would loop.
  function isCrossSubnet({ from, to, viaRouter }) {
    return Boolean(router) && !viaRouter && String(from).split('.')[0] !== String(to).split('.')[0];
  }

  return {
    registerServer(address, server) {
      validate(address);
      servers.set(address, server);
    },

    // CHECKS: the router hands back via attach() during engine wiring; a
    // network without one keeps the single-subnet contract unchanged.
    attachRouter(attached) {
      router = attached;
    },

    resolve,

    send({ from, to, request, viaRouter }) {
      validate(from);
      if (isCrossSubnet({ from, to, viaRouter })) return router.route({ from, to, request });
      const server = resolve(to);
      const response = server.handleRequest(request);
      return { from, to, request, response };
    },

    // `isYou` rides through untouched: the engine marks the learner's own
    // interactive-browser request, the server stores it on the queue row.
    deliverToQueue({ id, from, to, request, atTick, isYou = false, viaRouter }) {
      validate(from);
      if (isCrossSubnet({ from, to, viaRouter })) {
        return router.enqueue({ id, from, to, request, atTick, isYou });
      }
      const server = resolve(to);
      server.enqueue({ id, from, to, request, atTick, isYou });
    },
  };
}
