// DOCUMENTS: Stage 6 orrery additions (split from layout.js by
// responsibility, guard-file-size): the DNS card on RING 7 and the Router
// side-card beside the 10.x hub on RING 6, with the wires their traces
// ride — the browser↔DNS ask/answer chord and the network↔router
// cross-subnet chord. Receives layout primitives as arguments so the
// module stays independent of layout.js.
export function addStage6Layout({ rings, nodes, wires, pos, makeWire }) {
  const dnsRing = rings.find((ring) => ring.id === 'ring-dns');
  const networkRing = rings.find((ring) => ring.id === 'ring-network');
  nodes['node-dns'] = pos('node-dns', 'ring-dns', dnsRing.radius, 120);
  nodes['node-router'] = pos('node-router', 'ring-network', networkRing.radius, 150);
  wires.push(
    makeWire(
      'wire-browser-dns',
      'node-browser',
      'node-dns',
      nodes['node-browser'],
      nodes['node-dns'],
    ),
    makeWire(
      'wire-network-router',
      'node-network',
      'node-router',
      nodes['node-network'],
      nodes['node-router'],
    ),
  );
}
