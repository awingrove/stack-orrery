// DOCUMENTS: Stage 6 orrery nodes (split from panel.html by
// responsibility, guard-file-size — that page sits at its 550-line cap, the
// same reason teaching-drawer.js exists). Builds the live `stage-pill-6`
// button, the DNS and Router node cards, their wire lanes, and the two
// inspector tabs. All content is textContent/attributes — no innerHTML, no
// inline handlers or styles (AGENTS.md CSP rule); world-space positioning
// stays in viewport.js (DL-1), driven by layout-stage6.js.
import { COMPONENT_SOURCE } from './inspector-source.js';

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function header(roleName, subtitle, ipChip) {
  const head = el('header', 'node-head');
  const name = el('div', 'node-name');
  name.append(el('span', 'role-name', roleName), el('span', 'node-subtitle', subtitle));
  head.append(name, el('span', 'ip-chip', ipChip), el('span', 'code-chip', '</> Code'));
  return head;
}

function nodeCard({ id, component, roleName, subtitle, ipChip }) {
  const card = el('article', 'node-card');
  card.id = id;
  card.dataset.testid = id;
  card.dataset.component = component;
  card.hidden = true;
  card.append(header(roleName, subtitle, ipChip));
  return card;
}

function wireColumn(id, lanes) {
  const column = el('div', 'wire-column');
  column.id = id;
  column.dataset.testid = id;
  column.setAttribute('aria-hidden', 'true');
  column.hidden = true;
  for (const [laneId, text, reverse] of lanes) {
    const lane = el('div', reverse ? 'wire-lane reverse' : 'wire-lane', text);
    lane.id = laneId;
    column.append(lane);
  }
  return column;
}

// CHECKS: the planned "6 · Multi-Net / CDN" pill becomes the live Stage 6
// button — clicking it switches the topology like every other pill, and
// `?stage=6` deep-links straight to it (unknown values still fall back to
// Stage 1, pinned in e2e/panel.spec.js).
function buildStagePill() {
  const planned = [...document.querySelectorAll('.stage-ladder .stage-pill')].at(-1);
  const pill = document.createElement('button');
  pill.dataset.testid = 'stage-pill-6';
  pill.dataset.stage = '6';
  pill.className = 'stage-pill';
  pill.type = 'button';
  pill.title = 'Switch to Stage 6 — DNS and cross-subnet routing';
  pill.textContent = planned ? planned.textContent : '6 · Multi-Net / CDN';
  planned?.replaceWith(pill);
}

function buildInspectorTabs() {
  const tabs = document.querySelector('.comp-tabs');
  for (const component of ['dns', 'router']) {
    if (!COMPONENT_SOURCE[component]) continue;
    const tab = el('button', 'comp-tab', component);
    tab.type = 'button';
    tab.dataset.select = component;
    tabs.append(tab);
  }
}

export function initStage6Nodes() {
  buildStagePill();
  buildInspectorTabs();

  const world = document.getElementById('orrery-world');

  // DNS card: lookup/hit counters plus the live resolver ledger with
  // remaining TTL (DESIGN.md #node-dns / #dns-entries-list).
  const dns = nodeCard({
    id: 'node-dns',
    component: 'dns',
    roleName: 'DNS',
    subtitle: 'resolver, tick-TTL ledger',
    ipChip: '10.60',
  });
  const dnsStats = el('p', 'mono last-frame', 'Lookups: 0 · Hits: 0 · TTL: 300t');
  dnsStats.id = 'dns-stats';
  dnsStats.dataset.testid = 'dns-stats';
  const dnsEntries = el('ul', 'route-list');
  dnsEntries.id = 'dns-entries-list';
  dnsEntries.dataset.testid = 'dns-entries-list';
  dnsEntries.setAttribute('aria-label', 'Resolver cache');
  dns.append(dnsStats, dnsEntries);

  // Router side-card: the cross-subnet hop counter on the 10.x/20.x edge
  // (DESIGN.md #node-router).
  const router = nodeCard({
    id: 'node-router',
    component: 'router',
    roleName: 'Router',
    subtitle: 'cross-subnet edge',
    ipChip: '10.65 ⇄ 20.1',
  });
  const routerStats = el('p', 'mono last-frame', 'Routed: 0 · 10.65 ⇄ 20.1');
  routerStats.id = 'router-stats';
  routerStats.dataset.testid = 'router-stats';
  router.append(routerStats);

  world.append(
    wireColumn('wire-browser-dns', [
      ['packet-req-dns', 'dns ask =>'],
      ['packet-res-dns', '<- answer', true],
    ]),
    wireColumn('wire-network-router', [
      ['packet-req-router', 'route =>'],
      ['packet-res-router', '<- reply', true],
    ]),
    dns,
    router,
  );
}
