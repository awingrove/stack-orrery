// DOCUMENTS: pure presentation model — engine snapshot in, labels and bar
// geometry out. No DOM here: this is what the unit suite pins; panel.js and
// render.js own all DOM writes.
export const TICK_MS = 100;
const QUEUE_BAR_SATURATION = 20; // bar reads full at 20 queued requests
// Total hops per stage's trace shape (trace.js and engine.traceHop agree);
// Stage 6 is dynamic — see totalHopsForSnapshot below.
const TOTAL_HOPS = { 1: 4, 2: 5, 3: 6, 4: 7, 5: 8 };

const HOP_START_SENTENCE = 'Idle — type a path and click Go or Step 1 Hop ->';

// PINS: the Stage 6 live-stage set feeds ?stage= and the stage ladder — a
// hosted trace (trace.dns set) totals 10 hops, an NX answer 3, and a
// host-less trace stays at the Stage 5 shape's 8 (byte-identical story,
// pinned in test/panel/model-stage6.test.js).
export function totalHopsForSnapshot(snapshot) {
  const stage = snapshot.stage ?? 1;
  if (stage === 6) {
    if (snapshot.trace?.dns?.status === 'NX') return 3;
    return snapshot.trace?.dns ? 10 : 8;
  }
  return TOTAL_HOPS[stage] ?? 4;
}

function fillPercent(depth) {
  return `${Math.min(100, Math.round((depth / QUEUE_BAR_SATURATION) * 100))}%`;
}

// One hop-status sentence per hop, in hop order, for each stage's trace
// shape: 4 hops in Stage 1 (emit, route, serve, render), 5 in Stage 2 (LB
// round-robin pick), 6 in Stage 3 (cache check, then response emit), 7 in
// Stage 4 (the database hop after the cache check). Stage 6 branches on
// the trace's DNS preamble: a host-less path returns the Stage 5
// sentences byte-identical, a hosted path adds the two DNS hops in front
// of the renumbered Stage 5 story, and an NX answer stops at the browser
// card with no GET emitted.
//
// CHECKS: the Stage 6 narrative branches on trace.dns — never on a
// hardcoded stage-6 script — so `GET /about` keeps the Stage 5 hop count
// and texts byte-identical while `example.com/about` adds exactly two DNS
// hops (named counter-example pinned in test/panel/model-stage6.test.js).
function stage5Bodies(snapshot, from, serverAddress) {
  const t = snapshot.trace ?? {};
  const target = t.targetServer ?? '10.11';
  const worker = snapshot.workerQueue?.workerAddress ?? '10.41';
  if (t.asyncJob) {
    return [
      `Browser (${from}) emits "${t.request}"`,
      `Network (10.x) routes to LoadBalancer (${serverAddress})`,
      `LoadBalancer (${serverAddress}) -> ${target} queue`,
      `WebServer (${target}) enqueues job to WorkerQueue (10.40)`,
      `WebServer (${target}) -> "202 Accepted"`,
      `Network delivers 202 response to ${from}`,
      `Browser (${from}) received and displayed 202 Accepted`,
      `Worker (${worker}) processed job and committed to Database (10.30)`,
    ];
  }
  // Requests served synchronously keep the Stage 4 cache/database story;
  // the worker does not see them, so the tail hop reads idle.
  const db = snapshot.database ?? {};
  const primary = db.primaryAddress ?? '10.30';
  const replica = db.replicaAddress ?? '10.31';
  const lag = db.replicationLagTicks ?? 3;
  const dbOp =
    t.dbOp === 'WRITE'
      ? `Database WRITE @ Primary (${primary}) — replica lags ${lag}t`
      : t.dbOp === 'SELECT' && t.dbStale
        ? `Database SELECT @ Replica (${replica}) — STALE (lag ${lag}t)`
        : t.dbOp === 'SELECT'
          ? `Database SELECT @ Replica (${replica}) — fresh`
          : `Database SKIP — warm cache HIT (${snapshot.cache?.address ?? '10.20'})`;
  return [
    `Browser (${from}) emits "${t.request}"`,
    `Network (10.x) routes to LoadBalancer (${serverAddress})`,
    `LoadBalancer (${serverAddress}) -> ${target} queue`,
    dbOp,
    `WebServer (${target}) -> "${t.response}" (cache ${t.cacheStatus})`,
    `Network delivers ${t.status} response to ${from}`,
    `Browser (${from}) received and displayed ${t.status}`,
    `Worker (${worker}) idle — no async jobs in this trace`,
  ];
}

function stage5Sentences(snapshot, from, serverAddress) {
  return stage5Bodies(snapshot, from, serverAddress).map((body, i) => `Hop ${i + 1}/8: ${body}`);
}

function hopSentences(stage, snapshot, from, serverAddress) {
  const t = snapshot.trace ?? {};
  const target = t.targetServer ?? '10.11';
  if (stage === 6) {
    const dns = snapshot.dns ?? { address: '10.60' };
    if (t.dns?.status === 'NX') {
      return [
        `Hop 1/3: Browser (${from}) asks DNS (${dns.address}): "${t.dns.host}?"`,
        `Hop 2/3: DNS (${dns.address}) -> Browser (${from}): "NX no record"`,
        `Hop 3/3: Browser (${from}) rendered ${t.dns.host} NX — no GET emitted`,
      ];
    }
    if (t.dns) {
      return [
        `Hop 1/10: Browser (${from}) asks DNS (${dns.address}): "${t.dns.host}?"`,
        `Hop 2/10: DNS (${dns.address}) -> Browser (${from}): "${t.dns.host} = ${t.dns.target}"`,
        ...stage5Bodies(snapshot, from, serverAddress).map((body, i) => `Hop ${i + 3}/10: ${body}`),
      ];
    }
    return stage5Sentences(snapshot, from, serverAddress);
  }
  if (stage === 5) {
    return stage5Sentences(snapshot, from, serverAddress);
  }
  if (stage === 4) {
    const db = snapshot.database ?? null;
    const primary = db?.primaryAddress ?? '10.30';
    const replica = db?.replicaAddress ?? '10.31';
    const lag = db?.replicationLagTicks ?? 3;
    const dbSentence =
      t.dbOp === 'WRITE'
        ? `Hop 5/7: Database WRITE @ Primary (${primary}) — replica lags ${lag}t`
        : t.dbOp === 'SELECT' && t.dbStale
          ? `Hop 5/7: Database SELECT @ Replica (${replica}) — STALE (lag ${lag}t)`
          : t.dbOp === 'SELECT'
            ? `Hop 5/7: Database SELECT @ Replica (${replica}) — fresh`
            : `Hop 5/7: Database SKIP — warm cache HIT (10.20)`;
    return [
      `Hop 1/7: Browser (${from}) emits "${t.request}"`,
      `Hop 2/7: Network (10.x) routes to LoadBalancer (${serverAddress})`,
      `Hop 3/7: LoadBalancer (${serverAddress}) -> ${target} queue`,
      `Hop 4/7: WebServer (${target}) checks Cache (10.20) — ${t.cacheStatus}`,
      dbSentence,
      `Hop 6/7: WebServer (${target}) -> "${t.response}" (cache ${t.cacheStatus})`,
      `Hop 7/7: Browser (${from}) rendered ${t.status}`,
    ];
  }
  if (stage === 3) {
    return [
      `Hop 1/6: Browser (${from}) emits "${t.request}"`,
      `Hop 2/6: Network (10.x) routes to LoadBalancer (${serverAddress})`,
      `Hop 3/6: LoadBalancer (${serverAddress}) -> ${target} queue`,
      `Hop 4/6: WebServer (${target}) checks Cache (10.20) — ${t.cacheStatus}`,
      `Hop 5/6: WebServer (${target}) -> "${t.response}" (cache ${t.cacheStatus})`,
      `Hop 6/6: Browser (${from}) rendered ${t.status}`,
    ];
  }
  if (stage === 2) {
    return [
      `Hop 1/5: Browser (${from}) emits "${t.request}"`,
      `Hop 2/5: Network (10.x) routes to LoadBalancer (${serverAddress})`,
      `Hop 3/5: LoadBalancer (${serverAddress}) -> ${target} queue`,
      `Hop 4/5: WebServer (${target}) -> "${t.response}"`,
      `Hop 5/5: Browser (${from}) rendered ${t.status}`,
    ];
  }
  return [
    `Hop 1/4: Browser (${from}) emits "${t.request}"`,
    `Hop 2/4: Network (10.x) routes to ${serverAddress} queue`,
    `Hop 3/4: WebServer (${serverAddress}) -> "${t.response}"`,
    `Hop 4/4: Browser (${from}) rendered ${t.status}`,
  ];
}

function formatHopStatus(snapshot, serverAddress) {
  const hop = snapshot.trace?.hop ?? 0;
  const from = snapshot.trace?.from ?? '10.2';
  if (hop >= 1) {
    const sentences = hopSentences(snapshot.stage ?? 1, snapshot, from, serverAddress);
    if (hop <= sentences.length) return sentences[hop - 1];
  }
  return HOP_START_SENTENCE;
}

// PINS: journey-log chronology, as consumed by render.js's #journey-log.
// Entries carry the run key (run, hop): top-down, a run completed later
// floats wholly above a run completed earlier, and inside a run the entries
// sort hop-ascending whatever emission order the trace engine produces —
// a 4-hop trace must never read "hop 2/4" above "hop 1/4" (named
// counter-example, pinned in test/panel/render.test.js).
export function journeyEntryIsBefore(entry, existing) {
  return entry.run > existing.run || (entry.run === existing.run && entry.hop < existing.hop);
}

// Pure insertion into a sorted journey list (no DOM here): returns the
// ordered array with the new entry placed so the run key order holds.
export function orderJourneyEntries(entries, entry) {
  const ordered = [...entries];
  const index = ordered.findIndex((existing) => journeyEntryIsBefore(entry, existing));
  if (index === -1) ordered.push(entry);
  else ordered.splice(index, 0, entry);
  return ordered;
}

export function describeSnapshot(snapshot) {
  const stage = snapshot.stage ?? 1;
  const latencyMs = Math.round(snapshot.avgLatencyTicks * TICK_MS);
  const last = snapshot.lastExchange ?? null;
  const hop = snapshot.trace?.hop ?? 0;
  const serverAddress = snapshot.serverAddress ?? '10.1';
  const s1Depth = snapshot.servers?.[0]?.queueDepth ?? snapshot.queueDepth;
  const s2Depth = snapshot.servers?.[1]?.queueDepth ?? 0;
  const perBackend = snapshot.loadBalancer?.perBackend ?? {};
  // CHECKS: per-tick throughput is served/tick while the clock runs and
  // exactly 0 at tick 0 — the SERVED card renders "0.00/t", never NaN or
  // Infinity (named counter-example: a fresh Stage-1 panel at tick 0).
  const servedPerTick = snapshot.tick > 0 ? (snapshot.served ?? 0) / snapshot.tick : 0;
  return {
    stage,
    totalHops: totalHopsForSnapshot(snapshot),
    tick: String(snapshot.tick),
    users: String(snapshot.users),
    queueDepth: String(snapshot.queueDepth),
    served: String(snapshot.served),
    servedRate: `${servedPerTick.toFixed(2)}/t`,
    latency: `${latencyMs} ms`,
    queueFill: fillPercent(snapshot.queueDepth),
    queueFill1: fillPercent(s1Depth),
    queueFill2: fillPercent(s2Depth),
    serverAddress,
    server1Address: snapshot.servers?.[0]?.address ?? serverAddress,
    server2Address: snapshot.servers?.[1]?.address ?? '10.12',
    lbNextBackend: snapshot.loadBalancer
      ? `Next -> ${snapshot.loadBalancer.nextBackend}`
      : 'Next -> 10.11',
    lbBackend1Label: `10.11 WebServer-1 (${perBackend['10.11'] ?? 0})`,
    lbBackend2Label: `10.12 WebServer-2 (${perBackend['10.12'] ?? 0})`,
    cacheStatsLabel: `Hits: ${snapshot.cache?.hits ?? 0} · Misses: ${snapshot.cache?.misses ?? 0} · TTL: ${snapshot.cache?.ttlTicks ?? 10}t`,
    cacheEntries: snapshot.cache?.entries ?? [],
    dbStatsLabel: `Reads: ${snapshot.database?.reads ?? 0} · Writes: ${snapshot.database?.writes ?? 0} · Lag: ${snapshot.database?.replicationLagTicks ?? 3}t`,
    dbRows: snapshot.database?.rows ?? [],
    queueStatsLabel: snapshot.workerQueue
      ? `Enqueued: ${snapshot.workerQueue.enqueued} · Completed: ${snapshot.workerQueue.completed} · Active: ${
          snapshot.workerQueue.activeJob
            ? `#${snapshot.workerQueue.activeJob.jobId} ${snapshot.workerQueue.activeJob.path}`
            : 'none'
        }`
      : 'Enqueued: 0 · Completed: 0 · Active: none',
    workerStatsLabel: snapshot.workerQueue
      ? snapshot.workerQueue.activeJob
        ? `Worker ${snapshot.workerQueue.workerAddress} processing #${snapshot.workerQueue.activeJob.jobId} (${snapshot.workerQueue.activeJob.path})`
        : `Worker ${snapshot.workerQueue.workerAddress} Idle`
      : 'Worker 10.41 Idle',
    queueJobs: snapshot.workerQueue?.pendingJobs ?? [],
    dnsStatsLabel: snapshot.dns
      ? `Lookups: ${snapshot.dns.lookups} · Hits: ${snapshot.dns.cachedHits} · TTL: ${snapshot.dns.ttlTicks}t`
      : 'Lookups: 0 · Hits: 0 · TTL: 300t',
    dnsEntries: snapshot.dns?.cache ?? [],
    routerStatsLabel: snapshot.router
      ? `Routed: ${snapshot.router.routed} · ${snapshot.router.leftAddress} ⇄ ${snapshot.router.rightAddress}`
      : 'Routed: 0 · 10.65 ⇄ 20.1',
    exchangeSummary: last
      ? `${last.from} -> ${last.to} ${last.request} => ${last.response}`
      : 'No requests served yet',
    hop,
    hopStatus: formatHopStatus(snapshot, serverAddress),
    browserStatus: snapshot.browserDisplay
      ? `${snapshot.browserDisplay.status} (${snapshot.browserDisplay.request})`
      : 'No response yet',
    browserBody: snapshot.browserDisplay
      ? snapshot.browserDisplay.body
      : 'Send a request or step a hop to render a response.',
    networkLastFrame: snapshot.lastFrame ?? 'No frames routed yet',
    matchedRouteId: snapshot.lastMatchedRoute ?? null,
  };
}
