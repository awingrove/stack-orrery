// DOCUMENTS: the Stage 6 inspector code mirrors (split from
// inspector-source.js by responsibility, guard-file-size) — the DNS
// resolver and the cross-subnet Router, hand-edited to mirror
// js/sim/dns.js and js/sim/router.js the way every other component entry
// does. Live-state builders for the same components live in
// inspector-state.js.
export const STAGE6_SOURCE = {
  dns: {
    file: 'js/sim/dns.js',
    code: `createDns({ address = '10.60', ttlTicks = 300 } = {}) {
  // address must be "<net>.<host>" — a two-number mini-IP
  const authority = new Map([['example.com', '10.1']]);
  const cache = new Map();  // name -> { name, target, expiresAtTick }
  let lookups = 0, cachedHits = 0, authoritative = 0, lastLookup = null;
  function evictExpired(currentTick = 0) {
    for (const entry of cache.values()) {
      if (currentTick >= entry.expiresAtTick) cache.delete(entry.name);
    }
  }
  function lookup(name, currentTick = 0) {
    lookups += 1;
    evictExpired(currentTick);
    const entry = cache.get(name);
    if (entry) {           // hit inside ttlTicks: the ledger answers,
      cachedHits += 1;     // the authority table is left untouched
      lastLookup = { name, status: 'HIT', atTick: currentTick };
      return { status: 'OK', name, target: entry.target, fromCache: true };
    }
    const target = authority.get(name);
    if (target === undefined) {   // unknown name: NX for the browser
      lastLookup = { name, status: 'NX', atTick: currentTick };
      return { status: 'NX', name };   // to render — no throw here
    }
    authoritative += 1;   // miss or expired entry: consult the table
    cache.set(name, { name, target, expiresAtTick: currentTick + ttlTicks });
    lastLookup = { name, status: 'MISS', atTick: currentTick };
    return { status: 'OK', name, target, fromCache: false };
  }
  function snapshot(currentTick = 0) {
    evictExpired(currentTick);
    return { address, ttlTicks, lookups, cachedHits, authoritative, lastLookup,
      cache: [...cache.values()].map((e) => ({ ...e,
        ttlRemaining: e.expiresAtTick - currentTick })) };
  }
  return { address, lookup, snapshot };
}`,
  },
  router: {
    file: 'js/sim/router.js',
    code: `createRouter({ leftAddress = '10.65', rightAddress = '20.1' } = {}) {
  // both interfaces must be "<net>.<host>" — two-number mini-IPs
  let leftNetwork = null, rightNetwork = null, routed = 0;
  const subnetOf = (addr) => String(addr).split('.')[0];
  function networkFor(destSubnet) {
    if (leftNetwork && subnetOf(leftAddress) === destSubnet) return leftNetwork;
    if (rightNetwork && subnetOf(rightAddress) === destSubnet) return rightNetwork;
    throw new Error(\`router: no attached network for subnet \${destSubnet}\`);
  }
  return {
    attach(left, right) {  // register both interfaces into their networks
      left.registerServer(leftAddress, { handleRequest: () => \`200 Router \${leftAddress}\` });
      right.registerServer(rightAddress, { handleRequest: () => \`200 Router \${rightAddress}\` });
      leftNetwork = left; rightNetwork = right;
    },
    route({ from, to, request }) {   // exactly one router hop
      routed += 1;
      const server = networkFor(subnetOf(to)).resolve(to);
      const response = server.handleRequest(request);
      return { from, to, request, response };
    },
    enqueue({ id, from, to, request, atTick, isYou = false }) {
      routed += 1;  // isYou rides through to the destination queue row
      networkFor(subnetOf(to)).deliverToQueue({ id, from, to, request, atTick, isYou });
    },
    snapshot() { return { leftAddress, rightAddress, routed }; },
  };
}`,
  },
};
