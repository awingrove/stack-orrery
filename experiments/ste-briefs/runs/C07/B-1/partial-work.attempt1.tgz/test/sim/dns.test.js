import { describe, it, expect } from 'vitest';
import { createDns } from '../../js/sim/dns.js';
import { createEngine } from '../../js/sim/engine.js';

describe('createDns', () => {
  it('answers a hosted name from the tick-TTL ledger — hits inside ttlTicks leave the authority untouched, expired entries miss again', () => {
    const dns = createDns({ address: '10.60', ttlTicks: 300 });

    // Cold lookup: the authority table answers and the ledger warms.
    const cold = dns.lookup('example.com', 1);
    expect(cold).toEqual({ status: 'OK', name: 'example.com', target: '10.1', fromCache: false });
    expect(dns.snapshot(1)).toMatchObject({ lookups: 1, cachedHits: 0, authoritative: 1 });
    expect(dns.snapshot(1).cache).toEqual([
      { name: 'example.com', target: '10.1', expiresAtTick: 301, ttlRemaining: 300 },
    ]);

    // CHECKS: a hit inside ttlTicks answers from the ledger — cachedHits
    // increments and the authority consult counter does not move.
    const warm = dns.lookup('example.com', 299);
    expect(warm).toEqual({ status: 'OK', name: 'example.com', target: '10.1', fromCache: true });
    expect(dns.snapshot(299)).toMatchObject({ lookups: 2, cachedHits: 1, authoritative: 1 });

    // CHECKS: an expired entry is NOT answered from the ledger — tick 301
    // is past expiresAtTick 301's alive-through-300 window, so the entry
    // evicts and the authority is consulted again.
    const expired = dns.lookup('example.com', 301);
    expect(expired.fromCache).toBe(false);
    expect(dns.snapshot(301)).toMatchObject({ lookups: 3, cachedHits: 1, authoritative: 2 });
    expect(dns.snapshot(301).cache[0].expiresAtTick).toBe(601);

    // The whole state shape matches the brief's ledger contract.
    expect(Object.keys(dns.snapshot(301))).toEqual(
      expect.arrayContaining(['lookups', 'cachedHits', 'authoritative', 'cache']),
    );

    // CHECKS: the constructor rejects a non-mini-IP address and a
    // non-positive or non-integer ttlTicks (fail-loud over silent misconfig).
    expect(() => createDns({ address: '1060' })).toThrow(/invalid mini-IP/);
    expect(() => createDns({ ttlTicks: 0 })).toThrow(/ttlTicks/);
    expect(() => createDns({ ttlTicks: 2.5 })).toThrow(/ttlTicks/);
  });

  it('answers an unknown name with NX and no throw — the browser renders the NX card instead', () => {
    const dns = createDns();
    const answer = dns.lookup('nope.example', 0);
    expect(answer).toEqual({ status: 'NX', name: 'nope.example' });
    expect(dns.snapshot(0)).toMatchObject({ lookups: 1, cachedHits: 0, authoritative: 0 });
    expect(dns.snapshot(0).cache).toEqual([]);
    // A second ask is the same NX answer, still without an authority consult.
    expect(dns.lookup('nope.example', 1)).toEqual({ status: 'NX', name: 'nope.example' });
    expect(dns.snapshot(1)).toMatchObject({ lookups: 2, authoritative: 0 });
  });

  it('stage 6 engine resolves hosted paths through DNS 10.60 in two extra hops and emits no GET for NX names', () => {
    const engine = createEngine({ stage: 6 });
    let snap = engine.snapshot();
    expect(snap.dns).not.toBe(null);
    expect(snap.dns.address).toBe('10.60');
    expect(snap.router).not.toBe(null);

    // Hosted trace: 10 hops, one authority consult, the resolved target on
    // the ledger, and the Stage 5 story intact after the preamble (MISS on
    // the cache lookup, target backend 10.11).
    for (let hop = 0; hop < 10; hop++)
      engine.traceHop({ method: 'GET', path: 'example.com/about' });
    snap = engine.snapshot();
    expect(snap.trace.hop).toBe(10);
    expect(snap.trace.targetServer).toBe('10.11');
    expect(snap.trace.cacheStatus).toBe('MISS');
    expect(snap.dns.lookups).toBe(1);
    expect(snap.dns.authoritative).toBe(1);
    expect(snap.dns.cache[0]).toMatchObject({ name: 'example.com', target: '10.1' });
    expect(snap.browserDisplay.body).toBe('This is the about page');

    // Second hosted trace inside the TTL: a cached hit, no authority consult.
    for (let hop = 0; hop < 10; hop++)
      engine.traceHop({ method: 'GET', path: 'example.com/about' });
    snap = engine.snapshot();
    expect(snap.dns.cachedHits).toBe(1);
    expect(snap.dns.authoritative).toBe(1);

    // Host-less path: 8 hops, DNS counters untouched.
    for (let hop = 0; hop < 8; hop++) engine.traceHop({ method: 'GET', path: '/about' });
    snap = engine.snapshot();
    expect(snap.trace.hop).toBe(8);
    expect(snap.dns.lookups).toBe(2);

    // NX path: 3 hops, the browser renders the NX card, and nothing new
    // was served — the GET stayed off the wire.
    const servedBefore = snap.servers.reduce((sum, s) => sum + s.served, 0);
    for (let hop = 0; hop < 3; hop++)
      engine.traceHop({ method: 'GET', path: 'nope.example/about' });
    snap = engine.snapshot();
    expect(snap.trace.hop).toBe(3);
    expect(snap.dns.lookups).toBe(3);
    expect(snap.servers.reduce((sum, s) => sum + s.served, 0)).toBe(servedBefore);
    expect(snap.browserDisplay.status).toBe('NX');
    expect(snap.browserDisplay.body).toBe('no record');

    // Stages 1-5 expose no DNS at all.
    expect(createEngine({ stage: 5 }).snapshot().dns).toBe(null);
    expect(createEngine({ stage: 1 }).snapshot().dns).toBe(null);
  });
});
