import { describe, it, expect } from 'vitest';
import { createRouter } from '../../js/sim/router.js';
import { createNetwork } from '../../js/sim/network.js';
import { createWebServer } from '../../js/sim/webserver.js';
import { createEngine } from '../../js/sim/engine.js';

// A test-only stand-in in subnet 20: the shipped Stage 6 topology keeps
// subnet 20 empty besides the router's own 20.1 presence (Stage 6b puts
// the CDN edge there), but forwarding needs a destination to prove the
// frame arrives unchanged.
function joinedNetworks() {
  const net10 = createNetwork();
  const net20 = createNetwork();
  const router = createRouter();
  net10.attachRouter(router);
  net20.attachRouter(router);
  router.attach(net10, net20);
  net10.registerServer('10.1', createWebServer({ address: '10.1' }));
  net20.registerServer('20.5', createWebServer({ address: '20.5' }));
  return { net10, net20, router };
}

describe('createRouter', () => {
  it("same-subnet sends keep today's send and deliverToQueue contract unchanged", () => {
    const { net10, router } = joinedNetworks();
    expect(net10.send({ from: '10.2', to: '10.1', request: 'GET /about' })).toEqual({
      from: '10.2',
      to: '10.1',
      request: 'GET /about',
      response: '200 This is the about page',
    });
    const server = net10.resolve('10.1');
    server.enqueue({
      id: 'q:1',
      from: '10.2',
      to: '10.1',
      request: 'GET /',
      atTick: 1,
      isYou: true,
    });
    expect(server.queueSnapshot()[0]).toMatchObject({ isYou: true, request: 'GET /' });
    expect(router.snapshot().routed).toBe(0);
  });

  it('cross-subnet frames take exactly one router hop and isYou rides through', () => {
    const { net10, net20, router } = joinedNetworks();
    const frame = net10.send({ from: '10.2', to: '20.5', request: 'GET /about' });
    expect(frame).toEqual({
      from: '10.2',
      to: '20.5',
      request: 'GET /about',
      response: '200 This is the about page',
    });
    expect(router.snapshot()).toEqual({ leftAddress: '10.65', rightAddress: '20.1', routed: 1 });
    // A queue delivery crosses the same single hop; the you-flag rides
    // through onto the destination queue row.
    net10.deliverToQueue({
      id: 'q:2',
      from: '10.2',
      to: '20.5',
      request: 'GET /',
      atTick: 2,
      isYou: true,
    });
    expect(net20.resolve('20.5').queueSnapshot()[0]).toMatchObject({ isYou: true });
    expect(router.snapshot().routed).toBe(2);

    // The router's own interfaces answer pings from their subnets: 20.1 is
    // the only reachable 20.x target in 6a.
    expect(net10.send({ from: '10.2', to: '20.1', request: 'GET /' }).response).toBe(
      '200 Router 20.1',
    );
    expect(net10.send({ from: '10.2', to: '10.65', request: 'GET /' }).response).toBe(
      '200 Router 10.65',
    );
  });

  it('a send into subnet 20 to unregistered 20.9 fails loud', () => {
    const { net10 } = joinedNetworks();
    expect(() => net10.send({ from: '10.2', to: '20.9', request: 'GET /' })).toThrow(
      /no server at 20\.9/,
    );
    expect(() =>
      net10.deliverToQueue({ id: 'q:3', from: '10.2', to: '20.9', request: 'GET /', atTick: 1 }),
    ).toThrow(/no server at 20\.9/);
    // CHECKS: the constructor rejects an interface that is not a two-number
    // mini-IP.
    expect(() => createRouter({ leftAddress: '1065' })).toThrow(/invalid mini-IP/);
    expect(() => createRouter({ rightAddress: '20' })).toThrow(/invalid mini-IP/);
  });

  it('stage 6 engine exposes Router 10.65 ⇄ 20.1 and DNS 10.60 from stage 6 only', () => {
    const snap = createEngine({ stage: 6 }).snapshot();
    expect(snap.router).toEqual({ leftAddress: '10.65', rightAddress: '20.1', routed: 0 });
    expect(snap.dns).not.toBe(null);
    expect(createEngine({ stage: 5 }).snapshot().router).toBe(null);
    expect(createEngine({ stage: 1 }).snapshot().router).toBe(null);
  });
});
