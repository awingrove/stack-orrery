import { describe, it, expect } from 'vitest';
import { describeSnapshot } from '../../js/panel/model.js';
import { componentTitle, formatComponentState } from '../../js/panel/inspector-state.js';

// Stage-boundary extraction (guard-file-size): the Stage 6 narrative-branch
// pins — the host-less trace keeps the Stage 5 story byte-identical, a
// hosted path adds exactly two DNS hops, and an NX answer renders the NX
// card with no GET sentence anywhere.
function traceBase(over = {}) {
  return {
    hop: 1,
    method: 'GET',
    path: '/about',
    request: 'GET /about',
    targetServer: '10.11',
    asyncJob: false,
    cacheStatus: 'MISS',
    dbOp: 'SELECT',
    dbStale: false,
    response: '200 This is the about page',
    status: 200,
    body: 'This is the about page',
    routeId: 'about',
    dns: null,
    ...over,
  };
}

function snapBase(stage, trace, over = {}) {
  return {
    stage,
    tick: 2,
    users: 5,
    serverAddress: '10.1',
    queueDepth: 0,
    served: 1,
    avgLatencyTicks: 1,
    loadBalancer: { address: '10.1', nextBackend: '10.11', perBackend: { 10.11: 1, 10.12: 0 } },
    cache: { address: '10.20', ttlTicks: 10, hits: 0, misses: 1, entries: [] },
    database: {
      primaryAddress: '10.30',
      replicaAddress: '10.31',
      replicationLagTicks: 3,
      rows: [],
    },
    workerQueue: {
      address: '10.40',
      workerAddress: '10.41',
      jobDurationTicks: 2,
      enqueued: 0,
      completed: 0,
      activeJob: null,
      pendingJobs: [],
    },
    servers: [
      { address: '10.11', queueDepth: 0, served: 1, queue: [] },
      { address: '10.12', queueDepth: 0, served: 0, queue: [] },
    ],
    dns: stage === 6 ? { address: '10.60', ttlTicks: 300, lookups: 0, cachedHits: 0 } : null,
    router: stage === 6 ? { leftAddress: '10.65', rightAddress: '20.1', routed: 0 } : null,
    trace,
    ...over,
  };
}

describe('describeSnapshot stage 6', () => {
  it('stage 6 host-less GET /about keeps the stage-5 hop story byte-identical — no DNS hop, no cross-subnet hop', () => {
    expect(describeSnapshot(snapBase(6, traceBase())).totalHops).toBe(8);
    for (let hop = 1; hop <= 8; hop++) {
      const trace = { ...traceBase(), hop };
      const s5 = describeSnapshot(snapBase(5, trace));
      const s6 = describeSnapshot(snapBase(6, trace));
      expect(s6.hopStatus).toBe(s5.hopStatus);
      expect(s6.totalHops).toBe(s5.totalHops);
      // The named counter-example: a GET trace keeps the Stage 5 story —
      // no DNS ask, no NX, no router sentence anywhere.
      expect(s6.hopStatus).not.toMatch(/DNS|NX|Router/);
    }
  });

  it('stage 6 hosted example.com/about adds exactly two DNS hops to the 8-hop story (10 total)', () => {
    const hosted = {
      dns: { host: 'example.com', rest: '/about', status: 'ANSWER', target: '10.1' },
    };
    const snap = snapBase(6, traceBase({ hop: 2, ...hosted }));
    const labels = describeSnapshot(snap);
    expect(labels.totalHops).toBe(10);
    expect(labels.hopStatus).toBe('Hop 2/10: DNS (10.60) -> Browser (10.2): "example.com = 10.1"');
    expect(describeSnapshot(snapBase(6, traceBase({ hop: 1, ...hosted }))).hopStatus).toBe(
      'Hop 1/10: Browser (10.2) asks DNS (10.60): "example.com?"',
    );
    // Hops 3..10 are the Stage 5 story renumbered — same sentences, +2 hops.
    for (let story = 1; story <= 8; story++) {
      const s5 = describeSnapshot(snapBase(5, traceBase({ hop: story })));
      const s6 = describeSnapshot(snapBase(6, traceBase({ hop: story + 2, ...hosted })));
      expect(s6.hopStatus).toBe(
        s5.hopStatus.replace(/^Hop (\d)\/8:/, (_m, n) => `Hop ${Number(n) + 2}/10:`),
      );
    }
  });

  it('stage 6 NX trace renders the NX card and never emits a GET (3 hops, no serve sentence)', () => {
    const nx = { dns: { host: 'nope.example', rest: '/about', status: 'NX', target: null } };
    const snap = snapBase(6, traceBase({ hop: 2, request: 'GET nope.example/about', ...nx }));
    expect(describeSnapshot(snap).totalHops).toBe(3);
    expect(describeSnapshot(snapBase(6, traceBase({ hop: 1, ...nx }))).hopStatus).toBe(
      'Hop 1/3: Browser (10.2) asks DNS (10.60): "nope.example?"',
    );
    expect(describeSnapshot(snap).hopStatus).toBe(
      'Hop 2/3: DNS (10.60) -> Browser (10.2): "NX no record"',
    );
    const rendered = describeSnapshot(snapBase(6, traceBase({ hop: 3, ...nx })));
    expect(rendered.hopStatus).toBe(
      'Hop 3/3: Browser (10.2) rendered nope.example NX — no GET emitted',
    );
    // No GET sentence in any NX hop: nothing was emitted to a webserver.
    for (let hop = 1; hop <= 3; hop++) {
      const sentence = describeSnapshot(snapBase(6, traceBase({ hop, ...nx }))).hopStatus;
      expect(sentence).not.toMatch(/WebServer|Network delivers|emits "GET \//);
    }
  });

  it('maps a live stage-6 snapshot to the dns and router inspector state as JSON', () => {
    const hosted = {
      dns: { host: 'example.com', rest: '/about', status: 'ANSWER', target: '10.1' },
    };
    const snap = snapBase(6, traceBase({ hop: 2, ...hosted }), {
      dns: {
        address: '10.60',
        ttlTicks: 300,
        lookups: 2,
        cachedHits: 1,
        authoritative: 1,
        lastLookup: { name: 'example.com', status: 'HIT', atTick: 2 },
        cache: [{ name: 'example.com', target: '10.1', expiresAtTick: 301, ttlRemaining: 299 }],
      },
      router: { leftAddress: '10.65', rightAddress: '20.1', routed: 1 },
    });
    const dnsState = JSON.parse(formatComponentState(snap, 'dns'));
    expect(dnsState).toEqual({
      address: '10.60',
      ttlTicks: 300,
      authoritativeTable: { 'example.com': '10.1' },
      lookups: 2,
      cachedHits: 1,
      authoritative: 1,
      lastLookup: { name: 'example.com', status: 'HIT', atTick: 2 },
      cache: [{ name: 'example.com', target: '10.1', expiresAtTick: 301, ttlRemaining: 299 }],
    });
    expect(JSON.parse(formatComponentState(snap, 'router'))).toEqual({
      leftAddress: '10.65',
      rightAddress: '20.1',
      routed: 1,
      joinedSubnets: ['10.x', '20.x'],
    });
    expect(componentTitle(snap, 'dns')).toBe('DNS — mini-IP 10.60');
    expect(componentTitle(snap, 'router')).toBe('Router — 10.65 ⇄ 20.1');
    // The Stage 6 network table names the resolver and both router sides
    // (quoted string keys — a bare 10.60 literal collapses to 10.6).
    const networkState = JSON.parse(formatComponentState(snap, 'network'));
    expect(networkState.interfaces['10.60']).toBe('DNS');
    expect(networkState.interfaces['10.65']).toBe('Router (10.x side)');
    expect(networkState.interfaces['20.1']).toBe('Router (20.x side)');
    // Live labels for the two stage-6 cards read off the snapshot.
    const labels = describeSnapshot(snap);
    expect(labels.dnsStatsLabel).toBe('Lookups: 2 · Hits: 1 · TTL: 300t');
    expect(labels.routerStatsLabel).toBe('Routed: 1 · 10.65 ⇄ 20.1');
  });
});
